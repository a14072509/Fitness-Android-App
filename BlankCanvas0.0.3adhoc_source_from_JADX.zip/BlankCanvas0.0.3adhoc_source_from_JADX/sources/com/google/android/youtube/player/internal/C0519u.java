package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: com.google.android.youtube.player.internal.u */
public interface C0519u extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.u$a */
    public static abstract class C0710a extends Binder implements C0519u {

        /* renamed from: com.google.android.youtube.player.internal.u$a$a */
        private static class C0709a implements C0519u {
            /* renamed from: a */
            private IBinder f115a;

            C0709a(IBinder iBinder) {
                this.f115a = iBinder;
            }

            public final IBinder asBinder() {
                return this.f115a;
            }
        }

        public C0710a() {
            attachInterface(this, "com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
        }

        /* renamed from: a */
        public static C0519u m321a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0519u)) ? new C0709a(iBinder) : (C0519u) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel2.writeString("com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
            return true;
        }
    }
}
