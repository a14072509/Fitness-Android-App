package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailLoader.ErrorReason;
import com.google.android.youtube.player.YouTubeThumbnailLoader.OnThumbnailLoadedListener;
import com.google.android.youtube.player.YouTubeThumbnailView;
import java.lang.ref.WeakReference;
import java.util.NoSuchElementException;

/* renamed from: com.google.android.youtube.player.internal.a */
public abstract class C0684a implements YouTubeThumbnailLoader {
    /* renamed from: a */
    private final WeakReference<YouTubeThumbnailView> f85a;
    /* renamed from: b */
    private OnThumbnailLoadedListener f86b;
    /* renamed from: c */
    private boolean f87c;
    /* renamed from: d */
    private boolean f88d;

    public C0684a(YouTubeThumbnailView youTubeThumbnailView) {
        this.f85a = new WeakReference(ab.m44a((Object) youTubeThumbnailView));
    }

    /* renamed from: i */
    private void m190i() {
        if (!mo2542a()) {
            throw new IllegalStateException("This YouTubeThumbnailLoader has been released");
        }
    }

    /* renamed from: a */
    public final void m191a(Bitmap bitmap, String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f85a.get();
        if (mo2542a() && youTubeThumbnailView != null) {
            youTubeThumbnailView.setImageBitmap(bitmap);
            OnThumbnailLoadedListener onThumbnailLoadedListener = this.f86b;
            if (onThumbnailLoadedListener != null) {
                onThumbnailLoadedListener.onThumbnailLoaded(youTubeThumbnailView, str);
            }
        }
    }

    /* renamed from: a */
    public abstract void mo2540a(String str);

    /* renamed from: a */
    public abstract void mo2541a(String str, int i);

    /* renamed from: a */
    protected boolean mo2542a() {
        return !this.f88d;
    }

    /* renamed from: b */
    public final void m195b() {
        if (mo2542a()) {
            C0523y.m136a("The finalize() method for a YouTubeThumbnailLoader has work to do. You should have called release().", new Object[0]);
            release();
        }
    }

    /* renamed from: b */
    public final void m196b(String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f85a.get();
        if (mo2542a() && this.f86b != null && youTubeThumbnailView != null) {
            ErrorReason valueOf;
            try {
                valueOf = ErrorReason.valueOf(str);
            } catch (IllegalArgumentException e) {
                valueOf = ErrorReason.UNKNOWN;
            }
            this.f86b.onThumbnailError(youTubeThumbnailView, valueOf);
        }
    }

    /* renamed from: c */
    public abstract void mo2543c();

    /* renamed from: d */
    public abstract void mo2544d();

    /* renamed from: e */
    public abstract void mo2545e();

    /* renamed from: f */
    public abstract boolean mo2546f();

    public final void first() {
        m190i();
        if (this.f87c) {
            mo2545e();
            return;
        }
        throw new IllegalStateException("Must call setPlaylist first");
    }

    /* renamed from: g */
    public abstract boolean mo2547g();

    /* renamed from: h */
    public abstract void mo2548h();

    public final boolean hasNext() {
        m190i();
        return mo2546f();
    }

    public final boolean hasPrevious() {
        m190i();
        return mo2547g();
    }

    public final void next() {
        m190i();
        if (!this.f87c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (mo2546f()) {
            mo2543c();
        } else {
            throw new NoSuchElementException("Called next at end of playlist");
        }
    }

    public final void previous() {
        m190i();
        if (!this.f87c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (mo2547g()) {
            mo2544d();
        } else {
            throw new NoSuchElementException("Called previous at start of playlist");
        }
    }

    public final void release() {
        if (mo2542a()) {
            this.f88d = true;
            this.f86b = null;
            mo2548h();
        }
    }

    public final void setOnThumbnailLoadedListener(OnThumbnailLoadedListener onThumbnailLoadedListener) {
        m190i();
        this.f86b = onThumbnailLoadedListener;
    }

    public final void setPlaylist(String str) {
        setPlaylist(str, 0);
    }

    public final void setPlaylist(String str, int i) {
        m190i();
        this.f87c = true;
        mo2541a(str, i);
    }

    public final void setVideo(String str) {
        m190i();
        this.f87c = false;
        mo2540a(str);
    }
}
