package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0518t.C0516a;
import com.google.android.youtube.player.internal.C0518t.C0517b;
import com.google.android.youtube.player.internal.C0521w.C0520a;

public abstract class aa {
    /* renamed from: a */
    private static final aa f25a = m40b();

    /* renamed from: a */
    public static aa m39a() {
        return f25a;
    }

    /* renamed from: b */
    private static aa m40b() {
        try {
            return (aa) Class.forName("com.google.android.youtube.api.locallylinked.LocallyLinkedFactory").asSubclass(aa.class).newInstance();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        } catch (Throwable e2) {
            throw new IllegalStateException(e2);
        } catch (ClassNotFoundException e3) {
            return new ac();
        }
    }

    /* renamed from: a */
    public abstract C0684a mo1592a(C0685b c0685b, YouTubeThumbnailView youTubeThumbnailView);

    /* renamed from: a */
    public abstract C0685b mo1593a(Context context, String str, C0516a c0516a, C0517b c0517b);

    /* renamed from: a */
    public abstract C0498d mo1594a(Activity activity, C0685b c0685b, boolean z) throws C0520a;
}
