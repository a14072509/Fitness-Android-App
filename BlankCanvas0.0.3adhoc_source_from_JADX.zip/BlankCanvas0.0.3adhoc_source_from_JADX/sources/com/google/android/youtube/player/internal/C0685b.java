package com.google.android.youtube.player.internal;

import android.os.IBinder;

/* renamed from: com.google.android.youtube.player.internal.b */
public interface C0685b extends C0518t {
    /* renamed from: a */
    IBinder mo2533a();

    /* renamed from: a */
    C0505k mo2535a(C0504j c0504j);

    /* renamed from: a */
    void mo2537a(boolean z);
}
