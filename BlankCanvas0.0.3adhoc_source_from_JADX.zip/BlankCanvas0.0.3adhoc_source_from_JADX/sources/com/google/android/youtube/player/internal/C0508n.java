package com.google.android.youtube.player.internal;

import android.content.Context;
import android.support.v4.view.ViewCompat;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.ccil.cowan.tagsoup.Schema;

/* renamed from: com.google.android.youtube.player.internal.n */
public final class C0508n extends FrameLayout {
    /* renamed from: a */
    private final ProgressBar f36a;
    /* renamed from: b */
    private final TextView f37b;

    public C0508n(Context context) {
        super(context, null, C0524z.m145c(context));
        C0507m c0507m = new C0507m(context);
        setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.f36a = new ProgressBar(context);
        this.f36a.setVisibility(8);
        addView(this.f36a, new LayoutParams(-2, -2, 17));
        int i = (int) ((context.getResources().getDisplayMetrics().density * 10.0f) + 0.5f);
        this.f37b = new TextView(context);
        this.f37b.setTextAppearance(context, 16973894);
        this.f37b.setTextColor(-1);
        this.f37b.setVisibility(8);
        this.f37b.setPadding(i, i, i, i);
        this.f37b.setGravity(17);
        this.f37b.setText(c0507m.f26a);
        addView(this.f37b, new LayoutParams(-2, -2, 17));
    }

    /* renamed from: a */
    public final void m119a() {
        this.f36a.setVisibility(8);
        this.f37b.setVisibility(8);
    }

    /* renamed from: b */
    public final void m120b() {
        this.f36a.setVisibility(0);
        this.f37b.setVisibility(8);
    }

    /* renamed from: c */
    public final void m121c() {
        this.f36a.setVisibility(8);
        this.f37b.setVisibility(0);
    }

    protected final void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (mode != Schema.M_PCDATA || mode2 != Schema.M_PCDATA) {
            if (mode != Schema.M_PCDATA) {
                if (mode != Integer.MIN_VALUE || mode2 != 0) {
                    float f;
                    if (mode2 != Schema.M_PCDATA) {
                        if (mode2 != Integer.MIN_VALUE || mode != 0) {
                            if (mode == Integer.MIN_VALUE && mode2 == Integer.MIN_VALUE) {
                                f = (float) size2;
                                float f2 = ((float) size) / 1.777f;
                                if (f < f2) {
                                    size = (int) (f * 1.777f);
                                } else {
                                    size2 = (int) f2;
                                }
                            } else {
                                size = 0;
                                size2 = 0;
                            }
                        }
                    }
                    f = (float) size2;
                    size = (int) (f * 1.777f);
                }
            }
            size2 = (int) (((float) size) / 1.777f);
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(C0508n.resolveSize(size, i), Schema.M_PCDATA), MeasureSpec.makeMeasureSpec(C0508n.resolveSize(size2, i2), Schema.M_PCDATA));
    }
}
