package com.google.android.youtube.player;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.google.android.youtube.player.internal.C0518t.C0516a;
import com.google.android.youtube.player.internal.C0518t.C0517b;
import com.google.android.youtube.player.internal.C0684a;
import com.google.android.youtube.player.internal.C0685b;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;

public final class YouTubeThumbnailView extends ImageView {
    /* renamed from: a */
    private C0685b f23a;
    /* renamed from: b */
    private C0684a f24b;

    public interface OnInitializedListener {
        void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult);

        void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader youTubeThumbnailLoader);
    }

    /* renamed from: com.google.android.youtube.player.YouTubeThumbnailView$a */
    private static final class C0683a implements C0516a, C0517b {
        /* renamed from: a */
        private YouTubeThumbnailView f83a;
        /* renamed from: b */
        private OnInitializedListener f84b;

        public C0683a(YouTubeThumbnailView youTubeThumbnailView, OnInitializedListener onInitializedListener) {
            this.f83a = (YouTubeThumbnailView) ab.m45a((Object) youTubeThumbnailView, (Object) "thumbnailView cannot be null");
            this.f84b = (OnInitializedListener) ab.m45a((Object) onInitializedListener, (Object) "onInitializedlistener cannot be null");
        }

        /* renamed from: c */
        private void m186c() {
            YouTubeThumbnailView youTubeThumbnailView = this.f83a;
            if (youTubeThumbnailView != null) {
                youTubeThumbnailView.f23a = null;
                this.f83a = null;
                this.f84b = null;
            }
        }

        /* renamed from: a */
        public final void mo1579a() {
            YouTubeThumbnailView youTubeThumbnailView = this.f83a;
            if (youTubeThumbnailView != null && youTubeThumbnailView.f23a != null) {
                this.f83a.f24b = aa.m39a().mo1592a(this.f83a.f23a, this.f83a);
                OnInitializedListener onInitializedListener = this.f84b;
                YouTubeThumbnailView youTubeThumbnailView2 = this.f83a;
                onInitializedListener.onInitializationSuccess(youTubeThumbnailView2, youTubeThumbnailView2.f24b);
                m186c();
            }
        }

        /* renamed from: a */
        public final void mo1581a(YouTubeInitializationResult youTubeInitializationResult) {
            this.f84b.onInitializationFailure(this.f83a, youTubeInitializationResult);
            m186c();
        }

        /* renamed from: b */
        public final void mo1580b() {
            m186c();
        }
    }

    public YouTubeThumbnailView(Context context) {
        this(context, null);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    protected final void finalize() throws Throwable {
        C0684a c0684a = this.f24b;
        if (c0684a != null) {
            c0684a.m195b();
            this.f24b = null;
        }
        super.finalize();
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        Object c0683a = new C0683a(this, onInitializedListener);
        this.f23a = aa.m39a().mo1593a(getContext(), str, c0683a, c0683a);
        this.f23a.mo1668e();
    }
}
