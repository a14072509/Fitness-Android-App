package com.google.android.youtube.player;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.C0496b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerFragment extends Fragment implements Provider {
    /* renamed from: a */
    private final C0679a f61a = new C0679a();
    /* renamed from: b */
    private Bundle f62b;
    /* renamed from: c */
    private YouTubePlayerView f63c;
    /* renamed from: d */
    private String f64d;
    /* renamed from: e */
    private OnInitializedListener f65e;
    /* renamed from: f */
    private boolean f66f;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerFragment$a */
    private final class C0679a implements C0496b {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerFragment f60a;

        private C0679a(YouTubePlayerFragment youTubePlayerFragment) {
            this.f60a = youTubePlayerFragment;
        }

        /* renamed from: a */
        public final void mo1576a(YouTubePlayerView youTubePlayerView) {
        }

        /* renamed from: a */
        public final void mo1577a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            YouTubePlayerFragment youTubePlayerFragment = this.f60a;
            youTubePlayerFragment.initialize(str, youTubePlayerFragment.f65e);
        }
    }

    /* renamed from: a */
    private void m158a() {
        YouTubePlayerView youTubePlayerView = this.f63c;
        if (youTubePlayerView != null && this.f65e != null) {
            youTubePlayerView.m179a(this.f66f);
            this.f63c.m178a(getActivity(), this, this.f64d, this.f65e, this.f62b);
            this.f62b = null;
            this.f65e = null;
        }
    }

    public static YouTubePlayerFragment newInstance() {
        return new YouTubePlayerFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f64d = ab.m46a(str, (Object) "Developer key cannot be null or empty");
        this.f65e = onInitializedListener;
        m158a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f62b = bundle != null ? bundle.getBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f63c = new YouTubePlayerView(getActivity(), null, 0, this.f61a);
        m158a();
        return this.f63c;
    }

    public void onDestroy() {
        if (this.f63c != null) {
            boolean z;
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f63c;
            if (activity != null) {
                if (!activity.isFinishing()) {
                    z = false;
                    youTubePlayerView.m181b(z);
                }
            }
            z = true;
            youTubePlayerView.m181b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f63c.m183c(getActivity().isFinishing());
        this.f63c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f63c.m182c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f63c.m180b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        YouTubePlayerView youTubePlayerView = this.f63c;
        bundle.putBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE", youTubePlayerView != null ? youTubePlayerView.m185e() : this.f62b);
    }

    public void onStart() {
        super.onStart();
        this.f63c.m177a();
    }

    public void onStop() {
        this.f63c.m184d();
        super.onStop();
    }
}
