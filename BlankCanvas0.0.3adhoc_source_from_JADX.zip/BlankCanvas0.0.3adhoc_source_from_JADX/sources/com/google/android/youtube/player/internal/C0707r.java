package com.google.android.youtube.player.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.youtube.player.YouTubeApiServiceUtil;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.internal.C0497c.C0687a;
import com.google.android.youtube.player.internal.C0503i.C0699a;
import com.google.android.youtube.player.internal.C0518t.C0516a;
import com.google.android.youtube.player.internal.C0518t.C0517b;
import java.util.ArrayList;

/* renamed from: com.google.android.youtube.player.internal.r */
public abstract class C0707r<T extends IInterface> implements C0518t {
    /* renamed from: a */
    final Handler f102a;
    /* renamed from: b */
    private final Context f103b;
    /* renamed from: c */
    private T f104c;
    /* renamed from: d */
    private ArrayList<C0516a> f105d;
    /* renamed from: e */
    private final ArrayList<C0516a> f106e = new ArrayList();
    /* renamed from: f */
    private boolean f107f = false;
    /* renamed from: g */
    private ArrayList<C0517b> f108g;
    /* renamed from: h */
    private boolean f109h = false;
    /* renamed from: i */
    private final ArrayList<C0514b<?>> f110i = new ArrayList();
    /* renamed from: j */
    private ServiceConnection f111j;
    /* renamed from: k */
    private boolean f112k = false;

    /* renamed from: com.google.android.youtube.player.internal.r$1 */
    static /* synthetic */ class C05121 {
        /* renamed from: a */
        static final /* synthetic */ int[] f47a = new int[YouTubeInitializationResult.values().length];

        static {
            try {
                f47a[YouTubeInitializationResult.SUCCESS.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$a */
    final class C0513a extends Handler {
        /* renamed from: a */
        final /* synthetic */ C0707r f48a;

        C0513a(C0707r c0707r) {
            this.f48a = c0707r;
        }

        public final void handleMessage(Message message) {
            if (message.what == 3) {
                this.f48a.m295a((YouTubeInitializationResult) message.obj);
            } else if (message.what == 4) {
                synchronized (this.f48a.f105d) {
                    if (this.f48a.f112k && this.f48a.m302f() && this.f48a.f105d.contains(message.obj)) {
                        ((C0516a) message.obj).mo1579a();
                    }
                }
            } else if (message.what != 2 || this.f48a.m302f()) {
                if (message.what != 2) {
                    if (message.what != 1) {
                        return;
                    }
                }
                ((C0514b) message.obj).m122a();
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$b */
    protected abstract class C0514b<TListener> {
        /* renamed from: a */
        final /* synthetic */ C0707r f49a;
        /* renamed from: b */
        private TListener f50b;

        public C0514b(C0707r c0707r, TListener tListener) {
            this.f49a = c0707r;
            this.f50b = tListener;
            synchronized (c0707r.f110i) {
                c0707r.f110i.add(this);
            }
        }

        /* renamed from: a */
        public final void m122a() {
            Object obj;
            synchronized (this) {
                obj = this.f50b;
            }
            mo1666a(obj);
        }

        /* renamed from: a */
        protected abstract void mo1666a(TListener tListener);

        /* renamed from: b */
        public final void m124b() {
            synchronized (this) {
                this.f50b = null;
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$e */
    final class C0515e implements ServiceConnection {
        /* renamed from: a */
        final /* synthetic */ C0707r f51a;

        C0515e(C0707r c0707r) {
            this.f51a = c0707r;
        }

        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f51a.m298b(iBinder);
        }

        public final void onServiceDisconnected(ComponentName componentName) {
            this.f51a.f104c = null;
            this.f51a.m304h();
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$c */
    protected final class C0706c extends C0514b<Boolean> {
        /* renamed from: b */
        public final YouTubeInitializationResult f99b;
        /* renamed from: c */
        public final IBinder f100c;
        /* renamed from: d */
        final /* synthetic */ C0707r f101d;

        public C0706c(C0707r c0707r, String str, IBinder iBinder) {
            this.f101d = c0707r;
            super(c0707r, Boolean.valueOf(true));
            this.f99b = C0707r.m289b(str);
            this.f100c = iBinder;
        }

        /* renamed from: a */
        protected final /* synthetic */ void mo1666a(Object obj) {
            if (((Boolean) obj) != null) {
                if (C05121.f47a[this.f99b.ordinal()] != 1) {
                    this.f101d.m295a(this.f99b);
                } else {
                    try {
                        if (this.f101d.mo2538b().equals(this.f100c.getInterfaceDescriptor())) {
                            this.f101d.f104c = this.f101d.mo2534a(this.f100c);
                            if (this.f101d.f104c != null) {
                                this.f101d.m303g();
                                return;
                            }
                        }
                    } catch (RemoteException e) {
                    }
                    this.f101d.mo2533a();
                    this.f101d.m295a(YouTubeInitializationResult.INTERNAL_ERROR);
                }
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$d */
    protected final class C0752d extends C0687a {
        /* renamed from: a */
        final /* synthetic */ C0707r f132a;

        protected C0752d(C0707r c0707r) {
            this.f132a = c0707r;
        }

        /* renamed from: a */
        public final void mo1595a(String str, IBinder iBinder) {
            this.f132a.f102a.sendMessage(this.f132a.f102a.obtainMessage(1, new C0706c(this.f132a, str, iBinder)));
        }
    }

    protected C0707r(Context context, C0516a c0516a, C0517b c0517b) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            this.f103b = (Context) ab.m44a((Object) context);
            this.f105d = new ArrayList();
            this.f105d.add(ab.m44a((Object) c0516a));
            this.f108g = new ArrayList();
            this.f108g.add(ab.m44a((Object) c0517b));
            this.f102a = new C0513a(this);
            return;
        }
        throw new IllegalStateException("Clients must be created on the UI thread.");
    }

    /* renamed from: a */
    private void mo2533a() {
        ServiceConnection serviceConnection = this.f111j;
        if (serviceConnection != null) {
            try {
                this.f103b.unbindService(serviceConnection);
            } catch (Throwable e) {
                Log.w("YouTubeClient", "Unexpected error from unbindService()", e);
            }
        }
        this.f104c = null;
        this.f111j = null;
    }

    /* renamed from: b */
    private static YouTubeInitializationResult m289b(String str) {
        try {
            return YouTubeInitializationResult.valueOf(str);
        } catch (IllegalArgumentException e) {
            return YouTubeInitializationResult.UNKNOWN_ERROR;
        } catch (NullPointerException e2) {
            return YouTubeInitializationResult.UNKNOWN_ERROR;
        }
    }

    /* renamed from: a */
    protected abstract T mo2534a(IBinder iBinder);

    /* renamed from: a */
    protected final void m295a(com.google.android.youtube.player.YouTubeInitializationResult r8) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:20:0x003b in {9, 12, 13, 16, 19} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.f102a;
        r1 = 4;
        r0.removeMessages(r1);
        r0 = r7.f108g;
        monitor-enter(r0);
        r1 = 1;
        r7.f109h = r1;	 Catch:{ all -> 0x0038 }
        r1 = r7.f108g;	 Catch:{ all -> 0x0038 }
        r2 = r1.size();	 Catch:{ all -> 0x0038 }
        r3 = 0;	 Catch:{ all -> 0x0038 }
        r4 = 0;	 Catch:{ all -> 0x0038 }
    L_0x0014:
        if (r4 >= r2) goto L_0x0034;	 Catch:{ all -> 0x0038 }
    L_0x0016:
        r5 = r7.f112k;	 Catch:{ all -> 0x0038 }
        if (r5 != 0) goto L_0x001c;	 Catch:{ all -> 0x0038 }
    L_0x001a:
        monitor-exit(r0);	 Catch:{ all -> 0x0038 }
        return;	 Catch:{ all -> 0x0038 }
    L_0x001c:
        r5 = r7.f108g;	 Catch:{ all -> 0x0038 }
        r6 = r1.get(r4);	 Catch:{ all -> 0x0038 }
        r5 = r5.contains(r6);	 Catch:{ all -> 0x0038 }
        if (r5 == 0) goto L_0x0031;	 Catch:{ all -> 0x0038 }
    L_0x0028:
        r5 = r1.get(r4);	 Catch:{ all -> 0x0038 }
        r5 = (com.google.android.youtube.player.internal.C0518t.C0517b) r5;	 Catch:{ all -> 0x0038 }
        r5.mo1581a(r8);	 Catch:{ all -> 0x0038 }
    L_0x0031:
        r4 = r4 + 1;	 Catch:{ all -> 0x0038 }
        goto L_0x0014;	 Catch:{ all -> 0x0038 }
    L_0x0034:
        r7.f109h = r3;	 Catch:{ all -> 0x0038 }
        monitor-exit(r0);	 Catch:{ all -> 0x0038 }
        return;	 Catch:{ all -> 0x0038 }
    L_0x0038:
        r8 = move-exception;	 Catch:{ all -> 0x0038 }
        monitor-exit(r0);	 Catch:{ all -> 0x0038 }
        throw r8;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.a(com.google.android.youtube.player.YouTubeInitializationResult):void");
    }

    /* renamed from: a */
    protected abstract void mo2536a(C0503i c0503i, C0752d c0752d) throws RemoteException;

    /* renamed from: b */
    protected abstract String mo2538b();

    /* renamed from: b */
    protected final void m298b(IBinder iBinder) {
        try {
            mo2536a(C0699a.m270a(iBinder), new C0752d(this));
        } catch (RemoteException e) {
            Log.w("YouTubeClient", "service died");
        }
    }

    /* renamed from: c */
    protected abstract String mo2539c();

    /* renamed from: d */
    public void mo1667d() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:14:0x002c in {5, 9, 13} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r4 = this;
        r4.m304h();
        r0 = 0;
        r4.f112k = r0;
        r1 = r4.f110i;
        monitor-enter(r1);
        r2 = r4.f110i;	 Catch:{ all -> 0x0029 }
        r2 = r2.size();	 Catch:{ all -> 0x0029 }
    L_0x000f:
        if (r0 >= r2) goto L_0x001f;	 Catch:{ all -> 0x0029 }
    L_0x0011:
        r3 = r4.f110i;	 Catch:{ all -> 0x0029 }
        r3 = r3.get(r0);	 Catch:{ all -> 0x0029 }
        r3 = (com.google.android.youtube.player.internal.C0707r.C0514b) r3;	 Catch:{ all -> 0x0029 }
        r3.m124b();	 Catch:{ all -> 0x0029 }
        r0 = r0 + 1;	 Catch:{ all -> 0x0029 }
        goto L_0x000f;	 Catch:{ all -> 0x0029 }
    L_0x001f:
        r0 = r4.f110i;	 Catch:{ all -> 0x0029 }
        r0.clear();	 Catch:{ all -> 0x0029 }
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        r4.mo2533a();
        return;
    L_0x0029:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.d():void");
    }

    /* renamed from: e */
    public final void mo1668e() {
        this.f112k = true;
        YouTubeInitializationResult isYouTubeApiServiceAvailable = YouTubeApiServiceUtil.isYouTubeApiServiceAvailable(this.f103b);
        if (isYouTubeApiServiceAvailable != YouTubeInitializationResult.SUCCESS) {
            Handler handler = this.f102a;
            handler.sendMessage(handler.obtainMessage(3, isYouTubeApiServiceAvailable));
            return;
        }
        Intent intent = new Intent(mo2539c()).setPackage(C0524z.m139a(this.f103b));
        if (this.f111j != null) {
            Log.e("YouTubeClient", "Calling connect() while still connected, missing disconnect().");
            mo2533a();
        }
        this.f111j = new C0515e(this);
        if (!this.f103b.bindService(intent, this.f111j, 129)) {
            Handler handler2 = this.f102a;
            handler2.sendMessage(handler2.obtainMessage(3, YouTubeInitializationResult.ERROR_CONNECTING_TO_SERVICE));
        }
    }

    /* renamed from: f */
    public final boolean m302f() {
        return this.f104c != null;
    }

    /* renamed from: g */
    protected final void m303g() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:27:0x005b in {5, 6, 9, 10, 19, 20, 23, 26} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.f105d;
        monitor-enter(r0);
        r1 = r7.f107f;	 Catch:{ all -> 0x0058 }
        r2 = 1;	 Catch:{ all -> 0x0058 }
        r3 = 0;	 Catch:{ all -> 0x0058 }
        if (r1 != 0) goto L_0x000b;	 Catch:{ all -> 0x0058 }
    L_0x0009:
        r1 = 1;	 Catch:{ all -> 0x0058 }
        goto L_0x000c;	 Catch:{ all -> 0x0058 }
    L_0x000b:
        r1 = 0;	 Catch:{ all -> 0x0058 }
    L_0x000c:
        com.google.android.youtube.player.internal.ab.m47a(r1);	 Catch:{ all -> 0x0058 }
        r1 = r7.f102a;	 Catch:{ all -> 0x0058 }
        r4 = 4;	 Catch:{ all -> 0x0058 }
        r1.removeMessages(r4);	 Catch:{ all -> 0x0058 }
        r7.f107f = r2;	 Catch:{ all -> 0x0058 }
        r1 = r7.f106e;	 Catch:{ all -> 0x0058 }
        r1 = r1.size();	 Catch:{ all -> 0x0058 }
        if (r1 != 0) goto L_0x0020;	 Catch:{ all -> 0x0058 }
    L_0x001f:
        goto L_0x0021;	 Catch:{ all -> 0x0058 }
    L_0x0020:
        r2 = 0;	 Catch:{ all -> 0x0058 }
    L_0x0021:
        com.google.android.youtube.player.internal.ab.m47a(r2);	 Catch:{ all -> 0x0058 }
        r1 = r7.f105d;	 Catch:{ all -> 0x0058 }
        r2 = r1.size();	 Catch:{ all -> 0x0058 }
        r4 = 0;	 Catch:{ all -> 0x0058 }
    L_0x002b:
        if (r4 >= r2) goto L_0x004f;	 Catch:{ all -> 0x0058 }
    L_0x002d:
        r5 = r7.f112k;	 Catch:{ all -> 0x0058 }
        if (r5 == 0) goto L_0x004f;	 Catch:{ all -> 0x0058 }
    L_0x0031:
        r5 = r7.m302f();	 Catch:{ all -> 0x0058 }
        if (r5 == 0) goto L_0x004f;	 Catch:{ all -> 0x0058 }
    L_0x0037:
        r5 = r7.f106e;	 Catch:{ all -> 0x0058 }
        r6 = r1.get(r4);	 Catch:{ all -> 0x0058 }
        r5 = r5.contains(r6);	 Catch:{ all -> 0x0058 }
        if (r5 != 0) goto L_0x004c;	 Catch:{ all -> 0x0058 }
    L_0x0043:
        r5 = r1.get(r4);	 Catch:{ all -> 0x0058 }
        r5 = (com.google.android.youtube.player.internal.C0518t.C0516a) r5;	 Catch:{ all -> 0x0058 }
        r5.mo1579a();	 Catch:{ all -> 0x0058 }
    L_0x004c:
        r4 = r4 + 1;	 Catch:{ all -> 0x0058 }
        goto L_0x002b;	 Catch:{ all -> 0x0058 }
    L_0x004f:
        r1 = r7.f106e;	 Catch:{ all -> 0x0058 }
        r1.clear();	 Catch:{ all -> 0x0058 }
        r7.f107f = r3;	 Catch:{ all -> 0x0058 }
        monitor-exit(r0);	 Catch:{ all -> 0x0058 }
        return;	 Catch:{ all -> 0x0058 }
    L_0x0058:
        r1 = move-exception;	 Catch:{ all -> 0x0058 }
        monitor-exit(r0);	 Catch:{ all -> 0x0058 }
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.g():void");
    }

    /* renamed from: h */
    protected final void m304h() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:18:0x0039 in {10, 11, 14, 17} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.f102a;
        r1 = 4;
        r0.removeMessages(r1);
        r0 = r7.f105d;
        monitor-enter(r0);
        r1 = 1;
        r7.f107f = r1;	 Catch:{ all -> 0x0036 }
        r1 = r7.f105d;	 Catch:{ all -> 0x0036 }
        r2 = r1.size();	 Catch:{ all -> 0x0036 }
        r3 = 0;	 Catch:{ all -> 0x0036 }
        r4 = 0;	 Catch:{ all -> 0x0036 }
    L_0x0014:
        if (r4 >= r2) goto L_0x0032;	 Catch:{ all -> 0x0036 }
    L_0x0016:
        r5 = r7.f112k;	 Catch:{ all -> 0x0036 }
        if (r5 == 0) goto L_0x0032;	 Catch:{ all -> 0x0036 }
    L_0x001a:
        r5 = r7.f105d;	 Catch:{ all -> 0x0036 }
        r6 = r1.get(r4);	 Catch:{ all -> 0x0036 }
        r5 = r5.contains(r6);	 Catch:{ all -> 0x0036 }
        if (r5 == 0) goto L_0x002f;	 Catch:{ all -> 0x0036 }
    L_0x0026:
        r5 = r1.get(r4);	 Catch:{ all -> 0x0036 }
        r5 = (com.google.android.youtube.player.internal.C0518t.C0516a) r5;	 Catch:{ all -> 0x0036 }
        r5.mo1580b();	 Catch:{ all -> 0x0036 }
    L_0x002f:
        r4 = r4 + 1;	 Catch:{ all -> 0x0036 }
        goto L_0x0014;	 Catch:{ all -> 0x0036 }
    L_0x0032:
        r7.f107f = r3;	 Catch:{ all -> 0x0036 }
        monitor-exit(r0);	 Catch:{ all -> 0x0036 }
        return;	 Catch:{ all -> 0x0036 }
    L_0x0036:
        r1 = move-exception;	 Catch:{ all -> 0x0036 }
        monitor-exit(r0);	 Catch:{ all -> 0x0036 }
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.h():void");
    }

    /* renamed from: i */
    protected final void m305i() {
        if (!m302f()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    /* renamed from: j */
    protected final T m306j() {
        m305i();
        return this.f104c;
    }
}
