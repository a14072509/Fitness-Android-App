package com.google.android.youtube.player.internal;

import android.text.TextUtils;

public final class ab {
    /* renamed from: a */
    public static <T> T m44a(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException("null reference");
    }

    /* renamed from: a */
    public static <T> T m45a(T t, Object obj) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(String.valueOf(obj));
    }

    /* renamed from: a */
    public static String m46a(String str, Object obj) {
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        throw new IllegalArgumentException(String.valueOf(obj));
    }

    /* renamed from: a */
    public static void m47a(boolean z) {
        if (!z) {
            throw new IllegalStateException();
        }
    }
}
