package com.google.android.youtube.player.internal;

import android.content.res.Configuration;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.view.KeyEvent;
import com.google.android.youtube.player.internal.C0499e.C0691a.C0690a;
import com.google.android.youtube.player.internal.C0500f.C0693a.C0692a;
import com.google.android.youtube.player.internal.C0501g.C0695a.C0694a;
import com.google.android.youtube.player.internal.C0502h.C0697a.C0696a;
import com.google.android.youtube.player.internal.C0519u.C0710a;
import java.util.List;

/* renamed from: com.google.android.youtube.player.internal.d */
public interface C0498d extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.d$a */
    public static abstract class C0689a extends Binder implements C0498d {

        /* renamed from: com.google.android.youtube.player.internal.d$a$a */
        private static class C0688a implements C0498d {
            /* renamed from: a */
            private IBinder f90a;

            C0688a(IBinder iBinder) {
                this.f90a = iBinder;
            }

            /* renamed from: a */
            public final void mo1596a() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1597a(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(i);
                    this.f90a.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1598a(Configuration configuration) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    if (configuration != null) {
                        obtain.writeInt(1);
                        configuration.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f90a.transact(32, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1599a(C0499e c0499e) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeStrongBinder(c0499e != null ? c0499e.asBinder() : null);
                    this.f90a.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1600a(C0500f c0500f) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeStrongBinder(c0500f != null ? c0500f.asBinder() : null);
                    this.f90a.transact(29, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1601a(C0501g c0501g) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeStrongBinder(c0501g != null ? c0501g.asBinder() : null);
                    this.f90a.transact(28, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1602a(C0502h c0502h) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeStrongBinder(c0502h != null ? c0502h.asBinder() : null);
                    this.f90a.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1603a(String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeString(str);
                    this.f90a.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1604a(String str, int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    this.f90a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1605a(String str, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.f90a.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1606a(List<String> list, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeStringList(list);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.f90a.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1607a(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(z ? 1 : 0);
                    this.f90a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final boolean mo1608a(int i, KeyEvent keyEvent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(i);
                    boolean z = true;
                    if (keyEvent != null) {
                        obtain.writeInt(1);
                        keyEvent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f90a.transact(41, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() == 0) {
                        z = false;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final boolean mo1609a(Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    boolean z = true;
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f90a.transact(40, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() == 0) {
                        z = false;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f90a;
            }

            /* renamed from: b */
            public final void mo1610b() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: b */
            public final void mo1611b(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(i);
                    this.f90a.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: b */
            public final void mo1612b(String str, int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    this.f90a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: b */
            public final void mo1613b(String str, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.f90a.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: b */
            public final void mo1614b(List<String> list, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeStringList(list);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.f90a.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: b */
            public final void mo1615b(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(z ? 1 : 0);
                    this.f90a.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: b */
            public final boolean mo1616b(int i, KeyEvent keyEvent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(i);
                    boolean z = true;
                    if (keyEvent != null) {
                        obtain.writeInt(1);
                        keyEvent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f90a.transact(42, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() == 0) {
                        z = false;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: c */
            public final void mo1617c(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(i);
                    this.f90a.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: c */
            public final void mo1618c(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(z ? 1 : 0);
                    this.f90a.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: c */
            public final boolean mo1619c() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    boolean z = false;
                    this.f90a.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        z = true;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: d */
            public final void mo1620d(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(i);
                    this.f90a.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: d */
            public final void mo1621d(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(z ? 1 : 0);
                    this.f90a.transact(25, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: d */
            public final boolean mo1622d() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    boolean z = false;
                    this.f90a.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        z = true;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: e */
            public final void mo1623e(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    obtain.writeInt(z ? 1 : 0);
                    this.f90a.transact(37, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: e */
            public final boolean mo1624e() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    boolean z = false;
                    this.f90a.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        z = true;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: f */
            public final void mo1625f() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: g */
            public final void mo1626g() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: h */
            public final int mo1627h() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: i */
            public final int mo1628i() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: j */
            public final int mo1629j() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: k */
            public final void mo1630k() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(30, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: l */
            public final void mo1631l() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(31, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: m */
            public final void mo1632m() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(33, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: n */
            public final void mo1633n() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(34, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: o */
            public final void mo1634o() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(35, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: p */
            public final void mo1635p() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(36, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: q */
            public final void mo1636q() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(38, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: r */
            public final Bundle mo1637r() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(39, obtain, obtain2, 0);
                    obtain2.readException();
                    Bundle bundle = obtain2.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(obtain2) : null;
                    obtain2.recycle();
                    obtain.recycle();
                    return bundle;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: s */
            public final C0519u mo1638s() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                    this.f90a.transact(43, obtain, obtain2, 0);
                    obtain2.readException();
                    C0519u a = C0710a.m321a(obtain2.readStrongBinder());
                    return a;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        /* renamed from: a */
        public static C0498d m253a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0498d)) ? new C0688a(iBinder) : (C0498d) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1598968902) {
                boolean z = false;
                C0499e c0499e = null;
                boolean c;
                IBinder readStrongBinder;
                IInterface queryLocalInterface;
                KeyEvent keyEvent;
                switch (i) {
                    case 1:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            z = true;
                        }
                        mo1607a(z);
                        parcel2.writeNoException();
                        return true;
                    case 2:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1604a(parcel.readString(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 3:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1612b(parcel.readString(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 4:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1605a(parcel.readString(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 5:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1613b(parcel.readString(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 6:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1606a(parcel.createStringArrayList(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 7:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1614b(parcel.createStringArrayList(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 8:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1596a();
                        parcel2.writeNoException();
                        return true;
                    case 9:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1610b();
                        parcel2.writeNoException();
                        return true;
                    case 10:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        c = mo1619c();
                        parcel2.writeNoException();
                        parcel2.writeInt(c);
                        return true;
                    case 11:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        c = mo1622d();
                        parcel2.writeNoException();
                        parcel2.writeInt(c);
                        return true;
                    case 12:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        c = mo1624e();
                        parcel2.writeNoException();
                        parcel2.writeInt(c);
                        return true;
                    case 13:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1625f();
                        parcel2.writeNoException();
                        return true;
                    case 14:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1626g();
                        parcel2.writeNoException();
                        return true;
                    case 15:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        i = mo1627h();
                        parcel2.writeNoException();
                        parcel2.writeInt(i);
                        return true;
                    case 16:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        i = mo1628i();
                        parcel2.writeNoException();
                        parcel2.writeInt(i);
                        return true;
                    case 17:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1597a(parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 18:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1611b(parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 19:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            z = true;
                        }
                        mo1615b(z);
                        parcel2.writeNoException();
                        return true;
                    case 20:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1617c(parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 21:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        i = mo1629j();
                        parcel2.writeNoException();
                        parcel2.writeInt(i);
                        return true;
                    case 22:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1620d(parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 23:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1603a(parcel.readString());
                        parcel2.writeNoException();
                        return true;
                    case 24:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            z = true;
                        }
                        mo1618c(z);
                        parcel2.writeNoException();
                        return true;
                    case 25:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            z = true;
                        }
                        mo1621d(z);
                        parcel2.writeNoException();
                        return true;
                    case 26:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        readStrongBinder = parcel.readStrongBinder();
                        if (readStrongBinder != null) {
                            queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IOnFullscreenListener");
                            c0499e = (queryLocalInterface == null || !(queryLocalInterface instanceof C0499e)) ? new C0690a(readStrongBinder) : (C0499e) queryLocalInterface;
                        }
                        mo1599a(c0499e);
                        parcel2.writeNoException();
                        return true;
                    case 27:
                        C0502h c0696a;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        readStrongBinder = parcel.readStrongBinder();
                        if (readStrongBinder != null) {
                            queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IPlaylistEventListener");
                            c0696a = (queryLocalInterface == null || !(queryLocalInterface instanceof C0502h)) ? new C0696a(readStrongBinder) : (C0502h) queryLocalInterface;
                        }
                        mo1602a(c0696a);
                        parcel2.writeNoException();
                        return true;
                    case 28:
                        C0501g c0694a;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        readStrongBinder = parcel.readStrongBinder();
                        if (readStrongBinder != null) {
                            queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IPlayerStateChangeListener");
                            c0694a = (queryLocalInterface == null || !(queryLocalInterface instanceof C0501g)) ? new C0694a(readStrongBinder) : (C0501g) queryLocalInterface;
                        }
                        mo1601a(c0694a);
                        parcel2.writeNoException();
                        return true;
                    case 29:
                        C0500f c0692a;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        readStrongBinder = parcel.readStrongBinder();
                        if (readStrongBinder != null) {
                            queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IPlaybackEventListener");
                            c0692a = (queryLocalInterface == null || !(queryLocalInterface instanceof C0500f)) ? new C0692a(readStrongBinder) : (C0500f) queryLocalInterface;
                        }
                        mo1600a(c0692a);
                        parcel2.writeNoException();
                        return true;
                    case 30:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1630k();
                        parcel2.writeNoException();
                        return true;
                    case 31:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1631l();
                        parcel2.writeNoException();
                        return true;
                    case 32:
                        Configuration configuration;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            configuration = (Configuration) Configuration.CREATOR.createFromParcel(parcel);
                        }
                        mo1598a(configuration);
                        parcel2.writeNoException();
                        return true;
                    case 33:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1632m();
                        parcel2.writeNoException();
                        return true;
                    case 34:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1633n();
                        parcel2.writeNoException();
                        return true;
                    case 35:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1634o();
                        parcel2.writeNoException();
                        return true;
                    case 36:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1635p();
                        parcel2.writeNoException();
                        return true;
                    case 37:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            z = true;
                        }
                        mo1623e(z);
                        parcel2.writeNoException();
                        return true;
                    case 38:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        mo1636q();
                        parcel2.writeNoException();
                        return true;
                    case 39:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        Bundle r = mo1637r();
                        parcel2.writeNoException();
                        if (r != null) {
                            parcel2.writeInt(1);
                            r.writeToParcel(parcel2, 1);
                        } else {
                            parcel2.writeInt(0);
                        }
                        return true;
                    case 40:
                        Bundle bundle;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        if (parcel.readInt() != 0) {
                            bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                        }
                        c = mo1609a(bundle);
                        parcel2.writeNoException();
                        parcel2.writeInt(c);
                        return true;
                    case 41:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        i = parcel.readInt();
                        if (parcel.readInt() != 0) {
                            keyEvent = (KeyEvent) KeyEvent.CREATOR.createFromParcel(parcel);
                        }
                        c = mo1608a(i, keyEvent);
                        parcel2.writeNoException();
                        parcel2.writeInt(c);
                        return true;
                    case 42:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        i = parcel.readInt();
                        if (parcel.readInt() != 0) {
                            keyEvent = (KeyEvent) KeyEvent.CREATOR.createFromParcel(parcel);
                        }
                        c = mo1616b(i, keyEvent);
                        parcel2.writeNoException();
                        parcel2.writeInt(c);
                        return true;
                    case 43:
                        IBinder asBinder;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IEmbeddedPlayer");
                        C0519u s = mo1638s();
                        parcel2.writeNoException();
                        if (s != null) {
                            asBinder = s.asBinder();
                        }
                        parcel2.writeStrongBinder(asBinder);
                        return true;
                    default:
                        return super.onTransact(i, parcel, parcel2, i2);
                }
            }
            parcel2.writeString("com.google.android.youtube.player.internal.IEmbeddedPlayer");
            return true;
        }
    }

    /* renamed from: a */
    void mo1596a() throws RemoteException;

    /* renamed from: a */
    void mo1597a(int i) throws RemoteException;

    /* renamed from: a */
    void mo1598a(Configuration configuration) throws RemoteException;

    /* renamed from: a */
    void mo1599a(C0499e c0499e) throws RemoteException;

    /* renamed from: a */
    void mo1600a(C0500f c0500f) throws RemoteException;

    /* renamed from: a */
    void mo1601a(C0501g c0501g) throws RemoteException;

    /* renamed from: a */
    void mo1602a(C0502h c0502h) throws RemoteException;

    /* renamed from: a */
    void mo1603a(String str) throws RemoteException;

    /* renamed from: a */
    void mo1604a(String str, int i) throws RemoteException;

    /* renamed from: a */
    void mo1605a(String str, int i, int i2) throws RemoteException;

    /* renamed from: a */
    void mo1606a(List<String> list, int i, int i2) throws RemoteException;

    /* renamed from: a */
    void mo1607a(boolean z) throws RemoteException;

    /* renamed from: a */
    boolean mo1608a(int i, KeyEvent keyEvent) throws RemoteException;

    /* renamed from: a */
    boolean mo1609a(Bundle bundle) throws RemoteException;

    /* renamed from: b */
    void mo1610b() throws RemoteException;

    /* renamed from: b */
    void mo1611b(int i) throws RemoteException;

    /* renamed from: b */
    void mo1612b(String str, int i) throws RemoteException;

    /* renamed from: b */
    void mo1613b(String str, int i, int i2) throws RemoteException;

    /* renamed from: b */
    void mo1614b(List<String> list, int i, int i2) throws RemoteException;

    /* renamed from: b */
    void mo1615b(boolean z) throws RemoteException;

    /* renamed from: b */
    boolean mo1616b(int i, KeyEvent keyEvent) throws RemoteException;

    /* renamed from: c */
    void mo1617c(int i) throws RemoteException;

    /* renamed from: c */
    void mo1618c(boolean z) throws RemoteException;

    /* renamed from: c */
    boolean mo1619c() throws RemoteException;

    /* renamed from: d */
    void mo1620d(int i) throws RemoteException;

    /* renamed from: d */
    void mo1621d(boolean z) throws RemoteException;

    /* renamed from: d */
    boolean mo1622d() throws RemoteException;

    /* renamed from: e */
    void mo1623e(boolean z) throws RemoteException;

    /* renamed from: e */
    boolean mo1624e() throws RemoteException;

    /* renamed from: f */
    void mo1625f() throws RemoteException;

    /* renamed from: g */
    void mo1626g() throws RemoteException;

    /* renamed from: h */
    int mo1627h() throws RemoteException;

    /* renamed from: i */
    int mo1628i() throws RemoteException;

    /* renamed from: j */
    int mo1629j() throws RemoteException;

    /* renamed from: k */
    void mo1630k() throws RemoteException;

    /* renamed from: l */
    void mo1631l() throws RemoteException;

    /* renamed from: m */
    void mo1632m() throws RemoteException;

    /* renamed from: n */
    void mo1633n() throws RemoteException;

    /* renamed from: o */
    void mo1634o() throws RemoteException;

    /* renamed from: p */
    void mo1635p() throws RemoteException;

    /* renamed from: q */
    void mo1636q() throws RemoteException;

    /* renamed from: r */
    Bundle mo1637r() throws RemoteException;

    /* renamed from: s */
    C0519u mo1638s() throws RemoteException;
}
