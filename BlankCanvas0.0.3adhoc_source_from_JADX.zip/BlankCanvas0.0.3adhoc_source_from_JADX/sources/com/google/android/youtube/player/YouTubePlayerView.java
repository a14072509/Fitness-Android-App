package com.google.android.youtube.player;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver.OnGlobalFocusChangeListener;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.internal.C0508n;
import com.google.android.youtube.player.internal.C0518t.C0516a;
import com.google.android.youtube.player.internal.C0518t.C0517b;
import com.google.android.youtube.player.internal.C0523y;
import com.google.android.youtube.player.internal.C0685b;
import com.google.android.youtube.player.internal.C0708s;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public final class YouTubePlayerView extends ViewGroup implements Provider {
    /* renamed from: a */
    private final C0495a f71a;
    /* renamed from: b */
    private final Set<View> f72b;
    /* renamed from: c */
    private final C0496b f73c;
    /* renamed from: d */
    private C0685b f74d;
    /* renamed from: e */
    private C0708s f75e;
    /* renamed from: f */
    private View f76f;
    /* renamed from: g */
    private C0508n f77g;
    /* renamed from: h */
    private Provider f78h;
    /* renamed from: i */
    private Bundle f79i;
    /* renamed from: j */
    private OnInitializedListener f80j;
    /* renamed from: k */
    private boolean f81k;
    /* renamed from: l */
    private boolean f82l;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerView$a */
    private final class C0495a implements OnGlobalFocusChangeListener {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerView f21a;

        private C0495a(YouTubePlayerView youTubePlayerView) {
            this.f21a = youTubePlayerView;
        }

        public final void onGlobalFocusChanged(View view, View view2) {
            if (this.f21a.f75e != null && this.f21a.f72b.contains(view2) && !this.f21a.f72b.contains(view)) {
                this.f21a.f75e.m319g();
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.YouTubePlayerView$b */
    interface C0496b {
        /* renamed from: a */
        void mo1576a(YouTubePlayerView youTubePlayerView);

        /* renamed from: a */
        void mo1577a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener);
    }

    /* renamed from: com.google.android.youtube.player.YouTubePlayerView$2 */
    class C06822 implements C0517b {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerView f70a;

        C06822(YouTubePlayerView youTubePlayerView) {
            this.f70a = youTubePlayerView;
        }

        /* renamed from: a */
        public final void mo1581a(YouTubeInitializationResult youTubeInitializationResult) {
            this.f70a.m166a(youTubeInitializationResult);
            this.f70a.f74d = null;
        }
    }

    public YouTubePlayerView(Context context) {
        this(context, null);
    }

    public YouTubePlayerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubePlayerView(Context context, AttributeSet attributeSet, int i) {
        if (context instanceof YouTubeBaseActivity) {
            this(context, attributeSet, i, ((YouTubeBaseActivity) context).m25a());
            return;
        }
        throw new IllegalStateException("A YouTubePlayerView can only be created with an Activity  which extends YouTubeBaseActivity as its context.");
    }

    YouTubePlayerView(Context context, AttributeSet attributeSet, int i, C0496b c0496b) {
        super((Context) ab.m45a((Object) context, (Object) "context cannot be null"), attributeSet, i);
        this.f73c = (C0496b) ab.m45a((Object) c0496b, (Object) "listener cannot be null");
        if (getBackground() == null) {
            setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        }
        setClipToPadding(false);
        this.f77g = new C0508n(context);
        requestTransparentRegion(this.f77g);
        addView(this.f77g);
        this.f72b = new HashSet();
        this.f71a = new C0495a();
    }

    /* renamed from: a */
    private void m165a(View view) {
        Object obj;
        if (view != this.f77g) {
            if (this.f75e == null || view != this.f76f) {
                obj = null;
                if (obj != null) {
                    throw new UnsupportedOperationException("No views can be added on top of the player");
                }
            }
        }
        obj = 1;
        if (obj != null) {
            throw new UnsupportedOperationException("No views can be added on top of the player");
        }
    }

    /* renamed from: a */
    private void m166a(YouTubeInitializationResult youTubeInitializationResult) {
        this.f75e = null;
        this.f77g.m121c();
        OnInitializedListener onInitializedListener = this.f80j;
        if (onInitializedListener != null) {
            onInitializedListener.onInitializationFailure(this.f78h, youTubeInitializationResult);
            this.f80j = null;
        }
    }

    /* renamed from: a */
    static /* synthetic */ void m167a(YouTubePlayerView youTubePlayerView, Activity activity) {
        try {
            youTubePlayerView.f75e = new C0708s(youTubePlayerView.f74d, aa.m39a().mo1594a(activity, youTubePlayerView.f74d, youTubePlayerView.f81k));
            youTubePlayerView.f76f = youTubePlayerView.f75e.m307a();
            youTubePlayerView.addView(youTubePlayerView.f76f);
            youTubePlayerView.removeView(youTubePlayerView.f77g);
            youTubePlayerView.f73c.mo1576a(youTubePlayerView);
            if (youTubePlayerView.f80j != null) {
                boolean z = false;
                Bundle bundle = youTubePlayerView.f79i;
                if (bundle != null) {
                    z = youTubePlayerView.f75e.m311a(bundle);
                    youTubePlayerView.f79i = null;
                }
                youTubePlayerView.f80j.onInitializationSuccess(youTubePlayerView.f78h, youTubePlayerView.f75e, z);
                youTubePlayerView.f80j = null;
            }
        } catch (Throwable e) {
            C0523y.m135a("Error creating YouTubePlayerView", e);
            youTubePlayerView.m166a(YouTubeInitializationResult.INTERNAL_ERROR);
        }
    }

    /* renamed from: a */
    final void m177a() {
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m312b();
        }
    }

    /* renamed from: a */
    final void m178a(final Activity activity, Provider provider, String str, OnInitializedListener onInitializedListener, Bundle bundle) {
        if (this.f75e != null) {
            return;
        }
        if (this.f80j == null) {
            ab.m45a((Object) activity, (Object) "activity cannot be null");
            this.f78h = (Provider) ab.m45a((Object) provider, (Object) "provider cannot be null");
            this.f80j = (OnInitializedListener) ab.m45a((Object) onInitializedListener, (Object) "listener cannot be null");
            this.f79i = bundle;
            this.f77g.m120b();
            this.f74d = aa.m39a().mo1593a(getContext(), str, new C0516a(this) {
                /* renamed from: b */
                final /* synthetic */ YouTubePlayerView f69b;

                /* renamed from: a */
                public final void mo1579a() {
                    if (this.f69b.f74d != null) {
                        YouTubePlayerView.m167a(this.f69b, activity);
                    }
                    this.f69b.f74d = null;
                }

                /* renamed from: b */
                public final void mo1580b() {
                    if (!(this.f69b.f82l || this.f69b.f75e == null)) {
                        this.f69b.f75e.m318f();
                    }
                    this.f69b.f77g.m119a();
                    YouTubePlayerView youTubePlayerView = this.f69b;
                    if (youTubePlayerView.indexOfChild(youTubePlayerView.f77g) < 0) {
                        youTubePlayerView = this.f69b;
                        youTubePlayerView.addView(youTubePlayerView.f77g);
                        youTubePlayerView = this.f69b;
                        youTubePlayerView.removeView(youTubePlayerView.f76f);
                    }
                    this.f69b.f76f = null;
                    this.f69b.f75e = null;
                    this.f69b.f74d = null;
                }
            }, new C06822(this));
            this.f74d.mo1668e();
        }
    }

    /* renamed from: a */
    final void m179a(boolean z) {
        if (!z || VERSION.SDK_INT >= 14) {
            this.f81k = z;
            return;
        }
        C0523y.m136a("Could not enable TextureView because API level is lower than 14", new Object[0]);
        this.f81k = false;
    }

    public final void addFocusables(ArrayList<View> arrayList, int i) {
        Collection arrayList2 = new ArrayList();
        super.addFocusables(arrayList2, i);
        arrayList.addAll(arrayList2);
        this.f72b.clear();
        this.f72b.addAll(arrayList2);
    }

    public final void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        Collection arrayList2 = new ArrayList();
        super.addFocusables(arrayList2, i, i2);
        arrayList.addAll(arrayList2);
        this.f72b.clear();
        this.f72b.addAll(arrayList2);
    }

    public final void addView(View view) {
        m165a(view);
        super.addView(view);
    }

    public final void addView(View view, int i) {
        m165a(view);
        super.addView(view, i);
    }

    public final void addView(View view, int i, int i2) {
        m165a(view);
        super.addView(view, i, i2);
    }

    public final void addView(View view, int i, LayoutParams layoutParams) {
        m165a(view);
        super.addView(view, i, layoutParams);
    }

    public final void addView(View view, LayoutParams layoutParams) {
        m165a(view);
        super.addView(view, layoutParams);
    }

    /* renamed from: b */
    final void m180b() {
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m315c();
        }
    }

    /* renamed from: b */
    final void m181b(boolean z) {
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m313b(z);
            m183c(z);
        }
    }

    /* renamed from: c */
    final void m182c() {
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m316d();
        }
    }

    /* renamed from: c */
    final void m183c(boolean z) {
        this.f82l = true;
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m309a(z);
        }
    }

    public final void clearChildFocus(View view) {
        if (hasFocusable()) {
            requestFocus();
        } else {
            super.clearChildFocus(view);
        }
    }

    /* renamed from: d */
    final void m184d() {
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m317e();
        }
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (this.f75e != null) {
            if (keyEvent.getAction() == 0) {
                if (!this.f75e.m310a(keyEvent.getKeyCode(), keyEvent)) {
                    if (!super.dispatchKeyEvent(keyEvent)) {
                        return false;
                    }
                }
                return true;
            } else if (keyEvent.getAction() == 1) {
                if (!this.f75e.m314b(keyEvent.getKeyCode(), keyEvent)) {
                    if (!super.dispatchKeyEvent(keyEvent)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    /* renamed from: e */
    final Bundle m185e() {
        C0708s c0708s = this.f75e;
        return c0708s == null ? this.f79i : c0708s.m320h();
    }

    public final void focusableViewAvailable(View view) {
        super.focusableViewAvailable(view);
        this.f72b.add(view);
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        ab.m46a(str, (Object) "Developer key cannot be null or empty");
        this.f73c.mo1577a(this, str, onInitializedListener);
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnGlobalFocusChangeListener(this.f71a);
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0708s c0708s = this.f75e;
        if (c0708s != null) {
            c0708s.m308a(configuration);
        }
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalFocusChangeListener(this.f71a);
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (getChildCount() > 0) {
            getChildAt(0).layout(0, 0, i3 - i, i4 - i2);
        }
    }

    protected final void onMeasure(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            childAt.measure(i, i2);
            setMeasuredDimension(childAt.getMeasuredWidth(), childAt.getMeasuredHeight());
            return;
        }
        setMeasuredDimension(0, 0);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public final void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        this.f72b.add(view2);
    }

    public final void setClipToPadding(boolean z) {
    }

    public final void setPadding(int i, int i2, int i3, int i4) {
    }
}
