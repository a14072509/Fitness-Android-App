package com.google.android.youtube.player.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0506l.C0705a;
import com.google.android.youtube.player.internal.C0518t.C0516a;
import com.google.android.youtube.player.internal.C0518t.C0517b;
import com.google.android.youtube.player.internal.C0707r.C0752d;

/* renamed from: com.google.android.youtube.player.internal.o */
public final class C0749o extends C0707r<C0506l> implements C0685b {
    /* renamed from: b */
    private final String f122b;
    /* renamed from: c */
    private final String f123c;
    /* renamed from: d */
    private final String f124d;
    /* renamed from: e */
    private boolean f125e;

    public C0749o(Context context, String str, String str2, String str3, C0516a c0516a, C0517b c0517b) {
        super(context, c0516a, c0517b);
        this.f122b = (String) ab.m44a((Object) str);
        this.f123c = ab.m46a(str2, (Object) "callingPackage cannot be null or empty");
        this.f124d = ab.m46a(str3, (Object) "callingAppVersion cannot be null or empty");
    }

    /* renamed from: k */
    private final void m324k() {
        m305i();
        if (this.f125e) {
            throw new IllegalStateException("Connection client has been released");
        }
    }

    /* renamed from: a */
    public final IBinder mo2533a() {
        m324k();
        try {
            return ((C0506l) m306j()).mo1663a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    protected final /* synthetic */ IInterface mo2534a(IBinder iBinder) {
        return C0705a.m283a(iBinder);
    }

    /* renamed from: a */
    public final C0505k mo2535a(C0504j c0504j) {
        m324k();
        try {
            return ((C0506l) m306j()).mo1664a(c0504j);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    protected final void mo2536a(C0503i c0503i, C0752d c0752d) throws RemoteException {
        c0503i.mo1654a(c0752d, 1202, this.f123c, this.f124d, this.f122b, null);
    }

    /* renamed from: a */
    public final void mo2537a(boolean z) {
        if (m302f()) {
            try {
                ((C0506l) m306j()).mo1665a(z);
            } catch (RemoteException e) {
            }
            this.f125e = true;
        }
    }

    /* renamed from: b */
    protected final String mo2538b() {
        return "com.google.android.youtube.player.internal.IYouTubeService";
    }

    /* renamed from: c */
    protected final String mo2539c() {
        return "com.google.android.youtube.api.service.START";
    }

    /* renamed from: d */
    public final void mo1667d() {
        if (!this.f125e) {
            mo2537a(true);
        }
        super.mo1667d();
    }
}
