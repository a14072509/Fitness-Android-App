package com.google.android.youtube.player.internal;

import com.google.android.youtube.player.YouTubeInitializationResult;

/* renamed from: com.google.android.youtube.player.internal.t */
public interface C0518t {

    /* renamed from: com.google.android.youtube.player.internal.t$a */
    public interface C0516a {
        /* renamed from: a */
        void mo1579a();

        /* renamed from: b */
        void mo1580b();
    }

    /* renamed from: com.google.android.youtube.player.internal.t$b */
    public interface C0517b {
        /* renamed from: a */
        void mo1581a(YouTubeInitializationResult youTubeInitializationResult);
    }

    /* renamed from: d */
    void mo1667d();

    /* renamed from: e */
    void mo1668e();
}
