package com.google.android.youtube.player.internal;

import android.content.Context;
import android.content.res.Resources;
import java.util.Locale;
import java.util.Map;

/* renamed from: com.google.android.youtube.player.internal.m */
public final class C0507m {
    /* renamed from: a */
    public final String f26a;
    /* renamed from: b */
    public final String f27b;
    /* renamed from: c */
    public final String f28c;
    /* renamed from: d */
    public final String f29d;
    /* renamed from: e */
    public final String f30e;
    /* renamed from: f */
    public final String f31f;
    /* renamed from: g */
    public final String f32g;
    /* renamed from: h */
    public final String f33h;
    /* renamed from: i */
    public final String f34i;
    /* renamed from: j */
    public final String f35j;

    public C0507m(Context context) {
        Resources resources = context.getResources();
        Locale locale = (resources == null || resources.getConfiguration() == null || resources.getConfiguration().locale == null) ? Locale.getDefault() : resources.getConfiguration().locale;
        Map a = C0522x.m133a(locale);
        this.f26a = (String) a.get("error_initializing_player");
        this.f27b = (String) a.get("get_youtube_app_title");
        this.f28c = (String) a.get("get_youtube_app_text");
        this.f29d = (String) a.get("get_youtube_app_action");
        this.f30e = (String) a.get("enable_youtube_app_title");
        this.f31f = (String) a.get("enable_youtube_app_text");
        this.f32g = (String) a.get("enable_youtube_app_action");
        this.f33h = (String) a.get("update_youtube_app_title");
        this.f34i = (String) a.get("update_youtube_app_text");
        this.f35j = (String) a.get("update_youtube_app_action");
    }
}
