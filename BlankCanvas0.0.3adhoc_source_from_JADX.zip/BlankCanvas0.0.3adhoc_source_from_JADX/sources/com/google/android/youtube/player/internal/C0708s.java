package com.google.android.youtube.player.internal;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.KeyEvent;
import android.view.View;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.ErrorReason;
import com.google.android.youtube.player.YouTubePlayer.OnFullscreenListener;
import com.google.android.youtube.player.YouTubePlayer.PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStyle;
import com.google.android.youtube.player.YouTubePlayer.PlaylistEventListener;
import com.google.android.youtube.player.internal.C0499e.C0691a;
import com.google.android.youtube.player.internal.C0500f.C0693a;
import com.google.android.youtube.player.internal.C0501g.C0695a;
import com.google.android.youtube.player.internal.C0502h.C0697a;
import java.util.List;

/* renamed from: com.google.android.youtube.player.internal.s */
public final class C0708s implements YouTubePlayer {
    /* renamed from: a */
    private C0685b f113a;
    /* renamed from: b */
    private C0498d f114b;

    public C0708s(C0685b c0685b, C0498d c0498d) {
        this.f113a = (C0685b) ab.m45a((Object) c0685b, (Object) "connectionClient cannot be null");
        this.f114b = (C0498d) ab.m45a((Object) c0498d, (Object) "embeddedPlayer cannot be null");
    }

    /* renamed from: a */
    public final View m307a() {
        try {
            return (View) C0757v.m364a(this.f114b.mo1638s());
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: a */
    public final void m308a(Configuration configuration) {
        try {
            this.f114b.mo1598a(configuration);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: a */
    public final void m309a(boolean z) {
        try {
            this.f114b.mo1607a(z);
            this.f113a.mo2537a(z);
            this.f113a.mo1667d();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: a */
    public final boolean m310a(int i, KeyEvent keyEvent) {
        try {
            return this.f114b.mo1608a(i, keyEvent);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: a */
    public final boolean m311a(Bundle bundle) {
        try {
            return this.f114b.mo1609a(bundle);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void addFullscreenControlFlag(int i) {
        try {
            this.f114b.mo1620d(i);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: b */
    public final void m312b() {
        try {
            this.f114b.mo1632m();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: b */
    public final void m313b(boolean z) {
        try {
            this.f114b.mo1623e(z);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: b */
    public final boolean m314b(int i, KeyEvent keyEvent) {
        try {
            return this.f114b.mo1616b(i, keyEvent);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: c */
    public final void m315c() {
        try {
            this.f114b.mo1633n();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void cuePlaylist(String str) {
        cuePlaylist(str, 0, 0);
    }

    public final void cuePlaylist(String str, int i, int i2) {
        try {
            this.f114b.mo1605a(str, i, i2);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void cueVideo(String str) {
        cueVideo(str, 0);
    }

    public final void cueVideo(String str, int i) {
        try {
            this.f114b.mo1604a(str, i);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void cueVideos(List<String> list) {
        cueVideos(list, 0, 0);
    }

    public final void cueVideos(List<String> list, int i, int i2) {
        try {
            this.f114b.mo1606a((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: d */
    public final void m316d() {
        try {
            this.f114b.mo1634o();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: e */
    public final void m317e() {
        try {
            this.f114b.mo1635p();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: f */
    public final void m318f() {
        try {
            this.f114b.mo1636q();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: g */
    public final void m319g() {
        try {
            this.f114b.mo1631l();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final int getCurrentTimeMillis() {
        try {
            return this.f114b.mo1627h();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final int getDurationMillis() {
        try {
            return this.f114b.mo1628i();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final int getFullscreenControlFlags() {
        try {
            return this.f114b.mo1629j();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    /* renamed from: h */
    public final Bundle m320h() {
        try {
            return this.f114b.mo1637r();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final boolean hasNext() {
        try {
            return this.f114b.mo1622d();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final boolean hasPrevious() {
        try {
            return this.f114b.mo1624e();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final boolean isPlaying() {
        try {
            return this.f114b.mo1619c();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void loadPlaylist(String str) {
        loadPlaylist(str, 0, 0);
    }

    public final void loadPlaylist(String str, int i, int i2) {
        try {
            this.f114b.mo1613b(str, i, i2);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void loadVideo(String str) {
        loadVideo(str, 0);
    }

    public final void loadVideo(String str, int i) {
        try {
            this.f114b.mo1612b(str, i);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void loadVideos(List<String> list) {
        loadVideos(list, 0, 0);
    }

    public final void loadVideos(List<String> list, int i, int i2) {
        try {
            this.f114b.mo1614b((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void next() {
        try {
            this.f114b.mo1625f();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void pause() {
        try {
            this.f114b.mo1610b();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void play() {
        try {
            this.f114b.mo1596a();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void previous() {
        try {
            this.f114b.mo1626g();
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void release() {
        m309a(true);
    }

    public final void seekRelativeMillis(int i) {
        try {
            this.f114b.mo1611b(i);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void seekToMillis(int i) {
        try {
            this.f114b.mo1597a(i);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setFullscreen(boolean z) {
        try {
            this.f114b.mo1615b(z);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setFullscreenControlFlags(int i) {
        try {
            this.f114b.mo1617c(i);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setManageAudioFocus(boolean z) {
        try {
            this.f114b.mo1621d(z);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setOnFullscreenListener(final OnFullscreenListener onFullscreenListener) {
        try {
            this.f114b.mo1599a(new C0691a(this) {
                /* renamed from: b */
                final /* synthetic */ C0708s f134b;

                /* renamed from: a */
                public final void mo1639a(boolean z) {
                    onFullscreenListener.onFullscreen(z);
                }
            });
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setPlaybackEventListener(final PlaybackEventListener playbackEventListener) {
        try {
            this.f114b.mo1600a(new C0693a(this) {
                /* renamed from: b */
                final /* synthetic */ C0708s f140b;

                /* renamed from: a */
                public final void mo1640a() {
                    playbackEventListener.onPlaying();
                }

                /* renamed from: a */
                public final void mo1641a(int i) {
                    playbackEventListener.onSeekTo(i);
                }

                /* renamed from: a */
                public final void mo1642a(boolean z) {
                    playbackEventListener.onBuffering(z);
                }

                /* renamed from: b */
                public final void mo1643b() {
                    playbackEventListener.onPaused();
                }

                /* renamed from: c */
                public final void mo1644c() {
                    playbackEventListener.onStopped();
                }
            });
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setPlayerStateChangeListener(final PlayerStateChangeListener playerStateChangeListener) {
        try {
            this.f114b.mo1601a(new C0695a(this) {
                /* renamed from: b */
                final /* synthetic */ C0708s f138b;

                /* renamed from: a */
                public final void mo1645a() {
                    playerStateChangeListener.onLoading();
                }

                /* renamed from: a */
                public final void mo1646a(String str) {
                    playerStateChangeListener.onLoaded(str);
                }

                /* renamed from: b */
                public final void mo1647b() {
                    playerStateChangeListener.onAdStarted();
                }

                /* renamed from: b */
                public final void mo1648b(String str) {
                    ErrorReason valueOf;
                    try {
                        valueOf = ErrorReason.valueOf(str);
                    } catch (IllegalArgumentException e) {
                        valueOf = ErrorReason.UNKNOWN;
                    }
                    playerStateChangeListener.onError(valueOf);
                }

                /* renamed from: c */
                public final void mo1649c() {
                    playerStateChangeListener.onVideoStarted();
                }

                /* renamed from: d */
                public final void mo1650d() {
                    playerStateChangeListener.onVideoEnded();
                }
            });
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setPlayerStyle(PlayerStyle playerStyle) {
        try {
            this.f114b.mo1603a(playerStyle.name());
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setPlaylistEventListener(final PlaylistEventListener playlistEventListener) {
        try {
            this.f114b.mo1602a(new C0697a(this) {
                /* renamed from: b */
                final /* synthetic */ C0708s f136b;

                /* renamed from: a */
                public final void mo1651a() {
                    playlistEventListener.onPrevious();
                }

                /* renamed from: b */
                public final void mo1652b() {
                    playlistEventListener.onNext();
                }

                /* renamed from: c */
                public final void mo1653c() {
                    playlistEventListener.onPlaylistEnded();
                }
            });
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }

    public final void setShowFullscreenButton(boolean z) {
        try {
            this.f114b.mo1618c(z);
        } catch (RemoteException e) {
            throw new C0511q(e);
        }
    }
}
