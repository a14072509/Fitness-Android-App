package com.google.android.youtube.player;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.google.android.youtube.player.internal.C0523y;
import com.google.android.youtube.player.internal.ab;

public enum YouTubeInitializationResult {
    SUCCESS,
    INTERNAL_ERROR,
    UNKNOWN_ERROR,
    SERVICE_MISSING,
    SERVICE_VERSION_UPDATE_REQUIRED,
    SERVICE_DISABLED,
    SERVICE_INVALID,
    ERROR_CONNECTING_TO_SERVICE,
    CLIENT_LIBRARY_UPDATE_REQUIRED,
    NETWORK_ERROR,
    DEVELOPER_KEY_INVALID,
    INVALID_APPLICATION_SIGNATURE;

    /* renamed from: com.google.android.youtube.player.YouTubeInitializationResult$a */
    private static final class C0494a implements OnClickListener {
        /* renamed from: a */
        private final Activity f15a;
        /* renamed from: b */
        private final Intent f16b;
        /* renamed from: c */
        private final int f17c;

        public C0494a(Activity activity, Intent intent, int i) {
            this.f15a = (Activity) ab.m44a((Object) activity);
            this.f16b = (Intent) ab.m44a((Object) intent);
            this.f17c = ((Integer) ab.m44a(Integer.valueOf(i))).intValue();
        }

        public final void onClick(DialogInterface dialogInterface, int i) {
            try {
                this.f15a.startActivityForResult(this.f16b, this.f17c);
                dialogInterface.dismiss();
            } catch (Throwable e) {
                C0523y.m135a("Can't perform resolution for YouTubeInitalizationError", e);
            }
        }
    }

    public final Dialog getErrorDialog(Activity activity, int i) {
        return getErrorDialog(activity, i, null);
    }

    public final android.app.Dialog getErrorDialog(android.app.Activity r3, int r4, android.content.DialogInterface.OnCancelListener r5) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:0x0093 in {2, 5, 6, 7, 12, 13, 15, 16, 17, 18, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = new android.app.AlertDialog$Builder;
        r0.<init>(r3);
        if (r5 == 0) goto L_0x000a;
    L_0x0007:
        r0.setOnCancelListener(r5);
    L_0x000a:
        r5 = com.google.android.youtube.player.YouTubeInitializationResult.C04931.f14a;
        r1 = r2.ordinal();
        r5 = r5[r1];
        switch(r5) {
            case 1: goto L_0x0020;
            case 2: goto L_0x0017;
            case 3: goto L_0x0020;
            default: goto L_0x0015;
        };
    L_0x0015:
        r5 = 0;
        goto L_0x0028;
    L_0x0017:
        r5 = com.google.android.youtube.player.internal.C0524z.m139a(r3);
        r5 = com.google.android.youtube.player.internal.C0524z.m137a(r5);
        goto L_0x0028;
    L_0x0020:
        r5 = com.google.android.youtube.player.internal.C0524z.m139a(r3);
        r5 = com.google.android.youtube.player.internal.C0524z.m143b(r5);
    L_0x0028:
        r1 = new com.google.android.youtube.player.YouTubeInitializationResult$a;
        r1.<init>(r3, r5, r4);
        r4 = new com.google.android.youtube.player.internal.m;
        r4.<init>(r3);
        r3 = com.google.android.youtube.player.YouTubeInitializationResult.C04931.f14a;
        r5 = r2.ordinal();
        r3 = r3[r5];
        switch(r3) {
            case 1: goto L_0x007a;
            case 2: goto L_0x006b;
            case 3: goto L_0x0054;
            default: goto L_0x003d;
        };
    L_0x003d:
        r3 = new java.lang.IllegalArgumentException;
        r4 = "Unexpected errorReason: ";
        r5 = r2.name();
        r5 = java.lang.String.valueOf(r5);
        r0 = r5.length();
        if (r0 == 0) goto L_0x0089;
    L_0x004f:
        r4 = r4.concat(r5);
        goto L_0x008f;
    L_0x0054:
        r3 = r4.f33h;
        r3 = r0.setTitle(r3);
        r5 = r4.f34i;
        r3 = r3.setMessage(r5);
        r4 = r4.f35j;
    L_0x0062:
        r3 = r3.setPositiveButton(r4, r1);
        r3 = r3.create();
        return r3;
    L_0x006b:
        r3 = r4.f30e;
        r3 = r0.setTitle(r3);
        r5 = r4.f31f;
        r3 = r3.setMessage(r5);
        r4 = r4.f32g;
        goto L_0x0062;
    L_0x007a:
        r3 = r4.f27b;
        r3 = r0.setTitle(r3);
        r5 = r4.f28c;
        r3 = r3.setMessage(r5);
        r4 = r4.f29d;
        goto L_0x0062;
    L_0x0089:
        r5 = new java.lang.String;
        r5.<init>(r4);
        r4 = r5;
    L_0x008f:
        r3.<init>(r4);
        throw r3;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.YouTubeInitializationResult.getErrorDialog(android.app.Activity, int, android.content.DialogInterface$OnCancelListener):android.app.Dialog");
    }

    public final boolean isUserRecoverableError() {
        switch (this) {
            case SERVICE_MISSING:
            case SERVICE_DISABLED:
            case SERVICE_VERSION_UPDATE_REQUIRED:
                return true;
            default:
                return false;
        }
    }
}
