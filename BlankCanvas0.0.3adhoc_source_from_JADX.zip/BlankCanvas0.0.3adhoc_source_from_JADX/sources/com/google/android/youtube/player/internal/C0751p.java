package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0504j.C0701a;

/* renamed from: com.google.android.youtube.player.internal.p */
public final class C0751p extends C0684a {
    /* renamed from: a */
    private final Handler f127a = new Handler(Looper.getMainLooper());
    /* renamed from: b */
    private C0685b f128b;
    /* renamed from: c */
    private C0505k f129c;
    /* renamed from: d */
    private boolean f130d;
    /* renamed from: e */
    private boolean f131e;

    /* renamed from: com.google.android.youtube.player.internal.p$a */
    private final class C0750a extends C0701a {
        /* renamed from: a */
        final /* synthetic */ C0751p f126a;

        private C0750a(C0751p c0751p) {
            this.f126a = c0751p;
        }

        /* renamed from: a */
        public final void mo1655a(Bitmap bitmap, String str, boolean z, boolean z2) {
            final boolean z3 = z;
            final boolean z4 = z2;
            final Bitmap bitmap2 = bitmap;
            final String str2 = str;
            this.f126a.f127a.post(new Runnable(this) {
                /* renamed from: e */
                final /* synthetic */ C0750a f42e;

                public final void run() {
                    this.f42e.f126a.f130d = z3;
                    this.f42e.f126a.f131e = z4;
                    this.f42e.f126a.m191a(bitmap2, str2);
                }
            });
        }

        /* renamed from: a */
        public final void mo1656a(final String str, final boolean z, final boolean z2) {
            this.f126a.f127a.post(new Runnable(this) {
                /* renamed from: d */
                final /* synthetic */ C0750a f46d;

                public final void run() {
                    this.f46d.f126a.f130d = z;
                    this.f46d.f126a.f131e = z2;
                    this.f46d.f126a.m196b(str);
                }
            });
        }
    }

    public C0751p(C0685b c0685b, YouTubeThumbnailView youTubeThumbnailView) {
        super(youTubeThumbnailView);
        this.f128b = (C0685b) ab.m45a((Object) c0685b, (Object) "connectionClient cannot be null");
        this.f129c = c0685b.mo2535a(new C0750a());
    }

    /* renamed from: a */
    public final void mo2540a(String str) {
        try {
            this.f129c.mo1658a(str);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    public final void mo2541a(String str, int i) {
        try {
            this.f129c.mo1659a(str, i);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    protected final boolean mo2542a() {
        return super.mo2542a() && this.f129c != null;
    }

    /* renamed from: c */
    public final void mo2543c() {
        try {
            this.f129c.mo1657a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: d */
    public final void mo2544d() {
        try {
            this.f129c.mo1660b();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: e */
    public final void mo2545e() {
        try {
            this.f129c.mo1661c();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: f */
    public final boolean mo2546f() {
        return this.f131e;
    }

    /* renamed from: g */
    public final boolean mo2547g() {
        return this.f130d;
    }

    /* renamed from: h */
    public final void mo2548h() {
        try {
            this.f129c.mo1662d();
        } catch (RemoteException e) {
        }
        this.f128b.mo1667d();
        this.f129c = null;
        this.f128b = null;
    }
}
