package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayerView.C0496b;

public class YouTubeBaseActivity extends Activity {
    /* renamed from: a */
    private C0678a f10a;
    /* renamed from: b */
    private YouTubePlayerView f11b;
    /* renamed from: c */
    private int f12c;
    /* renamed from: d */
    private Bundle f13d;

    /* renamed from: com.google.android.youtube.player.YouTubeBaseActivity$a */
    private final class C0678a implements C0496b {
        /* renamed from: a */
        final /* synthetic */ YouTubeBaseActivity f59a;

        private C0678a(YouTubeBaseActivity youTubeBaseActivity) {
            this.f59a = youTubeBaseActivity;
        }

        /* renamed from: a */
        public final void mo1576a(YouTubePlayerView youTubePlayerView) {
            if (!(this.f59a.f11b == null || this.f59a.f11b == youTubePlayerView)) {
                this.f59a.f11b.m183c(true);
            }
            this.f59a.f11b = youTubePlayerView;
            if (this.f59a.f12c > 0) {
                youTubePlayerView.m177a();
            }
            if (this.f59a.f12c >= 2) {
                youTubePlayerView.m180b();
            }
        }

        /* renamed from: a */
        public final void mo1577a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            Activity activity = this.f59a;
            youTubePlayerView.m178a(activity, youTubePlayerView, str, onInitializedListener, activity.f13d);
            this.f59a.f13d = null;
        }
    }

    /* renamed from: a */
    final C0496b m25a() {
        return this.f10a;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f10a = new C0678a();
        this.f13d = bundle != null ? bundle.getBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE") : null;
    }

    protected void onDestroy() {
        YouTubePlayerView youTubePlayerView = this.f11b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m181b(isFinishing());
        }
        super.onDestroy();
    }

    protected void onPause() {
        this.f12c = 1;
        YouTubePlayerView youTubePlayerView = this.f11b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m182c();
        }
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        this.f12c = 2;
        YouTubePlayerView youTubePlayerView = this.f11b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m180b();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        YouTubePlayerView youTubePlayerView = this.f11b;
        bundle.putBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE", youTubePlayerView != null ? youTubePlayerView.m185e() : this.f13d);
    }

    protected void onStart() {
        super.onStart();
        this.f12c = 1;
        YouTubePlayerView youTubePlayerView = this.f11b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m177a();
        }
    }

    protected void onStop() {
        this.f12c = 0;
        YouTubePlayerView youTubePlayerView = this.f11b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m184d();
        }
        super.onStop();
    }
}
