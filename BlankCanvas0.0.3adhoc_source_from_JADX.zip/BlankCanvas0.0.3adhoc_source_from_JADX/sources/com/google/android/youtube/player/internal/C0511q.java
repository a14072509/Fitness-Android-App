package com.google.android.youtube.player.internal;

import android.os.RemoteException;

/* renamed from: com.google.android.youtube.player.internal.q */
public final class C0511q extends RuntimeException {
    public C0511q(RemoteException remoteException) {
        super(remoteException);
    }
}
