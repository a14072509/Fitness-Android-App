package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0518t.C0516a;
import com.google.android.youtube.player.internal.C0518t.C0517b;
import com.google.android.youtube.player.internal.C0521w.C0520a;

public final class ac extends aa {
    /* renamed from: a */
    public final C0684a mo1592a(C0685b c0685b, YouTubeThumbnailView youTubeThumbnailView) {
        return new C0751p(c0685b, youTubeThumbnailView);
    }

    /* renamed from: a */
    public final C0685b mo1593a(Context context, String str, C0516a c0516a, C0517b c0517b) {
        return new C0749o(context, str, context.getPackageName(), C0524z.m146d(context), c0516a, c0517b);
    }

    /* renamed from: a */
    public final C0498d mo1594a(Activity activity, C0685b c0685b, boolean z) throws C0520a {
        return C0521w.m132a(activity, c0685b.mo2533a(), z);
    }
}
