package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0504j.C0701a.C0700a;
import com.google.android.youtube.player.internal.C0505k.C0703a;

/* renamed from: com.google.android.youtube.player.internal.l */
public interface C0506l extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.l$a */
    public static abstract class C0705a extends Binder implements C0506l {

        /* renamed from: com.google.android.youtube.player.internal.l$a$a */
        private static class C0704a implements C0506l {
            /* renamed from: a */
            private IBinder f98a;

            C0704a(IBinder iBinder) {
                this.f98a = iBinder;
            }

            /* renamed from: a */
            public final IBinder mo1663a() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    this.f98a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    IBinder readStrongBinder = obtain2.readStrongBinder();
                    return readStrongBinder;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final C0505k mo1664a(C0504j c0504j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    obtain.writeStrongBinder(c0504j != null ? c0504j.asBinder() : null);
                    this.f98a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    C0505k a = C0703a.m279a(obtain2.readStrongBinder());
                    return a;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo1665a(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    obtain.writeInt(z ? 1 : 0);
                    this.f98a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f98a;
            }
        }

        /* renamed from: a */
        public static C0506l m283a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.IYouTubeService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0506l)) ? new C0704a(iBinder) : (C0506l) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1598968902) {
                IBinder a;
                switch (i) {
                    case 1:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                        a = mo1663a();
                        parcel2.writeNoException();
                        parcel2.writeStrongBinder(a);
                        return true;
                    case 2:
                        C0504j c0504j;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                        a = parcel.readStrongBinder();
                        IBinder iBinder = null;
                        if (a == null) {
                            c0504j = null;
                        } else {
                            IInterface queryLocalInterface = a.queryLocalInterface("com.google.android.youtube.player.internal.IThumbnailLoaderClient");
                            c0504j = (queryLocalInterface == null || !(queryLocalInterface instanceof C0504j)) ? new C0700a(a) : (C0504j) queryLocalInterface;
                        }
                        C0505k a2 = mo1664a(c0504j);
                        parcel2.writeNoException();
                        if (a2 != null) {
                            iBinder = a2.asBinder();
                        }
                        parcel2.writeStrongBinder(iBinder);
                        return true;
                    case 3:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                        mo1665a(parcel.readInt() != 0);
                        parcel2.writeNoException();
                        return true;
                    default:
                        return super.onTransact(i, parcel, parcel2, i2);
                }
            }
            parcel2.writeString("com.google.android.youtube.player.internal.IYouTubeService");
            return true;
        }
    }

    /* renamed from: a */
    IBinder mo1663a() throws RemoteException;

    /* renamed from: a */
    C0505k mo1664a(C0504j c0504j) throws RemoteException;

    /* renamed from: a */
    void mo1665a(boolean z) throws RemoteException;
}
