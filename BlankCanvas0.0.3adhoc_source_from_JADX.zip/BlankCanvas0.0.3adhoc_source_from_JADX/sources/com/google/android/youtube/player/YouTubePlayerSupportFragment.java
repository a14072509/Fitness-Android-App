package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.C0496b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerSupportFragment extends Fragment implements Provider {
    /* renamed from: a */
    private final C0680a f116a = new C0680a();
    /* renamed from: b */
    private Bundle f117b;
    /* renamed from: c */
    private YouTubePlayerView f118c;
    /* renamed from: d */
    private String f119d;
    /* renamed from: e */
    private OnInitializedListener f120e;
    /* renamed from: f */
    private boolean f121f;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerSupportFragment$a */
    private final class C0680a implements C0496b {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerSupportFragment f67a;

        private C0680a(YouTubePlayerSupportFragment youTubePlayerSupportFragment) {
            this.f67a = youTubePlayerSupportFragment;
        }

        /* renamed from: a */
        public final void mo1576a(YouTubePlayerView youTubePlayerView) {
        }

        /* renamed from: a */
        public final void mo1577a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            YouTubePlayerSupportFragment youTubePlayerSupportFragment = this.f67a;
            youTubePlayerSupportFragment.initialize(str, youTubePlayerSupportFragment.f120e);
        }
    }

    /* renamed from: a */
    private void m323a() {
        YouTubePlayerView youTubePlayerView = this.f118c;
        if (youTubePlayerView != null && this.f120e != null) {
            youTubePlayerView.m179a(this.f121f);
            this.f118c.m178a(getActivity(), this, this.f119d, this.f120e, this.f117b);
            this.f117b = null;
            this.f120e = null;
        }
    }

    public static YouTubePlayerSupportFragment newInstance() {
        return new YouTubePlayerSupportFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f119d = ab.m46a(str, (Object) "Developer key cannot be null or empty");
        this.f120e = onInitializedListener;
        m323a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f117b = bundle != null ? bundle.getBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f118c = new YouTubePlayerView(getActivity(), null, 0, this.f116a);
        m323a();
        return this.f118c;
    }

    public void onDestroy() {
        if (this.f118c != null) {
            boolean z;
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f118c;
            if (activity != null) {
                if (!activity.isFinishing()) {
                    z = false;
                    youTubePlayerView.m181b(z);
                }
            }
            z = true;
            youTubePlayerView.m181b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f118c.m183c(getActivity().isFinishing());
        this.f118c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f118c.m182c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f118c.m180b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        YouTubePlayerView youTubePlayerView = this.f118c;
        bundle.putBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE", youTubePlayerView != null ? youTubePlayerView.m185e() : this.f117b);
    }

    public void onStart() {
        super.onStart();
        this.f118c.m177a();
    }

    public void onStop() {
        this.f118c.m184d();
        super.onStop();
    }
}
