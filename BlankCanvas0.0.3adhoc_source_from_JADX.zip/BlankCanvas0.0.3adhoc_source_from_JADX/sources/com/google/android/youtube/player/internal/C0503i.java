package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0497c.C0687a.C0686a;

/* renamed from: com.google.android.youtube.player.internal.i */
public interface C0503i extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.i$a */
    public static abstract class C0699a extends Binder implements C0503i {

        /* renamed from: com.google.android.youtube.player.internal.i$a$a */
        private static class C0698a implements C0503i {
            /* renamed from: a */
            private IBinder f95a;

            C0698a(IBinder iBinder) {
                this.f95a = iBinder;
            }

            /* renamed from: a */
            public final void mo1654a(C0497c c0497c, int i, String str, String str2, String str3, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IServiceBroker");
                    obtain.writeStrongBinder(c0497c != null ? c0497c.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f95a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f95a;
            }
        }

        /* renamed from: a */
        public static C0503i m270a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.IServiceBroker");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0503i)) ? new C0698a(iBinder) : (C0503i) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 1) {
                C0497c c0497c;
                parcel.enforceInterface("com.google.android.youtube.player.internal.IServiceBroker");
                IBinder readStrongBinder = parcel.readStrongBinder();
                Bundle bundle = null;
                if (readStrongBinder == null) {
                    c0497c = null;
                } else {
                    IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IConnectionCallbacks");
                    c0497c = (queryLocalInterface == null || !(queryLocalInterface instanceof C0497c)) ? new C0686a(readStrongBinder) : (C0497c) queryLocalInterface;
                }
                int readInt = parcel.readInt();
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                String readString3 = parcel.readString();
                if (parcel.readInt() != 0) {
                    bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                }
                mo1654a(c0497c, readInt, readString, readString2, readString3, bundle);
                parcel2.writeNoException();
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString("com.google.android.youtube.player.internal.IServiceBroker");
                return true;
            }
        }
    }

    /* renamed from: a */
    void mo1654a(C0497c c0497c, int i, String str, String str2, String str3, Bundle bundle) throws RemoteException;
}
