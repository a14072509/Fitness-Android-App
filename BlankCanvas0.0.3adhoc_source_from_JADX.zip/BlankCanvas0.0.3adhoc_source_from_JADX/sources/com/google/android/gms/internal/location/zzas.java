package com.google.android.gms.internal.location;

import android.app.PendingIntent;
import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.RemoteException;
import com.google.android.gms.common.api.internal.ListenerHolder;
import com.google.android.gms.common.api.internal.ListenerHolder.ListenerKey;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.zzu;
import com.google.android.gms.location.zzx;
import java.util.HashMap;
import java.util.Map;

public final class zzas {
    private final zzbj<zzao> zzcb;
    private final Context zzcu;
    private ContentProviderClient zzcv = null;
    private boolean zzcw = false;
    private final Map<ListenerKey<LocationListener>, zzax> zzcx = new HashMap();
    private final Map<ListenerKey<Object>, zzaw> zzcy = new HashMap();
    private final Map<ListenerKey<LocationCallback>, zzat> zzcz = new HashMap();

    public zzas(Context context, zzbj<zzao> zzbj) {
        this.zzcu = context;
        this.zzcb = zzbj;
    }

    private final zzax zza(ListenerHolder<LocationListener> listenerHolder) {
        zzax zzax;
        synchronized (this.zzcx) {
            zzax = (zzax) this.zzcx.get(listenerHolder.getListenerKey());
            if (zzax == null) {
                zzax = new zzax(listenerHolder);
            }
            this.zzcx.put(listenerHolder.getListenerKey(), zzax);
        }
        return zzax;
    }

    private final zzat zzb(ListenerHolder<LocationCallback> listenerHolder) {
        zzat zzat;
        synchronized (this.zzcz) {
            zzat = (zzat) this.zzcz.get(listenerHolder.getListenerKey());
            if (zzat == null) {
                zzat = new zzat(listenerHolder);
            }
            this.zzcz.put(listenerHolder.getListenerKey(), zzat);
        }
        return zzat;
    }

    public final Location getLastLocation() throws RemoteException {
        this.zzcb.checkConnected();
        return ((zzao) this.zzcb.getService()).zza(this.zzcu.getPackageName());
    }

    public final void removeAllListeners() throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:45:0x00a4 in {8, 19, 30, 33, 36, 40, 44} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.zzcx;
        monitor-enter(r0);
        r1 = r7.zzcx;	 Catch:{ all -> 0x00a1 }
        r1 = r1.values();	 Catch:{ all -> 0x00a1 }
        r1 = r1.iterator();	 Catch:{ all -> 0x00a1 }
    L_0x000d:
        r2 = r1.hasNext();	 Catch:{ all -> 0x00a1 }
        r3 = 0;	 Catch:{ all -> 0x00a1 }
        if (r2 == 0) goto L_0x002c;	 Catch:{ all -> 0x00a1 }
    L_0x0014:
        r2 = r1.next();	 Catch:{ all -> 0x00a1 }
        r2 = (com.google.android.gms.internal.location.zzax) r2;	 Catch:{ all -> 0x00a1 }
        if (r2 == 0) goto L_0x000d;	 Catch:{ all -> 0x00a1 }
    L_0x001c:
        r4 = r7.zzcb;	 Catch:{ all -> 0x00a1 }
        r4 = r4.getService();	 Catch:{ all -> 0x00a1 }
        r4 = (com.google.android.gms.internal.location.zzao) r4;	 Catch:{ all -> 0x00a1 }
        r2 = com.google.android.gms.internal.location.zzbf.zza(r2, r3);	 Catch:{ all -> 0x00a1 }
        r4.zza(r2);	 Catch:{ all -> 0x00a1 }
        goto L_0x000d;	 Catch:{ all -> 0x00a1 }
    L_0x002c:
        r1 = r7.zzcx;	 Catch:{ all -> 0x00a1 }
        r1.clear();	 Catch:{ all -> 0x00a1 }
        monitor-exit(r0);	 Catch:{ all -> 0x00a1 }
        r1 = r7.zzcz;
        monitor-enter(r1);
        r0 = r7.zzcz;	 Catch:{ all -> 0x009e }
        r0 = r0.values();	 Catch:{ all -> 0x009e }
        r0 = r0.iterator();	 Catch:{ all -> 0x009e }
    L_0x003f:
        r2 = r0.hasNext();	 Catch:{ all -> 0x009e }
        if (r2 == 0) goto L_0x005d;	 Catch:{ all -> 0x009e }
    L_0x0045:
        r2 = r0.next();	 Catch:{ all -> 0x009e }
        r2 = (com.google.android.gms.internal.location.zzat) r2;	 Catch:{ all -> 0x009e }
        if (r2 == 0) goto L_0x003f;	 Catch:{ all -> 0x009e }
    L_0x004d:
        r4 = r7.zzcb;	 Catch:{ all -> 0x009e }
        r4 = r4.getService();	 Catch:{ all -> 0x009e }
        r4 = (com.google.android.gms.internal.location.zzao) r4;	 Catch:{ all -> 0x009e }
        r2 = com.google.android.gms.internal.location.zzbf.zza(r2, r3);	 Catch:{ all -> 0x009e }
        r4.zza(r2);	 Catch:{ all -> 0x009e }
        goto L_0x003f;	 Catch:{ all -> 0x009e }
    L_0x005d:
        r0 = r7.zzcz;	 Catch:{ all -> 0x009e }
        r0.clear();	 Catch:{ all -> 0x009e }
        monitor-exit(r1);	 Catch:{ all -> 0x009e }
        r0 = r7.zzcy;
        monitor-enter(r0);
        r1 = r7.zzcy;	 Catch:{ all -> 0x009b }
        r1 = r1.values();	 Catch:{ all -> 0x009b }
        r1 = r1.iterator();	 Catch:{ all -> 0x009b }
    L_0x0070:
        r2 = r1.hasNext();	 Catch:{ all -> 0x009b }
        if (r2 == 0) goto L_0x0094;	 Catch:{ all -> 0x009b }
    L_0x0076:
        r2 = r1.next();	 Catch:{ all -> 0x009b }
        r2 = (com.google.android.gms.internal.location.zzaw) r2;	 Catch:{ all -> 0x009b }
        if (r2 == 0) goto L_0x0070;	 Catch:{ all -> 0x009b }
    L_0x007e:
        r4 = r7.zzcb;	 Catch:{ all -> 0x009b }
        r4 = r4.getService();	 Catch:{ all -> 0x009b }
        r4 = (com.google.android.gms.internal.location.zzao) r4;	 Catch:{ all -> 0x009b }
        r5 = new com.google.android.gms.internal.location.zzo;	 Catch:{ all -> 0x009b }
        r6 = 2;	 Catch:{ all -> 0x009b }
        r2 = r2.asBinder();	 Catch:{ all -> 0x009b }
        r5.<init>(r6, r3, r2, r3);	 Catch:{ all -> 0x009b }
        r4.zza(r5);	 Catch:{ all -> 0x009b }
        goto L_0x0070;	 Catch:{ all -> 0x009b }
    L_0x0094:
        r1 = r7.zzcy;	 Catch:{ all -> 0x009b }
        r1.clear();	 Catch:{ all -> 0x009b }
        monitor-exit(r0);	 Catch:{ all -> 0x009b }
        return;	 Catch:{ all -> 0x009b }
    L_0x009b:
        r1 = move-exception;	 Catch:{ all -> 0x009b }
        monitor-exit(r0);	 Catch:{ all -> 0x009b }
        throw r1;
    L_0x009e:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x009e }
        throw r0;
    L_0x00a1:
        r1 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x00a1 }
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.location.zzas.removeAllListeners():void");
    }

    public final LocationAvailability zza() throws RemoteException {
        this.zzcb.checkConnected();
        return ((zzao) this.zzcb.getService()).zzb(this.zzcu.getPackageName());
    }

    public final void zza(PendingIntent pendingIntent, zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(new zzbf(2, null, null, pendingIntent, null, zzaj != null ? zzaj.asBinder() : null));
    }

    public final void zza(Location location) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(location);
    }

    public final void zza(ListenerKey<LocationListener> listenerKey, zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        Preconditions.checkNotNull(listenerKey, "Invalid null listener key");
        synchronized (this.zzcx) {
            zzx zzx = (zzax) this.zzcx.remove(listenerKey);
            if (zzx != null) {
                zzx.release();
                ((zzao) this.zzcb.getService()).zza(zzbf.zza(zzx, zzaj));
            }
        }
    }

    public final void zza(zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(zzaj);
    }

    public final void zza(zzbd zzbd, ListenerHolder<LocationCallback> listenerHolder, zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(new zzbf(1, zzbd, null, null, zzb(listenerHolder).asBinder(), zzaj != null ? zzaj.asBinder() : null));
    }

    public final void zza(LocationRequest locationRequest, PendingIntent pendingIntent, zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(new zzbf(1, zzbd.zza(locationRequest), null, pendingIntent, null, zzaj != null ? zzaj.asBinder() : null));
    }

    public final void zza(LocationRequest locationRequest, ListenerHolder<LocationListener> listenerHolder, zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(new zzbf(1, zzbd.zza(locationRequest), zza((ListenerHolder) listenerHolder).asBinder(), null, null, zzaj != null ? zzaj.asBinder() : null));
    }

    public final void zza(boolean z) throws RemoteException {
        this.zzcb.checkConnected();
        ((zzao) this.zzcb.getService()).zza(z);
        this.zzcw = z;
    }

    public final void zzb() throws RemoteException {
        if (this.zzcw) {
            zza(false);
        }
    }

    public final void zzb(ListenerKey<LocationCallback> listenerKey, zzaj zzaj) throws RemoteException {
        this.zzcb.checkConnected();
        Preconditions.checkNotNull(listenerKey, "Invalid null listener key");
        synchronized (this.zzcz) {
            zzu zzu = (zzat) this.zzcz.remove(listenerKey);
            if (zzu != null) {
                zzu.release();
                ((zzao) this.zzcb.getService()).zza(zzbf.zza(zzu, zzaj));
            }
        }
    }
}
