package com.google.android.gms.internal.location;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api$AnyClient;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.zzal;

final class zzah extends zzai {
    private final /* synthetic */ zzal zzct;

    zzah(zzaf zzaf, GoogleApiClient googleApiClient, zzal zzal) {
        this.zzct = zzal;
        super(googleApiClient);
    }

    protected final /* synthetic */ void doExecute(Api$AnyClient api$AnyClient) throws RemoteException {
        ((zzaz) api$AnyClient).zza(this.zzct, this);
    }
}
