package com.google.android.gms.internal.location;

import android.app.PendingIntent;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api$AnyClient;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzaa extends zzab {
    private final /* synthetic */ PendingIntent zzbx;

    zzaa(zzq zzq, GoogleApiClient googleApiClient, PendingIntent pendingIntent) {
        this.zzbx = pendingIntent;
        super(googleApiClient);
    }

    protected final /* synthetic */ void doExecute(Api$AnyClient api$AnyClient) throws RemoteException {
        ((zzaz) api$AnyClient).zza(this.zzbx, new zzac(this));
    }
}
