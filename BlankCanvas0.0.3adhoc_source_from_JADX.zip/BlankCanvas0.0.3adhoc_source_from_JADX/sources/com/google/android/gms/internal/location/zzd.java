package com.google.android.gms.internal.location;

interface zzd {
}
