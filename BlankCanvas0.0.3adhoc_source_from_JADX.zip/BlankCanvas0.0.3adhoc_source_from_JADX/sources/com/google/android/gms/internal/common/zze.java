package com.google.android.gms.internal.common;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;

public class zze extends Handler {
    private static volatile zzf zzit = null;

    public zze(Looper looper) {
        super(looper);
    }

    public zze(Looper looper, Callback callback) {
        super(looper, callback);
    }
}
