package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.base.zab;
import com.google.android.gms.internal.base.zac;

public abstract class zae extends zab implements zad {
    public zae() {
        super("com.google.android.gms.signin.internal.ISignInCallbacks");
    }

    protected boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        switch (i) {
            case 3:
                zaa((ConnectionResult) zac.zaa(parcel, ConnectionResult.CREATOR), (zaa) zac.zaa(parcel, zaa.CREATOR));
                break;
            case 4:
                zag((Status) zac.zaa(parcel, Status.CREATOR));
                break;
            case 6:
                zah((Status) zac.zaa(parcel, Status.CREATOR));
                break;
            case 7:
                zaa((Status) zac.zaa(parcel, Status.CREATOR), (GoogleSignInAccount) zac.zaa(parcel, GoogleSignInAccount.CREATOR));
                break;
            case 8:
                zab((zaj) zac.zaa(parcel, zaj.CREATOR));
                break;
            default:
                return false;
        }
        parcel2.writeNoException();
        return true;
    }
}
