package com.google.android.gms.signin;

import com.google.android.gms.common.api.Api$Client;
import com.google.android.gms.common.internal.IAccountAccessor;

public interface zad extends Api$Client {
    void connect();

    void zaa(IAccountAccessor iAccountAccessor, boolean z);

    void zaa(com.google.android.gms.signin.internal.zad zad);

    void zacv();
}
