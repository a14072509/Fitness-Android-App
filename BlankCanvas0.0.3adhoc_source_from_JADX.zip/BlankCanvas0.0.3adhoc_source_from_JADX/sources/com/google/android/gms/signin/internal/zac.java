package com.google.android.gms.signin.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;

public class zac extends zae {
    public final void zaa(ConnectionResult connectionResult, zaa zaa) throws RemoteException {
    }

    public final void zag(Status status) throws RemoteException {
    }

    public final void zah(Status status) throws RemoteException {
    }

    public final void zaa(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    public void zab(zaj zaj) throws RemoteException {
    }
}
