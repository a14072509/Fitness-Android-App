package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.internal.GoogleApiManager.zaa;

final class zabk implements Runnable {
    private final /* synthetic */ zaa zaix;

    zabk(zaa zaa) {
        this.zaix = zaa;
    }

    public final void run() {
        this.zaix.zabh();
    }
}
