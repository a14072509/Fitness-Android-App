package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.BinderThread;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import com.google.android.gms.common.internal.IGmsCallbacks.zza;
import com.google.android.gms.common.util.VisibleForTesting;

@VisibleForTesting
public final class BaseGmsClient$zzd extends zza {
    private BaseGmsClient zzcv;
    private final int zzcw;

    public BaseGmsClient$zzd(@NonNull BaseGmsClient baseGmsClient, int i) {
        this.zzcv = baseGmsClient;
        this.zzcw = i;
    }

    @BinderThread
    public final void zza(int i, @Nullable Bundle bundle) {
        Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
    }

    @BinderThread
    public final void onPostInitComplete(int i, @NonNull IBinder iBinder, @Nullable Bundle bundle) {
        Preconditions.checkNotNull(this.zzcv, "onPostInitComplete can be called only once per call to getRemoteService");
        this.zzcv.onPostInitHandler(i, iBinder, bundle, this.zzcw);
        this.zzcv = 0;
    }

    @BinderThread
    public final void zza(int i, @NonNull IBinder iBinder, @NonNull zzb zzb) {
        Preconditions.checkNotNull(this.zzcv, "onPostInitCompleteWithConnectionInfo can be called only once per call togetRemoteService");
        Preconditions.checkNotNull(zzb);
        BaseGmsClient.zza(this.zzcv, zzb);
        onPostInitComplete(i, iBinder, zzb.zzcz);
    }
}
