package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;

public interface zar extends ConnectionCallbacks {
    void zaa(ConnectionResult connectionResult, Api<?> api, boolean z);
}
