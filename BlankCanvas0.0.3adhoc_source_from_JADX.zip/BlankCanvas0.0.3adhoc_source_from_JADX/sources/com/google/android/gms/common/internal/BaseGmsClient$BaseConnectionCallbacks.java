package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.support.annotation.Nullable;
import com.google.android.gms.common.annotation.KeepForSdk;

@KeepForSdk
public interface BaseGmsClient$BaseConnectionCallbacks {
    @KeepForSdk
    void onConnected(@Nullable Bundle bundle);

    @KeepForSdk
    void onConnectionSuspended(int i);
}
