package com.google.android.gms.common.api.internal;

import com.google.android.gms.signin.internal.zaj;

final class zacg implements Runnable {
    private final /* synthetic */ zaj zagq;
    private final /* synthetic */ zace zakj;

    zacg(zace zace, zaj zaj) {
        this.zakj = zace;
        this.zagq = zaj;
    }

    public final void run() {
        this.zakj.zac(this.zagq);
    }
}
