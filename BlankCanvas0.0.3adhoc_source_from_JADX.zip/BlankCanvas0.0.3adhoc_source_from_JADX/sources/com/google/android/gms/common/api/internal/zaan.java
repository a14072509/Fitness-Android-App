package com.google.android.gms.common.api.internal;

import android.support.annotation.WorkerThread;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api$Client;
import com.google.android.gms.common.internal.BaseGmsClient$ConnectionProgressReportCallbacks;
import com.google.android.gms.common.internal.GoogleApiAvailabilityCache;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

final class zaan extends zaau {
    final /* synthetic */ zaak zagi;
    private final Map<Api$Client, zaam> zagk;

    public zaan(zaak zaak, Map<Api$Client, zaam> map) {
        this.zagi = zaak;
        super(zaak);
        this.zagk = map;
    }

    @WorkerThread
    public final void zaan() {
        GoogleApiAvailabilityCache googleApiAvailabilityCache = new GoogleApiAvailabilityCache(this.zagi.zaex);
        List arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        for (Api$Client api$Client : this.zagk.keySet()) {
            if (!api$Client.requiresGooglePlayServices() || ((zaam) this.zagk.get(api$Client)).zaeb) {
                arrayList2.add(api$Client);
            } else {
                arrayList.add(api$Client);
            }
        }
        int i = -1;
        int i2 = 0;
        Object obj;
        if (arrayList.isEmpty()) {
            ArrayList arrayList3 = (ArrayList) arrayList2;
            int size = arrayList3.size();
            while (i2 < size) {
                obj = arrayList3.get(i2);
                i2++;
                i = googleApiAvailabilityCache.getClientAvailability(this.zagi.mContext, (Api$Client) obj);
                if (i == 0) {
                    break;
                }
            }
        } else {
            ArrayList arrayList4 = (ArrayList) arrayList;
            int size2 = arrayList4.size();
            while (i2 < size2) {
                obj = arrayList4.get(i2);
                i2++;
                i = googleApiAvailabilityCache.getClientAvailability(this.zagi.mContext, (Api$Client) obj);
                if (i != 0) {
                    break;
                }
            }
        }
        if (i != 0) {
            this.zagi.zafs.zaa(new zaao(this, this.zagi, new ConnectionResult(i, null)));
            return;
        }
        if (this.zagi.zagc) {
            this.zagi.zaga.connect();
        }
        for (Api$Client api$Client2 : this.zagk.keySet()) {
            BaseGmsClient$ConnectionProgressReportCallbacks baseGmsClient$ConnectionProgressReportCallbacks = (BaseGmsClient$ConnectionProgressReportCallbacks) this.zagk.get(api$Client2);
            if (api$Client2.requiresGooglePlayServices()) {
                if (googleApiAvailabilityCache.getClientAvailability(this.zagi.mContext, api$Client2) != 0) {
                    this.zagi.zafs.zaa(new zaap(this, this.zagi, baseGmsClient$ConnectionProgressReportCallbacks));
                }
            }
            api$Client2.connect(baseGmsClient$ConnectionProgressReportCallbacks);
        }
    }
}
