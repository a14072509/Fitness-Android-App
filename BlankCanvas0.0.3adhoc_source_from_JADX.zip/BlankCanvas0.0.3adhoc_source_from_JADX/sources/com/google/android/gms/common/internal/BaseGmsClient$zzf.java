package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.support.annotation.BinderThread;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;

protected final class BaseGmsClient$zzf extends BaseGmsClient$zza {
    private final /* synthetic */ BaseGmsClient zzcs;
    private final IBinder zzcx;

    @BinderThread
    public BaseGmsClient$zzf(BaseGmsClient baseGmsClient, int i, IBinder iBinder, Bundle bundle) {
        this.zzcs = baseGmsClient;
        super(baseGmsClient, i, bundle);
        this.zzcx = iBinder;
    }

    protected final void zza(ConnectionResult connectionResult) {
        if (BaseGmsClient.zzg(this.zzcs) != null) {
            BaseGmsClient.zzg(this.zzcs).onConnectionFailed(connectionResult);
        }
        this.zzcs.onConnectionFailed(connectionResult);
    }

    protected final boolean zzm() {
        try {
            String interfaceDescriptor = this.zzcx.getInterfaceDescriptor();
            if (this.zzcs.getServiceDescriptor().equals(interfaceDescriptor)) {
                IInterface createServiceInterface = this.zzcs.createServiceInterface(this.zzcx);
                if (createServiceInterface != null) {
                    if (!BaseGmsClient.zza(this.zzcs, 2, 4, createServiceInterface)) {
                        if (BaseGmsClient.zza(this.zzcs, 3, 4, createServiceInterface)) {
                        }
                    }
                    BaseGmsClient.zza(this.zzcs, null);
                    Bundle connectionHint = this.zzcs.getConnectionHint();
                    if (BaseGmsClient.zze(this.zzcs) != null) {
                        BaseGmsClient.zze(this.zzcs).onConnected(connectionHint);
                    }
                    return true;
                }
                return false;
            }
            String serviceDescriptor = this.zzcs.getServiceDescriptor();
            StringBuilder stringBuilder = new StringBuilder((String.valueOf(serviceDescriptor).length() + 34) + String.valueOf(interfaceDescriptor).length());
            stringBuilder.append("service descriptor mismatch: ");
            stringBuilder.append(serviceDescriptor);
            stringBuilder.append(" vs. ");
            stringBuilder.append(interfaceDescriptor);
            Log.e("GmsClient", stringBuilder.toString());
            return false;
        } catch (RemoteException e) {
            Log.w("GmsClient", "service probably died");
            return false;
        }
    }
}
