package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.support.annotation.BinderThread;
import android.support.annotation.Nullable;
import com.google.android.gms.common.ConnectionResult;

protected final class BaseGmsClient$zzg extends BaseGmsClient$zza {
    private final /* synthetic */ BaseGmsClient zzcs;

    @BinderThread
    public BaseGmsClient$zzg(BaseGmsClient baseGmsClient, @Nullable int i, Bundle bundle) {
        this.zzcs = baseGmsClient;
        super(baseGmsClient, i, null);
    }

    protected final void zza(ConnectionResult connectionResult) {
        this.zzcs.zzce.onReportServiceBinding(connectionResult);
        this.zzcs.onConnectionFailed(connectionResult);
    }

    protected final boolean zzm() {
        this.zzcs.zzce.onReportServiceBinding(ConnectionResult.RESULT_SUCCESS);
        return true;
    }
}
