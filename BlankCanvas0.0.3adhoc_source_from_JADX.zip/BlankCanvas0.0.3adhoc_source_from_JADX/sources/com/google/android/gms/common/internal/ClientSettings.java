package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.view.View;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient.Builder;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.signin.SignInOptions;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;

@KeepForSdk
@VisibleForTesting
public final class ClientSettings {
    public static final String KEY_CLIENT_SESSION_ID = "com.google.android.gms.common.internal.ClientSettings.sessionId";
    private final Set<Scope> zabr;
    private final int zabt;
    private final View zabu;
    private final String zabv;
    private final String zabw;
    private final Set<Scope> zaoa;
    private final Map<Api<?>, ClientSettings$OptionalApiSettings> zaob;
    private final SignInOptions zaoc;
    private Integer zaod;
    private final Account zax;

    @KeepForSdk
    public static ClientSettings createDefault(Context context) {
        return new Builder(context).buildClientSettings();
    }

    public ClientSettings(Account account, Set<Scope> set, Map<Api<?>, ClientSettings$OptionalApiSettings> map, int i, View view, String str, String str2, SignInOptions signInOptions) {
        this.zax = account;
        this.zabr = set == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(set);
        if (map == null) {
            map = Collections.EMPTY_MAP;
        }
        this.zaob = map;
        this.zabu = view;
        this.zabt = i;
        this.zabv = str;
        this.zabw = str2;
        this.zaoc = signInOptions;
        account = new HashSet(this.zabr);
        set = this.zaob.values().iterator();
        while (set.hasNext() != null) {
            account.addAll(((ClientSettings$OptionalApiSettings) set.next()).mScopes);
        }
        this.zaoa = Collections.unmodifiableSet(account);
    }

    @KeepForSdk
    @Deprecated
    @Nullable
    public final String getAccountName() {
        Account account = this.zax;
        return account != null ? account.name : null;
    }

    @KeepForSdk
    @Nullable
    public final Account getAccount() {
        return this.zax;
    }

    @KeepForSdk
    public final Account getAccountOrDefault() {
        Account account = this.zax;
        if (account != null) {
            return account;
        }
        return new Account("<<default account>>", AccountType.GOOGLE);
    }

    @KeepForSdk
    public final int getGravityForPopups() {
        return this.zabt;
    }

    @KeepForSdk
    public final Set<Scope> getRequiredScopes() {
        return this.zabr;
    }

    @KeepForSdk
    public final Set<Scope> getAllRequestedScopes() {
        return this.zaoa;
    }

    public final Map<Api<?>, ClientSettings$OptionalApiSettings> getOptionalApiSettings() {
        return this.zaob;
    }

    @KeepForSdk
    @Nullable
    public final String getRealClientPackageName() {
        return this.zabv;
    }

    @Nullable
    public final String getRealClientClassName() {
        return this.zabw;
    }

    @KeepForSdk
    @Nullable
    public final View getViewForPopups() {
        return this.zabu;
    }

    @Nullable
    public final SignInOptions getSignInOptions() {
        return this.zaoc;
    }

    @Nullable
    public final Integer getClientSessionId() {
        return this.zaod;
    }

    public final void setClientSessionId(Integer num) {
        this.zaod = num;
    }

    @KeepForSdk
    public final Set<Scope> getApplicableScopes(Api<?> api) {
        ClientSettings$OptionalApiSettings clientSettings$OptionalApiSettings = (ClientSettings$OptionalApiSettings) this.zaob.get(api);
        if (clientSettings$OptionalApiSettings != null) {
            if (!clientSettings$OptionalApiSettings.mScopes.isEmpty()) {
                Set<Scope> hashSet = new HashSet(this.zabr);
                hashSet.addAll(clientSettings$OptionalApiSettings.mScopes);
                return hashSet;
            }
        }
        return this.zabr;
    }
}
