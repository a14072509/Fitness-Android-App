package com.google.android.gms.common.internal;

import android.app.PendingIntent;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.internal.common.zze;

final class BaseGmsClient$zzb extends zze {
    private final /* synthetic */ BaseGmsClient zzcs;

    public BaseGmsClient$zzb(BaseGmsClient baseGmsClient, Looper looper) {
        this.zzcs = baseGmsClient;
        super(looper);
    }

    public final void handleMessage(Message message) {
        if (this.zzcs.zzcq.get() != message.arg1) {
            if (zzb(message)) {
                zza(message);
            }
            return;
        }
        PendingIntent pendingIntent;
        if (!(message.what == 1 || message.what == 7 || message.what == 4)) {
            if (message.what != 5) {
                pendingIntent = null;
                if (message.what == 4) {
                    BaseGmsClient.zza(this.zzcs, new ConnectionResult(message.arg2));
                    if (BaseGmsClient.zzb(this.zzcs) == null && BaseGmsClient.zzc(this.zzcs) == null) {
                        BaseGmsClient.zza(this.zzcs, 3, null);
                        return;
                    }
                    if (BaseGmsClient.zzd(this.zzcs) == null) {
                        message = BaseGmsClient.zzd(this.zzcs);
                    } else {
                        message = new ConnectionResult(8);
                    }
                    this.zzcs.zzce.onReportServiceBinding(message);
                    this.zzcs.onConnectionFailed(message);
                    return;
                } else if (message.what == 5) {
                    if (BaseGmsClient.zzd(this.zzcs) == null) {
                        message = BaseGmsClient.zzd(this.zzcs);
                    } else {
                        message = new ConnectionResult(8);
                    }
                    this.zzcs.zzce.onReportServiceBinding(message);
                    this.zzcs.onConnectionFailed(message);
                    return;
                } else if (message.what == 3) {
                    if (message.obj instanceof PendingIntent) {
                        pendingIntent = (PendingIntent) message.obj;
                    }
                    ConnectionResult connectionResult = new ConnectionResult(message.arg2, pendingIntent);
                    this.zzcs.zzce.onReportServiceBinding(connectionResult);
                    this.zzcs.onConnectionFailed(connectionResult);
                    return;
                } else if (message.what != 6) {
                    BaseGmsClient.zza(this.zzcs, 5, null);
                    if (BaseGmsClient.zze(this.zzcs) != null) {
                        BaseGmsClient.zze(this.zzcs).onConnectionSuspended(message.arg2);
                    }
                    this.zzcs.onConnectionSuspended(message.arg2);
                    BaseGmsClient.zza(this.zzcs, 5, 1, null);
                    return;
                } else if (message.what != 2 && !this.zzcs.isConnected()) {
                    zza(message);
                    return;
                } else if (zzb(message)) {
                    message = message.what;
                    StringBuilder stringBuilder = new StringBuilder(45);
                    stringBuilder.append("Don't know how to handle message: ");
                    stringBuilder.append(message);
                    Log.wtf("GmsClient", stringBuilder.toString(), new Exception());
                    return;
                } else {
                    ((BaseGmsClient$zzc) message.obj).zzo();
                    return;
                }
            }
        }
        if (this.zzcs.isConnecting()) {
            pendingIntent = null;
            if (message.what == 4) {
                BaseGmsClient.zza(this.zzcs, new ConnectionResult(message.arg2));
                if (BaseGmsClient.zzb(this.zzcs) == null) {
                }
                if (BaseGmsClient.zzd(this.zzcs) == null) {
                    message = new ConnectionResult(8);
                } else {
                    message = BaseGmsClient.zzd(this.zzcs);
                }
                this.zzcs.zzce.onReportServiceBinding(message);
                this.zzcs.onConnectionFailed(message);
                return;
            } else if (message.what == 5) {
                if (BaseGmsClient.zzd(this.zzcs) == null) {
                    message = new ConnectionResult(8);
                } else {
                    message = BaseGmsClient.zzd(this.zzcs);
                }
                this.zzcs.zzce.onReportServiceBinding(message);
                this.zzcs.onConnectionFailed(message);
                return;
            } else if (message.what == 3) {
                if (message.obj instanceof PendingIntent) {
                    pendingIntent = (PendingIntent) message.obj;
                }
                ConnectionResult connectionResult2 = new ConnectionResult(message.arg2, pendingIntent);
                this.zzcs.zzce.onReportServiceBinding(connectionResult2);
                this.zzcs.onConnectionFailed(connectionResult2);
                return;
            } else if (message.what != 6) {
                if (message.what != 2) {
                }
                if (zzb(message)) {
                    message = message.what;
                    StringBuilder stringBuilder2 = new StringBuilder(45);
                    stringBuilder2.append("Don't know how to handle message: ");
                    stringBuilder2.append(message);
                    Log.wtf("GmsClient", stringBuilder2.toString(), new Exception());
                    return;
                }
                ((BaseGmsClient$zzc) message.obj).zzo();
                return;
            } else {
                BaseGmsClient.zza(this.zzcs, 5, null);
                if (BaseGmsClient.zze(this.zzcs) != null) {
                    BaseGmsClient.zze(this.zzcs).onConnectionSuspended(message.arg2);
                }
                this.zzcs.onConnectionSuspended(message.arg2);
                BaseGmsClient.zza(this.zzcs, 5, 1, null);
                return;
            }
        }
        zza(message);
    }

    private static void zza(Message message) {
        BaseGmsClient$zzc baseGmsClient$zzc = (BaseGmsClient$zzc) message.obj;
        baseGmsClient$zzc.zzn();
        baseGmsClient$zzc.unregister();
    }

    private static boolean zzb(Message message) {
        if (!(message.what == 2 || message.what == 1)) {
            if (message.what != 7) {
                return null;
            }
        }
        return true;
    }
}
