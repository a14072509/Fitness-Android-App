package com.google.android.gms.common.internal.service;

import android.os.IInterface;
import android.os.RemoteException;

public interface zaj extends IInterface {
    void zaj(int i) throws RemoteException;
}
