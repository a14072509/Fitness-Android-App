package com.google.android.gms.common.internal.service;

import android.os.IInterface;
import android.os.RemoteException;

public interface zal extends IInterface {
    void zaa(zaj zaj) throws RemoteException;
}
