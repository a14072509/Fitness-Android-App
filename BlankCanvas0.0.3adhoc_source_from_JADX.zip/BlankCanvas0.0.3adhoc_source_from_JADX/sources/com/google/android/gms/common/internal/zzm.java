package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.zzk;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzm extends IInterface {
    boolean zza(zzk zzk, IObjectWrapper iObjectWrapper) throws RemoteException;
}
