package com.google.android.gms.common.api.internal;

interface zacs {
    void zac(BasePendingResult<?> basePendingResult);
}
