package com.google.android.gms.common.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.annotation.KeepForSdk;

@KeepForSdk
public interface BaseGmsClient$ConnectionProgressReportCallbacks {
    @KeepForSdk
    void onReportServiceBinding(@NonNull ConnectionResult connectionResult);
}
