package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.ConnectionResult;

final class zacf implements Runnable {
    private final /* synthetic */ zace zakj;

    zacf(zace zace) {
        this.zakj = zace;
    }

    public final void run() {
        this.zakj.zaki.zag(new ConnectionResult(4));
    }
}
