package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.support.v4.util.ArraySet;
import android.view.View;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.signin.SignInOptions;
import java.util.Collection;
import java.util.Map;

@KeepForSdk
public final class ClientSettings$Builder {
    private int zabt = 0;
    private View zabu;
    private String zabv;
    private String zabw;
    private Map<Api<?>, ClientSettings$OptionalApiSettings> zaob;
    private SignInOptions zaoc = SignInOptions.DEFAULT;
    private ArraySet<Scope> zaoe;
    private Account zax;

    public final ClientSettings$Builder setAccount(Account account) {
        this.zax = account;
        return this;
    }

    public final ClientSettings$Builder addRequiredScope(Scope scope) {
        if (this.zaoe == null) {
            this.zaoe = new ArraySet();
        }
        this.zaoe.add(scope);
        return this;
    }

    public final ClientSettings$Builder addAllRequiredScopes(Collection<Scope> collection) {
        if (this.zaoe == null) {
            this.zaoe = new ArraySet();
        }
        this.zaoe.addAll((Collection) collection);
        return this;
    }

    public final ClientSettings$Builder setOptionalApiSettingsMap(Map<Api<?>, ClientSettings$OptionalApiSettings> map) {
        this.zaob = map;
        return this;
    }

    public final ClientSettings$Builder setGravityForPopups(int i) {
        this.zabt = i;
        return this;
    }

    public final ClientSettings$Builder setViewForPopups(View view) {
        this.zabu = view;
        return this;
    }

    @KeepForSdk
    public final ClientSettings$Builder setRealClientPackageName(String str) {
        this.zabv = str;
        return this;
    }

    public final ClientSettings$Builder setRealClientClassName(String str) {
        this.zabw = str;
        return this;
    }

    public final ClientSettings$Builder setSignInOptions(SignInOptions signInOptions) {
        this.zaoc = signInOptions;
        return this;
    }

    @KeepForSdk
    public final ClientSettings build() {
        return new ClientSettings(this.zax, this.zaoe, this.zaob, this.zabt, this.zabu, this.zabv, this.zabw, this.zaoc);
    }
}
