package com.google.android.gms.common.api.internal;

final class zaai extends zabf {
    private final /* synthetic */ zaah zafu;

    zaai(zaah zaah, zabd zabd) {
        this.zafu = zaah;
        super(zabd);
    }

    public final void zaan() {
        this.zafu.onConnectionSuspended(1);
    }
}
