package com.google.android.gms.common.api.internal;

final class zabn implements Runnable {
    private final /* synthetic */ zabm zaiz;

    zabn(zabm zabm) {
        this.zaiz = zabm;
    }

    public final void run() {
        this.zaiz.zaix.zain.disconnect();
    }
}
