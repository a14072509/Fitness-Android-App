package com.google.android.gms.common;

/* renamed from: com.google.android.gms.common.R */
public final class C0481R {

    /* renamed from: com.google.android.gms.common.R$integer */
    public static final class integer {
        public static final int google_play_services_version = 2131230724;

        private integer() {
        }
    }

    /* renamed from: com.google.android.gms.common.R$string */
    public static final class string {
        public static final int common_google_play_services_unknown_issue = 2131427378;

        private string() {
        }
    }

    private C0481R() {
    }
}
