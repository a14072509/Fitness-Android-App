package com.google.android.gms.common.internal;

import android.util.Log;

protected abstract class BaseGmsClient$zzc<TListener> {
    private final /* synthetic */ BaseGmsClient zzcs;
    private TListener zzct;
    private boolean zzcu = null;

    public BaseGmsClient$zzc(BaseGmsClient baseGmsClient, TListener tListener) {
        this.zzcs = baseGmsClient;
        this.zzct = tListener;
    }

    protected abstract void zza(TListener tListener);

    protected abstract void zzn();

    public final void zzo() {
        synchronized (this) {
            Object obj = this.zzct;
            if (this.zzcu) {
                String valueOf = String.valueOf(this);
                StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 47);
                stringBuilder.append("Callback proxy ");
                stringBuilder.append(valueOf);
                stringBuilder.append(" being reused. This is not safe.");
                Log.w("GmsClient", stringBuilder.toString());
            }
        }
        if (obj != null) {
            try {
                zza(obj);
            } catch (RuntimeException e) {
                zzn();
                throw e;
            }
        }
        zzn();
        synchronized (this) {
            this.zzcu = true;
        }
        unregister();
    }

    public final void unregister() {
        removeListener();
        synchronized (BaseGmsClient.zzf(this.zzcs)) {
            BaseGmsClient.zzf(this.zzcs).remove(this);
        }
    }

    public final void removeListener() {
        synchronized (this) {
            this.zzct = null;
        }
    }
}
