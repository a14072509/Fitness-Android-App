package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.util.VisibleForTesting;

@VisibleForTesting
public final class BaseGmsClient$zze implements ServiceConnection {
    private final /* synthetic */ BaseGmsClient zzcs;
    private final int zzcw;

    public BaseGmsClient$zze(BaseGmsClient baseGmsClient, int i) {
        this.zzcs = baseGmsClient;
        this.zzcw = i;
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        if (iBinder == null) {
            BaseGmsClient.zza(this.zzcs, 16);
            return;
        }
        synchronized (BaseGmsClient.zza(this.zzcs)) {
            BaseGmsClient baseGmsClient = this.zzcs;
            if (iBinder == null) {
                iBinder = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IGmsServiceBroker");
                if (queryLocalInterface == null || !(queryLocalInterface instanceof IGmsServiceBroker)) {
                    iBinder = new zza(iBinder);
                } else {
                    iBinder = (IGmsServiceBroker) queryLocalInterface;
                }
            }
            BaseGmsClient.zza(baseGmsClient, iBinder);
        }
        this.zzcs.zza(null, null, this.zzcw);
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        synchronized (BaseGmsClient.zza(this.zzcs)) {
            BaseGmsClient.zza(this.zzcs, null);
        }
        this.zzcs.mHandler.sendMessage(this.zzcs.mHandler.obtainMessage(6, this.zzcw, 1));
    }
}
