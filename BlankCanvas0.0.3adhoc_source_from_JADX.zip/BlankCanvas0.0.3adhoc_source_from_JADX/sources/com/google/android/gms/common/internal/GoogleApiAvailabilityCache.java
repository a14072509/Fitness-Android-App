package com.google.android.gms.common.internal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.SparseIntArray;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GoogleApiAvailabilityLight;
import com.google.android.gms.common.api.Api$Client;

public class GoogleApiAvailabilityCache {
    private final SparseIntArray zaor;
    private GoogleApiAvailabilityLight zaos;

    public GoogleApiAvailabilityCache() {
        this(GoogleApiAvailability.getInstance());
    }

    public GoogleApiAvailabilityCache(@NonNull GoogleApiAvailabilityLight googleApiAvailabilityLight) {
        this.zaor = new SparseIntArray();
        Preconditions.checkNotNull(googleApiAvailabilityLight);
        this.zaos = googleApiAvailabilityLight;
    }

    public int getClientAvailability(@NonNull Context context, @NonNull Api$Client api$Client) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(api$Client);
        if (!api$Client.requiresGooglePlayServices()) {
            return 0;
        }
        api$Client = api$Client.getMinApkVersion();
        int i = this.zaor.get(api$Client, -1);
        if (i != -1) {
            return i;
        }
        for (int i2 = 0; i2 < this.zaor.size(); i2++) {
            int keyAt = this.zaor.keyAt(i2);
            if (keyAt > api$Client && this.zaor.get(keyAt) == 0) {
                i = 0;
                break;
            }
        }
        if (i == -1) {
            i = this.zaos.isGooglePlayServicesAvailable(context, api$Client);
        }
        this.zaor.put(api$Client, i);
        return i;
    }

    public void flush() {
        this.zaor.clear();
    }
}
