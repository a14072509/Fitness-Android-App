package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.GoogleApi;

public final class zabv {
    public final zab zajq;
    public final int zajr;
    public final GoogleApi<?> zajs;

    public zabv(zab zab, int i, GoogleApi<?> googleApi) {
        this.zajq = zab;
        this.zajr = i;
        this.zajs = googleApi;
    }
}
