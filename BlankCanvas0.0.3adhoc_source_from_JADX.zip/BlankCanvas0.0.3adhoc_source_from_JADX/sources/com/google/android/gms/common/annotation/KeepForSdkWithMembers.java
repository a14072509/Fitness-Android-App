package com.google.android.gms.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Deprecated
@Documented
@Target({ElementType.TYPE})
public @interface KeepForSdkWithMembers {
}
