package com.google.android.gms.common.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.annotation.KeepForSdk;

protected class BaseGmsClient$LegacyClientCallbackAdapter implements BaseGmsClient$ConnectionProgressReportCallbacks {
    private final /* synthetic */ BaseGmsClient zzcs;

    @KeepForSdk
    public BaseGmsClient$LegacyClientCallbackAdapter(BaseGmsClient baseGmsClient) {
        this.zzcs = baseGmsClient;
    }

    public void onReportServiceBinding(@NonNull ConnectionResult connectionResult) {
        if (connectionResult.isSuccess()) {
            connectionResult = this.zzcs;
            connectionResult.getRemoteService(null, connectionResult.getScopes());
            return;
        }
        if (BaseGmsClient.zzg(this.zzcs) != null) {
            BaseGmsClient.zzg(this.zzcs).onConnectionFailed(connectionResult);
        }
    }
}
