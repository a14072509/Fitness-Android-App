package com.google.android.gms.common.internal;

import android.app.PendingIntent;
import android.os.Bundle;
import android.support.annotation.BinderThread;
import com.google.android.gms.common.ConnectionResult;

abstract class BaseGmsClient$zza extends BaseGmsClient$zzc<Boolean> {
    private final int statusCode;
    private final Bundle zzcr;
    private final /* synthetic */ BaseGmsClient zzcs;

    @BinderThread
    protected BaseGmsClient$zza(BaseGmsClient baseGmsClient, int i, Bundle bundle) {
        this.zzcs = baseGmsClient;
        super(baseGmsClient, Boolean.valueOf(true));
        this.statusCode = i;
        this.zzcr = bundle;
    }

    protected abstract void zza(ConnectionResult connectionResult);

    protected abstract boolean zzm();

    protected final void zzn() {
    }

    protected final /* synthetic */ void zza(Object obj) {
        PendingIntent pendingIntent = null;
        if (((Boolean) obj) == null) {
            BaseGmsClient.zza(this.zzcs, 1, null);
            return;
        }
        obj = this.statusCode;
        if (obj != null) {
            if (obj != 10) {
                BaseGmsClient.zza(this.zzcs, 1, null);
                obj = this.zzcr;
                if (obj != null) {
                    pendingIntent = (PendingIntent) obj.getParcelable(BaseGmsClient.KEY_PENDING_INTENT);
                }
                zza(new ConnectionResult(this.statusCode, pendingIntent));
            } else {
                BaseGmsClient.zza(this.zzcs, 1, null);
                throw new IllegalStateException(String.format("A fatal developer error has occurred. Class name: %s. Start service action: %s. Service Descriptor: %s. ", new Object[]{getClass().getSimpleName(), this.zzcs.getStartServiceAction(), this.zzcs.getServiceDescriptor()}));
            }
        } else if (zzm() == null) {
            BaseGmsClient.zza(this.zzcs, 1, null);
            zza(new ConnectionResult(8, null));
        }
    }
}
