package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import com.google.android.gms.common.annotation.KeepForSdk;

@KeepForSdk
public final class DeviceProperties {
    private static Boolean zzgl;
    private static Boolean zzgm;
    private static Boolean zzgn;
    private static Boolean zzgo;
    private static Boolean zzgp;
    private static Boolean zzgq;
    private static Boolean zzgr;
    private static Boolean zzgs;

    private DeviceProperties() {
    }

    @KeepForSdk
    public static boolean isTablet(Resources resources) {
        boolean z = false;
        if (resources == null) {
            return false;
        }
        if (zzgl == null) {
            if (((resources.getConfiguration().screenLayout & 15) > 3 ? 1 : null) == null) {
                if (zzgm == null) {
                    resources = resources.getConfiguration();
                    resources = ((resources.screenLayout & 15) > 3 || resources.smallestScreenWidthDp < 600) ? null : true;
                    zzgm = Boolean.valueOf(resources);
                }
                if (zzgm.booleanValue() == null) {
                    zzgl = Boolean.valueOf(z);
                }
            }
            z = true;
            zzgl = Boolean.valueOf(z);
        }
        return zzgl.booleanValue();
    }

    @TargetApi(20)
    @KeepForSdk
    public static boolean isWearable(Context context) {
        if (zzgn == null) {
            if (PlatformVersion.isAtLeastKitKatWatch()) {
                if (context.getPackageManager().hasSystemFeature("android.hardware.type.watch") != null) {
                    context = true;
                    zzgn = Boolean.valueOf(context);
                }
            }
            context = null;
            zzgn = Boolean.valueOf(context);
        }
        return zzgn.booleanValue();
    }

    @TargetApi(26)
    @KeepForSdk
    public static boolean isWearableWithoutPlayStore(Context context) {
        if (isWearable(context)) {
            if (PlatformVersion.isAtLeastN()) {
                if (isSidewinder(context) == null || PlatformVersion.isAtLeastO() != null) {
                }
            }
            return true;
        }
        return null;
    }

    @TargetApi(21)
    @KeepForSdk
    public static boolean isSidewinder(Context context) {
        if (zzgo == null) {
            if (PlatformVersion.isAtLeastLollipop()) {
                if (context.getPackageManager().hasSystemFeature("cn.google") != null) {
                    context = true;
                    zzgo = Boolean.valueOf(context);
                }
            }
            context = null;
            zzgo = Boolean.valueOf(context);
        }
        return zzgo.booleanValue();
    }

    @KeepForSdk
    public static boolean isLatchsky(Context context) {
        if (zzgp == null) {
            context = context.getPackageManager();
            if (context.hasSystemFeature("com.google.android.feature.services_updater")) {
                if (context.hasSystemFeature("cn.google.services") != null) {
                    context = true;
                    zzgp = Boolean.valueOf(context);
                }
            }
            context = null;
            zzgp = Boolean.valueOf(context);
        }
        return zzgp.booleanValue();
    }

    public static boolean zzf(Context context) {
        if (zzgq == null) {
            if (!context.getPackageManager().hasSystemFeature("android.hardware.type.iot")) {
                if (context.getPackageManager().hasSystemFeature("android.hardware.type.embedded") == null) {
                    context = null;
                    zzgq = Boolean.valueOf(context);
                }
            }
            context = true;
            zzgq = Boolean.valueOf(context);
        }
        return zzgq.booleanValue();
    }

    @KeepForSdk
    public static boolean isAuto(Context context) {
        if (zzgr == null) {
            if (PlatformVersion.isAtLeastO()) {
                if (context.getPackageManager().hasSystemFeature("android.hardware.type.automotive") != null) {
                    context = true;
                    zzgr = Boolean.valueOf(context);
                }
            }
            context = null;
            zzgr = Boolean.valueOf(context);
        }
        return zzgr.booleanValue();
    }

    @KeepForSdk
    public static boolean isTv(Context context) {
        if (zzgs == null) {
            context = context.getPackageManager();
            if (!context.hasSystemFeature("com.google.android.tv")) {
                if (!context.hasSystemFeature("android.hardware.type.television")) {
                    if (context.hasSystemFeature("android.software.leanback") == null) {
                        context = null;
                        zzgs = Boolean.valueOf(context);
                    }
                }
            }
            context = true;
            zzgs = Boolean.valueOf(context);
        }
        return zzgs.booleanValue();
    }

    @KeepForSdk
    public static boolean isUserBuild() {
        return "user".equals(Build.TYPE);
    }
}
