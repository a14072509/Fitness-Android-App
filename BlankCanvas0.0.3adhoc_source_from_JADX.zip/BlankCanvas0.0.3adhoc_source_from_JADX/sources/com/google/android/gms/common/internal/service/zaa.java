package com.google.android.gms.common.internal.service;

import android.os.RemoteException;

public class zaa extends zak {
    public void zaj(int i) throws RemoteException {
    }
}
