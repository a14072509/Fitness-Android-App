package com.google.android.gms.common.internal;

import com.google.android.gms.common.annotation.KeepForSdk;

@KeepForSdk
public interface BaseGmsClient$SignOutCallbacks {
    @KeepForSdk
    void onSignOutComplete();
}
