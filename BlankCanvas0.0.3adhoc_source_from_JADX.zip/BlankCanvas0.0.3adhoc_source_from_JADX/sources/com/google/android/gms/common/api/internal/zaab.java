package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.tasks.TaskCompletionSource;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

public final class zaab {
    private final Map<BasePendingResult<?>, Boolean> zafj = Collections.synchronizedMap(new WeakHashMap());
    private final Map<TaskCompletionSource<?>, Boolean> zafk = Collections.synchronizedMap(new WeakHashMap());

    private final void zaa(boolean r5, com.google.android.gms.common.api.Status r6) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:41:0x007e in {17, 18, 19, 20, 28, 29, 30, 31, 32, 36, 40} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r4 = this;
        r0 = r4.zafj;
        monitor-enter(r0);
        r1 = new java.util.HashMap;	 Catch:{ all -> 0x007b }
        r2 = r4.zafj;	 Catch:{ all -> 0x007b }
        r1.<init>(r2);	 Catch:{ all -> 0x007b }
        monitor-exit(r0);	 Catch:{ all -> 0x007b }
        r2 = r4.zafk;
        monitor-enter(r2);
        r0 = new java.util.HashMap;	 Catch:{ all -> 0x0078 }
        r3 = r4.zafk;	 Catch:{ all -> 0x0078 }
        r0.<init>(r3);	 Catch:{ all -> 0x0078 }
        monitor-exit(r2);	 Catch:{ all -> 0x0078 }
        r1 = r1.entrySet();
        r1 = r1.iterator();
    L_0x001e:
        r2 = r1.hasNext();
        if (r2 == 0) goto L_0x0044;
    L_0x0024:
        r2 = r1.next();
        r2 = (java.util.Map.Entry) r2;
        if (r5 != 0) goto L_0x003a;
    L_0x002c:
        r3 = r2.getValue();
        r3 = (java.lang.Boolean) r3;
        r3 = r3.booleanValue();
        if (r3 == 0) goto L_0x0039;
    L_0x0038:
        goto L_0x003a;
    L_0x0039:
        goto L_0x0043;
    L_0x003a:
        r2 = r2.getKey();
        r2 = (com.google.android.gms.common.api.internal.BasePendingResult) r2;
        r2.zab(r6);
    L_0x0043:
        goto L_0x001e;
    L_0x0044:
        r0 = r0.entrySet();
        r0 = r0.iterator();
    L_0x004c:
        r1 = r0.hasNext();
        if (r1 == 0) goto L_0x0077;
    L_0x0052:
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        if (r5 != 0) goto L_0x0068;
    L_0x005a:
        r2 = r1.getValue();
        r2 = (java.lang.Boolean) r2;
        r2 = r2.booleanValue();
        if (r2 == 0) goto L_0x0067;
    L_0x0066:
        goto L_0x0068;
    L_0x0067:
        goto L_0x0076;
    L_0x0068:
        r1 = r1.getKey();
        r1 = (com.google.android.gms.tasks.TaskCompletionSource) r1;
        r2 = new com.google.android.gms.common.api.ApiException;
        r2.<init>(r6);
        r1.trySetException(r2);
    L_0x0076:
        goto L_0x004c;
    L_0x0077:
        return;
    L_0x0078:
        r5 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0078 }
        throw r5;
    L_0x007b:
        r5 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x007b }
        throw r5;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.api.internal.zaab.zaa(boolean, com.google.android.gms.common.api.Status):void");
    }

    final void zaa(BasePendingResult<? extends Result> basePendingResult, boolean z) {
        this.zafj.put(basePendingResult, Boolean.valueOf(z));
        basePendingResult.addStatusListener(new zaac(this, basePendingResult));
    }

    final <TResult> void zaa(TaskCompletionSource<TResult> taskCompletionSource, boolean z) {
        this.zafk.put(taskCompletionSource, Boolean.valueOf(z));
        taskCompletionSource.getTask().addOnCompleteListener(new zaad(this, taskCompletionSource));
    }

    final boolean zaag() {
        if (this.zafj.isEmpty()) {
            if (this.zafk.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public final void zaah() {
        zaa(false, GoogleApiManager.zahw);
    }

    public final void zaai() {
        zaa(true, zacp.zakw);
    }
}
