package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public final class zzb {
    private static Pattern zzgv = null;

    public static int zzc(int i) {
        if (i == -1) {
            return -1;
        }
        return i / 1000;
    }
}
