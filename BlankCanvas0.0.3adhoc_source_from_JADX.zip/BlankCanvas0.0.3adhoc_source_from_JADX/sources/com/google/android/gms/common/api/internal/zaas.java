package com.google.android.gms.common.api.internal;

import com.google.android.gms.signin.internal.zaj;

final class zaas extends zabf {
    private final /* synthetic */ zaak zagp;
    private final /* synthetic */ zaj zagq;

    zaas(zaar zaar, zabd zabd, zaak zaak, zaj zaj) {
        this.zagp = zaak;
        this.zagq = zaj;
        super(zabd);
    }

    public final void zaan() {
        this.zagp.zaa(this.zagq);
    }
}
