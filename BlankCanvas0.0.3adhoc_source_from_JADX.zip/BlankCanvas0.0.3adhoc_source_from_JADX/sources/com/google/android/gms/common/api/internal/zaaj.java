package com.google.android.gms.common.api.internal;

final class zaaj extends zabf {
    private final /* synthetic */ zaah zafu;

    zaaj(zaah zaah, zabd zabd) {
        this.zafu = zaah;
        super(zabd);
    }

    public final void zaan() {
        this.zafu.zafs.zahs.zab(null);
    }
}
