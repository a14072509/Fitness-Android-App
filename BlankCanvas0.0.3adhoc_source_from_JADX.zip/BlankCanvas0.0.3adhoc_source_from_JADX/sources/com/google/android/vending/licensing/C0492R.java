package com.google.android.vending.licensing;

/* renamed from: com.google.android.vending.licensing.R */
public final class C0492R {
    private C0492R() {
    }
}
