package com.google.android.vending.licensing;

public interface DeviceLimiter {
    int isDeviceAllowed(String str);
}
