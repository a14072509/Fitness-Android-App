package com.google.android.vending.licensing;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class PreferenceObfuscator {
    private static final String TAG = "PreferenceObfuscator";
    private Editor mEditor = null;
    private final Obfuscator mObfuscator;
    private final SharedPreferences mPreferences;

    public PreferenceObfuscator(SharedPreferences sp, Obfuscator o) {
        this.mPreferences = sp;
        this.mObfuscator = o;
    }

    public void putString(String key, String value) {
        if (this.mEditor == null) {
            this.mEditor = this.mPreferences.edit();
        }
        this.mEditor.putString(key, this.mObfuscator.obfuscate(value, key));
    }

    public String getString(String key, String defValue) {
        String value = this.mPreferences.getString(key, null);
        if (value == null) {
            return defValue;
        }
        String result;
        try {
            result = this.mObfuscator.unobfuscate(value, key);
        } catch (ValidationException e) {
            String str = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Validation error while reading preference: ");
            stringBuilder.append(key);
            Log.w(str, stringBuilder.toString());
            result = defValue;
        }
        return result;
    }

    public void commit() {
        Editor editor = this.mEditor;
        if (editor != null) {
            editor.commit();
            this.mEditor = null;
        }
    }
}
