package com.google.android.vending.expansion.downloader.impl;

import android.content.Context;
import android.os.Build;
import android.os.Build.VERSION;
import android.util.Log;
import com.google.android.vending.expansion.downloader.Constants;
import com.google.android.vending.expansion.downloader.Helpers;
import com.google.android.vending.expansion.downloader.impl.DownloaderService.GenerateSaveFileError;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.Locale;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.apache.http.entity.mime.MIME;
import org.apache.http.protocol.HTTP;

public class DownloadThread {
    private Context mContext;
    private final DownloadsDB mDB;
    private DownloadInfo mInfo;
    private final DownloadNotification mNotification;
    private DownloaderService mService;
    private String mUserAgent;

    private static class InnerState {
        public int mBytesNotified;
        public int mBytesSoFar;
        public int mBytesThisSession;
        public boolean mContinuingDownload;
        public String mHeaderContentDisposition;
        public String mHeaderContentLength;
        public String mHeaderContentLocation;
        public String mHeaderETag;
        public long mTimeLastNotification;

        private InnerState() {
            this.mBytesSoFar = 0;
            this.mBytesThisSession = 0;
            this.mContinuingDownload = false;
            this.mBytesNotified = 0;
            this.mTimeLastNotification = 0;
        }
    }

    private class RetryDownload extends Throwable {
        private static final long serialVersionUID = 6196036036517540229L;

        private RetryDownload() {
        }
    }

    private static class State {
        public boolean mCountRetry = false;
        public String mFilename;
        public boolean mGotData = false;
        public String mNewUri;
        public int mRedirectCount = 0;
        public String mRequestUri;
        public int mRetryAfter = 0;
        public FileOutputStream mStream;

        public State(DownloadInfo info, DownloaderService service) {
            this.mRedirectCount = info.mRedirectCount;
            this.mRequestUri = info.mUri;
            this.mFilename = service.generateTempSaveFileName(info.mFileName);
        }
    }

    private class StopRequest extends Throwable {
        private static final long serialVersionUID = 6338592678988347973L;
        public int mFinalStatus;

        public StopRequest(int finalStatus, String message) {
            super(message);
            this.mFinalStatus = finalStatus;
        }

        public StopRequest(int finalStatus, String message, Throwable throwable) {
            super(message, throwable);
            this.mFinalStatus = finalStatus;
        }
    }

    private void syncDestination(com.google.android.vending.expansion.downloader.impl.DownloadThread.State r6) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:57:0x00d1 in {5, 6, 8, 10, 20, 21, 29, 37, 45, 46, 49, 50, 52, 54, 55, 56} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = 0;
        r1 = new java.io.FileOutputStream;	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r2 = r6.mFilename;	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r3 = 1;	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r1.<init>(r2, r3);	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r0 = r1;	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r1 = r0.getFD();	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r1.sync();	 Catch:{ FileNotFoundException -> 0x008d, SyncFailedException -> 0x0065, IOException -> 0x003d, RuntimeException -> 0x002c }
        r0.close();	 Catch:{ IOException -> 0x0020, RuntimeException -> 0x0017 }
    L_0x0015:
        goto L_0x00b6;
    L_0x0017:
        r1 = move-exception;
        r2 = "LVLDL";
        r3 = "exception while closing file: ";
        android.util.Log.w(r2, r3, r1);
        goto L_0x0015;
    L_0x0020:
        r1 = move-exception;
        r2 = "LVLDL";
        r3 = "IOException while closing synced file: ";
        android.util.Log.w(r2, r3, r1);
        goto L_0x0015;
    L_0x0029:
        r1 = move-exception;
        goto L_0x00b7;
    L_0x002c:
        r1 = move-exception;
        r2 = "LVLDL";	 Catch:{ all -> 0x0029 }
        r3 = "exception while syncing file: ";	 Catch:{ all -> 0x0029 }
        android.util.Log.w(r2, r3, r1);	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x003b;
    L_0x0037:
        r0.close();	 Catch:{ IOException -> 0x0020, RuntimeException -> 0x0017 }
        goto L_0x0015;
    L_0x003b:
        goto L_0x00b6;
    L_0x003d:
        r1 = move-exception;
        r2 = "LVLDL";	 Catch:{ all -> 0x0029 }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0029 }
        r3.<init>();	 Catch:{ all -> 0x0029 }
        r4 = "IOException trying to sync ";	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r4 = r6.mFilename;	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r4 = ": ";	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r3.append(r1);	 Catch:{ all -> 0x0029 }
        r3 = r3.toString();	 Catch:{ all -> 0x0029 }
        android.util.Log.w(r2, r3);	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x003b;
    L_0x0061:
        r0.close();	 Catch:{ IOException -> 0x0020, RuntimeException -> 0x0017 }
        goto L_0x0015;
    L_0x0065:
        r1 = move-exception;
        r2 = "LVLDL";	 Catch:{ all -> 0x0029 }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0029 }
        r3.<init>();	 Catch:{ all -> 0x0029 }
        r4 = "file ";	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r4 = r6.mFilename;	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r4 = " sync failed: ";	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r3.append(r1);	 Catch:{ all -> 0x0029 }
        r3 = r3.toString();	 Catch:{ all -> 0x0029 }
        android.util.Log.w(r2, r3);	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x003b;
    L_0x0089:
        r0.close();	 Catch:{ IOException -> 0x0020, RuntimeException -> 0x0017 }
        goto L_0x0015;
    L_0x008d:
        r1 = move-exception;
        r2 = "LVLDL";	 Catch:{ all -> 0x0029 }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0029 }
        r3.<init>();	 Catch:{ all -> 0x0029 }
        r4 = "file ";	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r4 = r6.mFilename;	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r4 = " not found: ";	 Catch:{ all -> 0x0029 }
        r3.append(r4);	 Catch:{ all -> 0x0029 }
        r3.append(r1);	 Catch:{ all -> 0x0029 }
        r3 = r3.toString();	 Catch:{ all -> 0x0029 }
        android.util.Log.w(r2, r3);	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x003b;
    L_0x00b1:
        r0.close();	 Catch:{ IOException -> 0x0020, RuntimeException -> 0x0017 }
        goto L_0x0015;
    L_0x00b6:
        return;
    L_0x00b7:
        if (r0 == 0) goto L_0x00cf;
    L_0x00b9:
        r0.close();	 Catch:{ IOException -> 0x00c6, RuntimeException -> 0x00bd }
    L_0x00bc:
        goto L_0x00d0;
    L_0x00bd:
        r2 = move-exception;
        r3 = "LVLDL";
        r4 = "exception while closing file: ";
        android.util.Log.w(r3, r4, r2);
        goto L_0x00d0;
    L_0x00c6:
        r2 = move-exception;
        r3 = "LVLDL";
        r4 = "IOException while closing synced file: ";
        android.util.Log.w(r3, r4, r2);
        goto L_0x00bc;
    L_0x00d0:
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.vending.expansion.downloader.impl.DownloadThread.syncDestination(com.google.android.vending.expansion.downloader.impl.DownloadThread$State):void");
    }

    public void run() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:40:0x00f5 in {9, 12, 14, 15, 18, 19, 20, 28, 33, 34, 36, 37, 39} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/106374177.run(Unknown Source)
*/
        /*
        r11 = this;
        r0 = 10;
        android.os.Process.setThreadPriority(r0);
        r0 = new com.google.android.vending.expansion.downloader.impl.DownloadThread$State;
        r1 = r11.mInfo;
        r2 = r11.mService;
        r0.<init>(r1, r2);
        r8 = r0;
        r1 = 0;
        r9 = 491; // 0x1eb float:6.88E-43 double:2.426E-321;
        r0 = r11.mContext;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r2 = "power";	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = r0.getSystemService(r2);	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = (android.os.PowerManager) r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r2 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = 1;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r3 = "LVLDL";	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = r2.newWakeLock(r0, r3);	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r1 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r1.acquire();	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = 0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r3 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
    L_0x002a:
        if (r3 != 0) goto L_0x005d;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
    L_0x002c:
        r0 = new java.net.URL;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r4 = r8.mRequestUri;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0.<init>(r4);	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r4 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = r4.openConnection();	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = (java.net.HttpURLConnection) r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r5 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = "User-Agent";	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r6 = r11.userAgent();	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r5.setRequestProperty(r0, r6);	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r11.executeDownload(r8, r5);	 Catch:{ RetryDownload -> 0x0056, all -> 0x004e }
        r0 = 1;
        r5.disconnect();	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r3 = 0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r3 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        goto L_0x005c;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
    L_0x004e:
        r0 = move-exception;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r6 = r0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r5.disconnect();	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = 0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        throw r6;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
    L_0x0056:
        r0 = move-exception;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r5.disconnect();	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = 0;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
    L_0x005c:
        goto L_0x002a;	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
    L_0x005d:
        r11.finalizeDestinationFile(r8);	 Catch:{ StopRequest -> 0x00a8, Throwable -> 0x0080 }
        r0 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;
        if (r1 == 0) goto L_0x006a;
    L_0x0064:
        r1.release();
        r1 = 0;
        r9 = r1;
        goto L_0x006b;
    L_0x006a:
        r9 = r1;
    L_0x006b:
        r11.cleanupDestination(r8, r0);
        r3 = r8.mCountRetry;
        r4 = r8.mRetryAfter;
        r5 = r8.mRedirectCount;
        r6 = r8.mGotData;
        r7 = r8.mFilename;
        r1 = r11;
        r2 = r0;
        r1.notifyDownloadCompleted(r2, r3, r4, r5, r6, r7);
        goto L_0x00d8;
    L_0x007e:
        r0 = move-exception;
        goto L_0x00d9;
    L_0x0080:
        r0 = move-exception;
        r2 = "LVLDL";	 Catch:{ all -> 0x007e }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x007e }
        r3.<init>();	 Catch:{ all -> 0x007e }
        r4 = "Exception for ";	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r4 = r11.mInfo;	 Catch:{ all -> 0x007e }
        r4 = r4.mFileName;	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r4 = ": ";	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r3.append(r0);	 Catch:{ all -> 0x007e }
        r3 = r3.toString();	 Catch:{ all -> 0x007e }
        android.util.Log.w(r2, r3);	 Catch:{ all -> 0x007e }
        r0 = 491; // 0x1eb float:6.88E-43 double:2.426E-321;	 Catch:{ all -> 0x007e }
        if (r1 == 0) goto L_0x006a;	 Catch:{ all -> 0x007e }
    L_0x00a7:
        goto L_0x0064;	 Catch:{ all -> 0x007e }
    L_0x00a8:
        r0 = move-exception;	 Catch:{ all -> 0x007e }
        r2 = "LVLDL";	 Catch:{ all -> 0x007e }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x007e }
        r3.<init>();	 Catch:{ all -> 0x007e }
        r4 = "Aborting request for download ";	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r4 = r11.mInfo;	 Catch:{ all -> 0x007e }
        r4 = r4.mFileName;	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r4 = ": ";	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r4 = r0.getMessage();	 Catch:{ all -> 0x007e }
        r3.append(r4);	 Catch:{ all -> 0x007e }
        r3 = r3.toString();	 Catch:{ all -> 0x007e }
        android.util.Log.w(r2, r3);	 Catch:{ all -> 0x007e }
        r0.printStackTrace();	 Catch:{ all -> 0x007e }
        r2 = r0.mFinalStatus;	 Catch:{ all -> 0x007e }
        r0 = r2;
        if (r1 == 0) goto L_0x006a;
    L_0x00d7:
        goto L_0x0064;
    L_0x00d8:
        return;
    L_0x00d9:
        if (r1 == 0) goto L_0x00e1;
    L_0x00db:
        r1.release();
        r1 = 0;
        r10 = r1;
        goto L_0x00e2;
    L_0x00e1:
        r10 = r1;
    L_0x00e2:
        r11.cleanupDestination(r8, r9);
        r3 = r8.mCountRetry;
        r4 = r8.mRetryAfter;
        r5 = r8.mRedirectCount;
        r6 = r8.mGotData;
        r7 = r8.mFilename;
        r1 = r11;
        r2 = r9;
        r1.notifyDownloadCompleted(r2, r3, r4, r5, r6, r7);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.vending.expansion.downloader.impl.DownloadThread.run():void");
    }

    public DownloadThread(DownloadInfo info, DownloaderService service, DownloadNotification notification) {
        this.mContext = service;
        this.mInfo = info;
        this.mService = service;
        this.mNotification = notification;
        this.mDB = DownloadsDB.getDB(service);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("APKXDL (Linux; U; Android ");
        stringBuilder.append(VERSION.RELEASE);
        stringBuilder.append(";");
        stringBuilder.append(Locale.getDefault().toString());
        stringBuilder.append("; ");
        stringBuilder.append(Build.DEVICE);
        stringBuilder.append("/");
        stringBuilder.append(Build.ID);
        stringBuilder.append(")");
        stringBuilder.append(service.getPackageName());
        this.mUserAgent = stringBuilder.toString();
    }

    private String userAgent() {
        return this.mUserAgent;
    }

    private void executeDownload(State state, HttpURLConnection request) throws StopRequest, RetryDownload {
        InnerState innerState = new InnerState();
        byte[] data = new byte[4096];
        checkPausedOrCanceled(state);
        setupDestinationFile(state, innerState);
        addRequestHeaders(innerState, request);
        checkConnectivity(state);
        this.mNotification.onDownloadStateChanged(3);
        handleExceptionalStatus(state, innerState, request, sendRequest(state, request));
        processResponseHeaders(state, innerState, request);
        InputStream entityStream = openResponseEntity(state, request);
        this.mNotification.onDownloadStateChanged(4);
        transferData(state, innerState, data, entityStream);
    }

    private void checkConnectivity(State state) throws StopRequest {
        switch (this.mService.getNetworkAvailabilityState(this.mDB)) {
            case 1:
                return;
            case 2:
                throw new StopRequest(DownloaderService.STATUS_WAITING_FOR_NETWORK, "waiting for network to return");
            case 3:
                throw new StopRequest(DownloaderService.STATUS_QUEUED_FOR_WIFI, "waiting for wifi");
            case 5:
                throw new StopRequest(DownloaderService.STATUS_WAITING_FOR_NETWORK, "roaming is not allowed");
            case 6:
                throw new StopRequest(DownloaderService.STATUS_QUEUED_FOR_WIFI_OR_CELLULAR_PERMISSION, "waiting for wifi or for download over cellular to be authorized");
            default:
                return;
        }
    }

    private void transferData(State state, InnerState innerState, byte[] data, InputStream entityStream) throws StopRequest {
        while (true) {
            int bytesRead = readFromResponse(state, innerState, data, entityStream);
            if (bytesRead == -1) {
                handleEndOfStream(state, innerState);
                return;
            }
            state.mGotData = true;
            writeDataToDestination(state, data, bytesRead);
            innerState.mBytesSoFar += bytesRead;
            innerState.mBytesThisSession += bytesRead;
            reportProgress(state, innerState);
            checkPausedOrCanceled(state);
        }
    }

    private void finalizeDestinationFile(State state) throws StopRequest {
        syncDestination(state);
        String tempFilename = state.mFilename;
        String finalFilename = Helpers.generateSaveFileName(this.mService, this.mInfo.mFileName);
        if (!state.mFilename.equals(finalFilename)) {
            File startFile = new File(tempFilename);
            File destFile = new File(finalFilename);
            if (this.mInfo.mTotalBytes == -1 || this.mInfo.mCurrentBytes != this.mInfo.mTotalBytes) {
                throw new StopRequest(DownloaderService.STATUS_FILE_DELIVERED_INCORRECTLY, "file delivered with incorrect size. probably due to network not browser configured");
            } else if (!startFile.renameTo(destFile)) {
                throw new StopRequest(492, "unable to finalize destination file");
            }
        }
    }

    private void cleanupDestination(State state, int finalStatus) {
        closeDestination(state);
        if (state.mFilename != null && DownloaderService.isStatusError(finalStatus)) {
            new File(state.mFilename).delete();
            state.mFilename = null;
        }
    }

    private void closeDestination(State state) {
        try {
            if (state.mStream != null) {
                state.mStream.close();
                state.mStream = null;
            }
        } catch (IOException e) {
        }
    }

    private void checkPausedOrCanceled(State state) throws StopRequest {
        if (this.mService.getControl() != 1) {
            return;
        }
        if (this.mService.getStatus() == DownloaderService.STATUS_PAUSED_BY_APP) {
            throw new StopRequest(this.mService.getStatus(), "download paused");
        }
    }

    private void reportProgress(State state, InnerState innerState) {
        long now = System.currentTimeMillis();
        if (innerState.mBytesSoFar - innerState.mBytesNotified > 4096 && now - innerState.mTimeLastNotification > 1000) {
            this.mInfo.mCurrentBytes = (long) innerState.mBytesSoFar;
            this.mDB.updateDownloadCurrentBytes(this.mInfo);
            innerState.mBytesNotified = innerState.mBytesSoFar;
            innerState.mTimeLastNotification = now;
            this.mService.notifyUpdateBytes(((long) innerState.mBytesThisSession) + this.mService.mBytesSoFar);
        }
    }

    private void writeDataToDestination(State state, byte[] data, int bytesRead) throws StopRequest {
        try {
            if (state.mStream == null) {
                state.mStream = new FileOutputStream(state.mFilename, true);
            }
            state.mStream.write(data, 0, bytesRead);
            closeDestination(state);
        } catch (IOException ex) {
            if (!Helpers.isExternalMediaMounted()) {
                throw new StopRequest(499, "external media not mounted while writing destination file");
            } else if (Helpers.getAvailableBytes(Helpers.getFilesystemRoot(state.mFilename)) < ((long) bytesRead)) {
                throw new StopRequest(498, "insufficient space while writing destination file", ex);
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("while writing destination file: ");
                stringBuilder.append(ex.toString());
                throw new StopRequest(492, stringBuilder.toString(), ex);
            }
        }
    }

    private void handleEndOfStream(State state, InnerState innerState) throws StopRequest {
        boolean lengthMismatched;
        this.mInfo.mCurrentBytes = (long) innerState.mBytesSoFar;
        this.mDB.updateDownload(this.mInfo);
        if (innerState.mHeaderContentLength != null) {
            if (innerState.mBytesSoFar != Integer.parseInt(innerState.mHeaderContentLength)) {
                lengthMismatched = true;
                if (!lengthMismatched) {
                    if (cannotResume(innerState)) {
                        throw new StopRequest(getFinalStatusForHttpError(state), "closed socket before end of file");
                    }
                    throw new StopRequest(489, "mismatched content length");
                }
                return;
            }
        }
        lengthMismatched = false;
        if (!lengthMismatched) {
            return;
        }
        if (cannotResume(innerState)) {
            throw new StopRequest(getFinalStatusForHttpError(state), "closed socket before end of file");
        }
        throw new StopRequest(489, "mismatched content length");
    }

    private boolean cannotResume(InnerState innerState) {
        return innerState.mBytesSoFar > 0 && innerState.mHeaderETag == null;
    }

    private int readFromResponse(State state, InnerState innerState, byte[] data, InputStream entityStream) throws StopRequest {
        try {
            return entityStream.read(data);
        } catch (IOException ex) {
            logNetworkState();
            this.mInfo.mCurrentBytes = (long) innerState.mBytesSoFar;
            this.mDB.updateDownload(this.mInfo);
            if (cannotResume(innerState)) {
                String message = new StringBuilder();
                message.append("while reading response: ");
                message.append(ex.toString());
                message.append(", can't resume interrupted download with no ETag");
                throw new StopRequest(489, message.toString(), ex);
            }
            int finalStatusForHttpError = getFinalStatusForHttpError(state);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("while reading response: ");
            stringBuilder.append(ex.toString());
            throw new StopRequest(finalStatusForHttpError, stringBuilder.toString(), ex);
        }
    }

    private InputStream openResponseEntity(State state, HttpURLConnection response) throws StopRequest {
        try {
            return response.getInputStream();
        } catch (IOException ex) {
            logNetworkState();
            int finalStatusForHttpError = getFinalStatusForHttpError(state);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("while getting entity: ");
            stringBuilder.append(ex.toString());
            throw new StopRequest(finalStatusForHttpError, stringBuilder.toString(), ex);
        }
    }

    private void logNetworkState() {
        String str = Constants.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Net ");
        stringBuilder.append(this.mService.getNetworkAvailabilityState(this.mDB) == 1 ? "Up" : "Down");
        Log.i(str, stringBuilder.toString());
    }

    private void processResponseHeaders(State state, InnerState innerState, HttpURLConnection response) throws StopRequest {
        if (!innerState.mContinuingDownload) {
            readResponseHeaders(state, innerState, response);
            try {
                state.mFilename = this.mService.generateSaveFile(this.mInfo.mFileName, this.mInfo.mTotalBytes);
                try {
                    state.mStream = new FileOutputStream(state.mFilename);
                } catch (FileNotFoundException exc) {
                    try {
                        if (new File(Helpers.getSaveFilePath(this.mService)).mkdirs()) {
                            state.mStream = new FileOutputStream(state.mFilename);
                        }
                    } catch (Exception e) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("while opening destination file: ");
                        stringBuilder.append(exc.toString());
                        throw new StopRequest(492, stringBuilder.toString(), exc);
                    }
                }
                updateDatabaseFromHeaders(state, innerState);
                checkConnectivity(state);
            } catch (GenerateSaveFileError exc2) {
                throw new StopRequest(exc2.mStatus, exc2.mMessage);
            }
        }
    }

    private void updateDatabaseFromHeaders(State state, InnerState innerState) {
        this.mInfo.mETag = innerState.mHeaderETag;
        this.mDB.updateDownload(this.mInfo);
    }

    private void readResponseHeaders(State state, InnerState innerState, HttpURLConnection response) throws StopRequest {
        boolean noSizeInfo;
        String value = response.getHeaderField(MIME.CONTENT_DISPOSITION);
        if (value != null) {
            innerState.mHeaderContentDisposition = value;
        }
        value = response.getHeaderField(HttpHeaders.CONTENT_LOCATION);
        if (value != null) {
            innerState.mHeaderContentLocation = value;
        }
        value = response.getHeaderField(HttpHeaders.ETAG);
        if (value != null) {
            innerState.mHeaderETag = value;
        }
        String headerTransferEncoding = null;
        value = response.getHeaderField("Transfer-Encoding");
        if (value != null) {
            headerTransferEncoding = value;
        }
        value = response.getHeaderField("Content-Type");
        if (value != null) {
            if (!value.equals("application/vnd.android.obb")) {
                throw new StopRequest(DownloaderService.STATUS_FILE_DELIVERED_INCORRECTLY, "file delivered with incorrect Mime type");
            }
        }
        if (headerTransferEncoding == null) {
            long contentLength = (long) response.getContentLength();
            if (value != null) {
                if (contentLength == -1 || contentLength == this.mInfo.mTotalBytes) {
                    innerState.mHeaderContentLength = Long.toString(contentLength);
                } else {
                    Log.e(Constants.TAG, "Incorrect file size delivered.");
                }
            }
        }
        if (innerState.mHeaderContentLength == null) {
            if (headerTransferEncoding != null) {
                if (headerTransferEncoding.equalsIgnoreCase(HTTP.CHUNK_CODING)) {
                }
            }
            noSizeInfo = true;
            if (!noSizeInfo) {
                throw new StopRequest(495, "can't know size of download, giving up");
            }
        }
        noSizeInfo = false;
        if (!noSizeInfo) {
            throw new StopRequest(495, "can't know size of download, giving up");
        }
    }

    private void handleExceptionalStatus(State state, InnerState innerState, HttpURLConnection connection, int responseCode) throws StopRequest, RetryDownload {
        if (responseCode == HttpStatus.SC_SERVICE_UNAVAILABLE && this.mInfo.mNumFailed < 5) {
            handleServiceUnavailable(state, connection);
        }
        if (responseCode != (innerState.mContinuingDownload ? HttpStatus.SC_PARTIAL_CONTENT : 200)) {
            handleOtherStatus(state, innerState, responseCode);
        } else {
            state.mRedirectCount = 0;
        }
    }

    private void handleOtherStatus(State state, InnerState innerState, int statusCode) throws StopRequest {
        int finalStatus;
        if (DownloaderService.isStatusError(statusCode)) {
            finalStatus = statusCode;
        } else {
            if (statusCode >= HttpStatus.SC_MULTIPLE_CHOICES) {
                if (statusCode < 400) {
                    finalStatus = 493;
                }
            }
            if (innerState.mContinuingDownload && statusCode == 200) {
                finalStatus = 489;
            } else {
                finalStatus = 494;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("http error ");
        stringBuilder.append(statusCode);
        throw new StopRequest(finalStatus, stringBuilder.toString());
    }

    private void addRequestHeaders(InnerState innerState, HttpURLConnection request) {
        if (innerState.mContinuingDownload) {
            if (innerState.mHeaderETag != null) {
                request.setRequestProperty(HttpHeaders.IF_MATCH, innerState.mHeaderETag);
            }
            String str = HttpHeaders.RANGE;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bytes=");
            stringBuilder.append(innerState.mBytesSoFar);
            stringBuilder.append(Constants.FILENAME_SEQUENCE_SEPARATOR);
            request.setRequestProperty(str, stringBuilder.toString());
        }
    }

    private void handleServiceUnavailable(State state, HttpURLConnection connection) throws StopRequest {
        state.mCountRetry = true;
        String retryAfterValue = connection.getHeaderField(HttpHeaders.RETRY_AFTER);
        if (retryAfterValue != null) {
            try {
                state.mRetryAfter = Integer.parseInt(retryAfterValue);
                if (state.mRetryAfter >= 0) {
                    if (state.mRetryAfter < 30) {
                        state.mRetryAfter = 30;
                    } else if (state.mRetryAfter > Constants.MAX_RETRY_AFTER) {
                        state.mRetryAfter = Constants.MAX_RETRY_AFTER;
                    }
                    state.mRetryAfter += Helpers.sRandom.nextInt(31);
                    state.mRetryAfter *= 1000;
                } else {
                    state.mRetryAfter = 0;
                }
            } catch (NumberFormatException e) {
            }
        }
        throw new StopRequest(DownloaderService.STATUS_WAITING_TO_RETRY, "got 503 Service Unavailable, will retry later");
    }

    private int sendRequest(State state, HttpURLConnection request) throws StopRequest {
        StringBuilder stringBuilder;
        try {
            return request.getResponseCode();
        } catch (IllegalArgumentException ex) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("while trying to execute request: ");
            stringBuilder.append(ex.toString());
            throw new StopRequest(495, stringBuilder.toString(), ex);
        } catch (IOException ex2) {
            logNetworkState();
            int finalStatusForHttpError = getFinalStatusForHttpError(state);
            stringBuilder = new StringBuilder();
            stringBuilder.append("while trying to execute request: ");
            stringBuilder.append(ex2.toString());
            throw new StopRequest(finalStatusForHttpError, stringBuilder.toString(), ex2);
        }
    }

    private int getFinalStatusForHttpError(State state) {
        if (this.mService.getNetworkAvailabilityState(this.mDB) != 1) {
            return DownloaderService.STATUS_WAITING_FOR_NETWORK;
        }
        if (this.mInfo.mNumFailed < 5) {
            state.mCountRetry = true;
            return DownloaderService.STATUS_WAITING_TO_RETRY;
        }
        String str = Constants.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reached max retries for ");
        stringBuilder.append(this.mInfo.mNumFailed);
        Log.w(str, stringBuilder.toString());
        return 495;
    }

    private void setupDestinationFile(State state, InnerState innerState) throws StopRequest {
        if (state.mFilename != null) {
            if (Helpers.isFilenameValid(state.mFilename)) {
                File f = new File(state.mFilename);
                if (f.exists()) {
                    long fileLength = f.length();
                    if (fileLength == 0) {
                        f.delete();
                        state.mFilename = null;
                    } else if (this.mInfo.mETag != null) {
                        try {
                            state.mStream = new FileOutputStream(state.mFilename, true);
                            innerState.mBytesSoFar = (int) fileLength;
                            if (this.mInfo.mTotalBytes != -1) {
                                innerState.mHeaderContentLength = Long.toString(this.mInfo.mTotalBytes);
                            }
                            innerState.mHeaderETag = this.mInfo.mETag;
                            innerState.mContinuingDownload = true;
                        } catch (FileNotFoundException exc) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("while opening destination for resuming: ");
                            stringBuilder.append(exc.toString());
                            throw new StopRequest(492, stringBuilder.toString(), exc);
                        }
                    } else {
                        f.delete();
                        throw new StopRequest(489, "Trying to resume a download that can't be resumed");
                    }
                }
            } else {
                throw new StopRequest(492, "found invalid internal destination filename");
            }
        }
        if (state.mStream != null) {
            closeDestination(state);
        }
    }

    private void notifyDownloadCompleted(int status, boolean countRetry, int retryAfter, int redirectCount, boolean gotData, String filename) {
        updateDownloadDatabase(status, countRetry, retryAfter, redirectCount, gotData, filename);
        DownloaderService.isStatusCompleted(status);
    }

    private void updateDownloadDatabase(int status, boolean countRetry, int retryAfter, int redirectCount, boolean gotData, String filename) {
        DownloadInfo downloadInfo = this.mInfo;
        downloadInfo.mStatus = status;
        downloadInfo.mRetryAfter = retryAfter;
        downloadInfo.mRedirectCount = redirectCount;
        downloadInfo.mLastMod = System.currentTimeMillis();
        if (!countRetry) {
            this.mInfo.mNumFailed = 0;
        } else if (gotData) {
            this.mInfo.mNumFailed = 1;
        } else {
            DownloadInfo downloadInfo2 = this.mInfo;
            downloadInfo2.mNumFailed++;
        }
        this.mDB.updateDownload(this.mInfo);
    }
}
