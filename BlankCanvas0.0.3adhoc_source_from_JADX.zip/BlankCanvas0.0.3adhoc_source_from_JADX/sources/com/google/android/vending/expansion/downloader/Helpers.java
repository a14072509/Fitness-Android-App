package com.google.android.vending.expansion.downloader;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import android.util.Log;
import com.android.vending.expansion.downloader.C0236R;
import com.eachscape.util.TimeUtils;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Helpers {
    private static final Pattern CONTENT_DISPOSITION_PATTERN = Pattern.compile("attachment;\\s*filename\\s*=\\s*\"([^\"]*)\"");
    public static final int FS_CANNOT_READ = 2;
    public static final int FS_DOES_NOT_EXIST = 1;
    public static final int FS_READABLE = 0;
    public static Random sRandom = new Random(SystemClock.uptimeMillis());

    private Helpers() {
    }

    static String parseContentDisposition(String contentDisposition) {
        try {
            Matcher m = CONTENT_DISPOSITION_PATTERN.matcher(contentDisposition);
            if (m.find()) {
                return m.group(1);
            }
            return null;
        } catch (IllegalStateException e) {
        }
    }

    public static File getFilesystemRoot(String path) {
        File cache = Environment.getDownloadCacheDirectory();
        if (path.startsWith(cache.getPath())) {
            return cache;
        }
        File external = Environment.getExternalStorageDirectory();
        if (path.startsWith(external.getPath())) {
            return external;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot determine filesystem root for ");
        stringBuilder.append(path);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static boolean isExternalMediaMounted() {
        if (Environment.getExternalStorageState().equals("mounted")) {
            return true;
        }
        return false;
    }

    public static long getAvailableBytes(File root) {
        StatFs stat = new StatFs(root.getPath());
        return ((long) stat.getBlockSize()) * (((long) stat.getAvailableBlocks()) - 4);
    }

    public static boolean isFilenameValid(String filename) {
        filename = filename.replaceFirst("/+", "/");
        if (!filename.startsWith(Environment.getDownloadCacheDirectory().toString())) {
            if (!filename.startsWith(Environment.getExternalStorageDirectory().toString())) {
                return false;
            }
        }
        return true;
    }

    static void deleteFile(String path) {
        try {
            new File(path).delete();
        } catch (Exception e) {
            String str = Constants.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("file: '");
            stringBuilder.append(path);
            stringBuilder.append("' couldn't be deleted");
            Log.w(str, stringBuilder.toString(), e);
        }
    }

    public static String getDownloadProgressString(long overallProgress, long overallTotal) {
        if (overallTotal == 0) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("%.2f", new Object[]{Float.valueOf(((float) overallProgress) / 1048576.0f)}));
        stringBuilder.append("MB /");
        stringBuilder.append(String.format("%.2f", new Object[]{Float.valueOf(((float) overallTotal) / 1048576.0f)}));
        stringBuilder.append("MB");
        return stringBuilder.toString();
    }

    public static String getDownloadProgressStringNotification(long overallProgress, long overallTotal) {
        if (overallTotal == 0) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getDownloadProgressString(overallProgress, overallTotal));
        stringBuilder.append(" (");
        stringBuilder.append(getDownloadProgressPercent(overallProgress, overallTotal));
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public static String getDownloadProgressPercent(long overallProgress, long overallTotal) {
        if (overallTotal == 0) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Long.toString((100 * overallProgress) / overallTotal));
        stringBuilder.append("%");
        return stringBuilder.toString();
    }

    public static String getSpeedString(float bytesPerMillisecond) {
        return String.format("%.2f", new Object[]{Float.valueOf((1000.0f * bytesPerMillisecond) / 1024.0f)});
    }

    public static String getTimeRemaining(long durationInMilliseconds) {
        SimpleDateFormat sdf;
        if (durationInMilliseconds > TimeUtils.ONE_HOUR) {
            sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        } else {
            sdf = new SimpleDateFormat("mm:ss", Locale.getDefault());
        }
        return sdf.format(new Date(durationInMilliseconds - ((long) TimeZone.getDefault().getRawOffset())));
    }

    public static String getExpansionAPKFileName(Context c, boolean mainFile, int versionCode) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(mainFile ? "main." : "patch.");
        stringBuilder.append(versionCode);
        stringBuilder.append(".");
        stringBuilder.append(c.getPackageName());
        stringBuilder.append(".obb");
        return stringBuilder.toString();
    }

    public static String generateSaveFileName(Context c, String fileName) {
        String path = new StringBuilder();
        path.append(getSaveFilePath(c));
        path.append(File.separator);
        path.append(fileName);
        return path.toString();
    }

    @TargetApi(11)
    public static String getSaveFilePath(Context c) {
        if (VERSION.SDK_INT >= 19) {
            return c.getObbDir().toString();
        }
        File root = Environment.getExternalStorageDirectory();
        String path = new StringBuilder();
        path.append(root.toString());
        path.append(Constants.EXP_PATH);
        path.append(c.getPackageName());
        return path.toString();
    }

    public static boolean doesFileExist(Context c, String fileName, long fileSize, boolean deleteFileOnMismatch) {
        File fileForNewFile = new File(generateSaveFileName(c, fileName));
        if (fileForNewFile.exists()) {
            if (fileForNewFile.length() == fileSize) {
                return true;
            }
            if (deleteFileOnMismatch) {
                fileForNewFile.delete();
            }
        }
        return false;
    }

    public static int getFileStatus(Context c, String fileName) {
        File fileForNewFile = new File(generateSaveFileName(c, fileName));
        if (!fileForNewFile.exists()) {
            return 1;
        }
        if (fileForNewFile.canRead()) {
            return 0;
        }
        return 2;
    }

    public static boolean canWriteOBBFile(Context c) {
        File fileForNewFile = new File(getSaveFilePath(c));
        if (!fileForNewFile.exists()) {
            return fileForNewFile.mkdirs();
        }
        boolean canWrite = fileForNewFile.isDirectory() && fileForNewFile.canWrite();
        return canWrite;
    }

    public static int getDownloaderStringResourceIDFromState(int state) {
        switch (state) {
            case 1:
                return C0236R.string.state_idle;
            case 2:
                return C0236R.string.state_fetching_url;
            case 3:
                return C0236R.string.state_connecting;
            case 4:
                return C0236R.string.state_downloading;
            case 5:
                return C0236R.string.state_completed;
            case 6:
                return C0236R.string.state_paused_network_unavailable;
            case 7:
                return C0236R.string.state_paused_by_request;
            case 8:
                return C0236R.string.state_paused_wifi_disabled;
            case 9:
                return C0236R.string.state_paused_wifi_unavailable;
            case 10:
                return C0236R.string.state_paused_wifi_disabled;
            case 11:
                return C0236R.string.state_paused_wifi_unavailable;
            case 12:
                return C0236R.string.state_paused_roaming;
            case 13:
                return C0236R.string.state_paused_network_setup_failure;
            case 14:
                return C0236R.string.state_paused_sdcard_unavailable;
            case 15:
                return C0236R.string.state_failed_unlicensed;
            case 16:
                return C0236R.string.state_failed_fetching_url;
            case 17:
                return C0236R.string.state_failed_sdcard_full;
            case 18:
                return C0236R.string.state_failed_cancelled;
            default:
                return C0236R.string.state_unknown;
        }
    }
}
