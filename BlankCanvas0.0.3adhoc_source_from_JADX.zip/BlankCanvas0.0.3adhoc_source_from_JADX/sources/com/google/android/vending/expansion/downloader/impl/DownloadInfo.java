package com.google.android.vending.expansion.downloader.impl;

import android.util.Log;
import com.google.android.vending.expansion.downloader.Constants;
import com.google.android.vending.expansion.downloader.Helpers;

public class DownloadInfo {
    public int mControl;
    public long mCurrentBytes;
    public String mETag;
    public final String mFileName;
    public int mFuzz = Helpers.sRandom.nextInt(1001);
    public final int mIndex;
    boolean mInitialized;
    public long mLastMod;
    public int mNumFailed;
    public int mRedirectCount;
    public int mRetryAfter;
    public int mStatus;
    public long mTotalBytes;
    public String mUri;

    public DownloadInfo(int index, String fileName, String pkg) {
        this.mFileName = fileName;
        this.mIndex = index;
    }

    public void resetDownload() {
        this.mCurrentBytes = 0;
        this.mETag = "";
        this.mLastMod = 0;
        this.mStatus = 0;
        this.mControl = 0;
        this.mNumFailed = 0;
        this.mRetryAfter = 0;
        this.mRedirectCount = 0;
    }

    public long restartTime(long now) {
        int i = this.mNumFailed;
        if (i == 0) {
            return now;
        }
        int i2 = this.mRetryAfter;
        if (i2 > 0) {
            return this.mLastMod + ((long) i2);
        }
        return this.mLastMod + ((long) (((this.mFuzz + 1000) * 30) * (1 << (i - 1))));
    }

    public void logVerboseInfo() {
        Log.v(Constants.TAG, "Service adding new entry");
        String str = Constants.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FILENAME: ");
        stringBuilder.append(this.mFileName);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("URI     : ");
        stringBuilder.append(this.mUri);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("FILENAME: ");
        stringBuilder.append(this.mFileName);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("CONTROL : ");
        stringBuilder.append(this.mControl);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("STATUS  : ");
        stringBuilder.append(this.mStatus);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("FAILED_C: ");
        stringBuilder.append(this.mNumFailed);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("RETRY_AF: ");
        stringBuilder.append(this.mRetryAfter);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("REDIRECT: ");
        stringBuilder.append(this.mRedirectCount);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("LAST_MOD: ");
        stringBuilder.append(this.mLastMod);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("TOTAL   : ");
        stringBuilder.append(this.mTotalBytes);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("CURRENT : ");
        stringBuilder.append(this.mCurrentBytes);
        Log.v(str, stringBuilder.toString());
        str = Constants.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("ETAG    : ");
        stringBuilder.append(this.mETag);
        Log.v(str, stringBuilder.toString());
    }
}
