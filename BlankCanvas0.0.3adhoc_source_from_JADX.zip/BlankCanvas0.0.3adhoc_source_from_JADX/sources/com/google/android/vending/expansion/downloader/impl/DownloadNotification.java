package com.google.android.vending.expansion.downloader.impl;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Messenger;
import android.support.v4.app.NotificationCompat.Builder;
import com.android.vending.expansion.downloader.C0236R;
import com.google.android.vending.expansion.downloader.DownloadProgressInfo;
import com.google.android.vending.expansion.downloader.DownloaderClientMarshaller;
import com.google.android.vending.expansion.downloader.Helpers;
import com.google.android.vending.expansion.downloader.IDownloaderClient;

public class DownloadNotification implements IDownloaderClient {
    static final String LOGTAG = "DownloadNotification";
    static final int NOTIFICATION_ID = LOGTAG.hashCode();
    private Builder mActiveDownloadBuilder;
    private Builder mBuilder;
    private IDownloaderClient mClientProxy;
    private PendingIntent mContentIntent;
    private final Context mContext;
    private Builder mCurrentBuilder;
    private String mCurrentText;
    private CharSequence mCurrentTitle;
    private CharSequence mLabel;
    private final NotificationManager mNotificationManager;
    private DownloadProgressInfo mProgressInfo;
    private int mState = -1;

    public PendingIntent getClientIntent() {
        return this.mContentIntent;
    }

    public void setClientIntent(PendingIntent clientIntent) {
        this.mBuilder.setContentIntent(clientIntent);
        this.mActiveDownloadBuilder.setContentIntent(clientIntent);
        this.mContentIntent = clientIntent;
    }

    public void resendState() {
        IDownloaderClient iDownloaderClient = this.mClientProxy;
        if (iDownloaderClient != null) {
            iDownloaderClient.onDownloadStateChanged(this.mState);
        }
    }

    public void onDownloadStateChanged(int newState) {
        IDownloaderClient iDownloaderClient = this.mClientProxy;
        if (iDownloaderClient != null) {
            iDownloaderClient.onDownloadStateChanged(newState);
        }
        if (newState != this.mState) {
            this.mState = newState;
            if (newState != 1) {
                if (this.mContentIntent != null) {
                    int iconResource;
                    int stringDownloadID;
                    boolean ongoingEvent;
                    if (newState != 0) {
                        if (newState != 7) {
                            switch (newState) {
                                case 2:
                                case 3:
                                    iconResource = 17301634;
                                    stringDownloadID = Helpers.getDownloaderStringResourceIDFromState(newState);
                                    ongoingEvent = true;
                                    break;
                                case 4:
                                    iconResource = 17301633;
                                    stringDownloadID = Helpers.getDownloaderStringResourceIDFromState(newState);
                                    ongoingEvent = true;
                                    break;
                                case 5:
                                    break;
                                default:
                                    switch (newState) {
                                        case 15:
                                        case 16:
                                        case 17:
                                        case 18:
                                        case 19:
                                            iconResource = 17301642;
                                            stringDownloadID = Helpers.getDownloaderStringResourceIDFromState(newState);
                                            ongoingEvent = false;
                                            break;
                                        default:
                                            iconResource = 17301642;
                                            stringDownloadID = Helpers.getDownloaderStringResourceIDFromState(newState);
                                            ongoingEvent = true;
                                            break;
                                    }
                            }
                        }
                        iconResource = 17301634;
                        stringDownloadID = Helpers.getDownloaderStringResourceIDFromState(newState);
                        ongoingEvent = false;
                    } else {
                        iconResource = 17301642;
                        stringDownloadID = C0236R.string.state_unknown;
                        ongoingEvent = false;
                    }
                    this.mCurrentText = this.mContext.getString(stringDownloadID);
                    this.mCurrentTitle = this.mLabel;
                    Builder builder = this.mCurrentBuilder;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(this.mLabel);
                    stringBuilder.append(": ");
                    stringBuilder.append(this.mCurrentText);
                    builder.setTicker(stringBuilder.toString());
                    this.mCurrentBuilder.setSmallIcon(iconResource);
                    this.mCurrentBuilder.setContentTitle(this.mCurrentTitle);
                    this.mCurrentBuilder.setContentText(this.mCurrentText);
                    if (ongoingEvent) {
                        this.mCurrentBuilder.setOngoing(true);
                    } else {
                        this.mCurrentBuilder.setOngoing(false);
                        this.mCurrentBuilder.setAutoCancel(true);
                    }
                    this.mNotificationManager.notify(NOTIFICATION_ID, this.mCurrentBuilder.build());
                }
            }
        }
    }

    public void onDownloadProgress(DownloadProgressInfo progress) {
        this.mProgressInfo = progress;
        IDownloaderClient iDownloaderClient = this.mClientProxy;
        if (iDownloaderClient != null) {
            iDownloaderClient.onDownloadProgress(progress);
        }
        if (progress.mOverallTotal <= 0) {
            this.mBuilder.setTicker(this.mCurrentTitle);
            this.mBuilder.setSmallIcon(17301633);
            this.mBuilder.setContentTitle(this.mCurrentTitle);
            this.mBuilder.setContentText(this.mCurrentText);
            this.mCurrentBuilder = this.mBuilder;
        } else {
            this.mActiveDownloadBuilder.setProgress((int) progress.mOverallTotal, (int) progress.mOverallProgress, false);
            this.mActiveDownloadBuilder.setContentText(Helpers.getDownloadProgressString(progress.mOverallProgress, progress.mOverallTotal));
            this.mActiveDownloadBuilder.setSmallIcon(17301633);
            Builder builder = this.mActiveDownloadBuilder;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.mLabel);
            stringBuilder.append(": ");
            stringBuilder.append(this.mCurrentText);
            builder.setTicker(stringBuilder.toString());
            this.mActiveDownloadBuilder.setContentTitle(this.mLabel);
            this.mActiveDownloadBuilder.setContentInfo(this.mContext.getString(C0236R.string.time_remaining_notification, new Object[]{Helpers.getTimeRemaining(progress.mTimeRemaining)}));
            this.mCurrentBuilder = this.mActiveDownloadBuilder;
        }
        this.mNotificationManager.notify(NOTIFICATION_ID, this.mCurrentBuilder.build());
    }

    public void setMessenger(Messenger msg) {
        this.mClientProxy = DownloaderClientMarshaller.CreateProxy(msg);
        DownloadProgressInfo downloadProgressInfo = this.mProgressInfo;
        if (downloadProgressInfo != null) {
            this.mClientProxy.onDownloadProgress(downloadProgressInfo);
        }
        int i = this.mState;
        if (i != -1) {
            this.mClientProxy.onDownloadStateChanged(i);
        }
    }

    DownloadNotification(Context ctx, CharSequence applicationLabel) {
        this.mContext = ctx;
        this.mLabel = applicationLabel;
        this.mNotificationManager = (NotificationManager) this.mContext.getSystemService("notification");
        this.mActiveDownloadBuilder = new Builder(ctx);
        this.mBuilder = new Builder(ctx);
        this.mActiveDownloadBuilder.setPriority(-1);
        this.mActiveDownloadBuilder.setCategory("progress");
        this.mBuilder.setPriority(-1);
        this.mBuilder.setCategory("progress");
        this.mCurrentBuilder = this.mBuilder;
    }

    public void onServiceConnected(Messenger m) {
    }
}
