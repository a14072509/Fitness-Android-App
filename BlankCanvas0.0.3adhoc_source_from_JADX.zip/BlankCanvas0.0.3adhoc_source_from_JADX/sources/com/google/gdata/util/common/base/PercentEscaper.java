package com.google.gdata.util.common.base;

import android.support.v4.internal.view.SupportMenu;
import org.codehaus.jackson.util.MinimalPrettyPrinter;

public class PercentEscaper extends UnicodeEscaper {
    public static final String SAFECHARS_URLENCODER = "-_.*";
    public static final String SAFEPATHCHARS_URLENCODER = "-_.!~*'()@:$&,;=";
    public static final String SAFEQUERYSTRINGCHARS_URLENCODER = "-_.!~*'()@:$,;/?:";
    private static final char[] UPPER_HEX_DIGITS = "0123456789ABCDEF".toCharArray();
    private static final char[] URI_ESCAPED_SPACE = new char[]{'+'};
    private final boolean plusForSpace;
    private final boolean[] safeOctets;

    public PercentEscaper(String safeChars, boolean plusForSpace) {
        if (safeChars.matches(".*[0-9A-Za-z].*")) {
            throw new IllegalArgumentException("Alphanumeric characters are always 'safe' and should not be explicitly specified");
        }
        if (plusForSpace) {
            if (safeChars.contains(MinimalPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR)) {
                throw new IllegalArgumentException("plusForSpace cannot be specified when space is a 'safe' character");
            }
        }
        if (safeChars.contains("%")) {
            throw new IllegalArgumentException("The '%' character cannot be specified as 'safe'");
        }
        this.plusForSpace = plusForSpace;
        this.safeOctets = createSafeOctets(safeChars);
    }

    private static boolean[] createSafeOctets(String safeChars) {
        int len$;
        int maxChar = 122;
        char[] safeCharArray = safeChars.toCharArray();
        for (char c : safeCharArray) {
            maxChar = Math.max(c, maxChar);
        }
        boolean[] octets = new boolean[(maxChar + 1)];
        for (len$ = 48; len$ <= 57; len$++) {
            octets[len$] = true;
        }
        for (len$ = 65; len$ <= 90; len$++) {
            octets[len$] = true;
        }
        for (len$ = 97; len$ <= 122; len$++) {
            octets[len$] = true;
        }
        for (char c2 : safeCharArray) {
            octets[c2] = true;
        }
        return octets;
    }

    protected int nextEscapeIndex(CharSequence csq, int index, int end) {
        while (index < end) {
            char c = csq.charAt(index);
            boolean[] zArr = this.safeOctets;
            if (c >= zArr.length) {
                break;
            } else if (!zArr[c]) {
                break;
            } else {
                index++;
            }
        }
        return index;
    }

    public String escape(String s) {
        int slen = s.length();
        int index = 0;
        while (index < slen) {
            char c = s.charAt(index);
            boolean[] zArr = this.safeOctets;
            if (c < zArr.length) {
                if (zArr[c]) {
                    index++;
                }
            }
            return escapeSlow(s, index);
        }
        return s;
    }

    protected char[] escape(int cp) {
        boolean[] zArr = this.safeOctets;
        if (cp < zArr.length && zArr[cp]) {
            return null;
        }
        if (cp == 32 && this.plusForSpace) {
            return URI_ESCAPED_SPACE;
        }
        char[] dest;
        char[] cArr;
        if (cp <= 127) {
            dest = new char[3];
            cArr = UPPER_HEX_DIGITS;
            dest[2] = cArr[cp & 15];
            dest[1] = cArr[cp >>> 4];
            return dest;
        } else if (cp <= 2047) {
            dest = new char[6];
            cArr = UPPER_HEX_DIGITS;
            dest[5] = cArr[cp & 15];
            cp >>>= 4;
            dest[4] = cArr[(cp & 3) | 8];
            cp >>>= 2;
            dest[2] = cArr[cp & 15];
            dest[1] = cArr[(cp >>> 4) | 12];
            return dest;
        } else if (cp <= SupportMenu.USER_MASK) {
            dest = new char[9];
            dest[0] = '%';
            dest[1] = 'E';
            dest[3] = '%';
            dest[6] = '%';
            char[] cArr2 = UPPER_HEX_DIGITS;
            dest[8] = cArr2[cp & 15];
            cp >>>= 4;
            dest[7] = cArr2[(cp & 3) | 8];
            cp >>>= 2;
            dest[5] = cArr2[cp & 15];
            cp >>>= 4;
            dest[4] = cArr2[(cp & 3) | 8];
            dest[2] = cArr2[cp >>> 2];
            return dest;
        } else if (cp <= 1114111) {
            dest = new char[12];
            dest[0] = '%';
            dest[1] = 'F';
            dest[3] = '%';
            dest[6] = '%';
            dest[9] = '%';
            cArr = UPPER_HEX_DIGITS;
            dest[11] = cArr[cp & 15];
            cp >>>= 4;
            dest[10] = cArr[(cp & 3) | 8];
            cp >>>= 2;
            dest[8] = cArr[cp & 15];
            cp >>>= 4;
            dest[7] = cArr[(cp & 3) | 8];
            cp >>>= 2;
            dest[5] = cArr[cp & 15];
            cp >>>= 4;
            dest[4] = cArr[(cp & 3) | 8];
            dest[2] = cArr[(cp >>> 2) & 7];
            return dest;
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid unicode character value ");
            stringBuilder.append(cp);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
    }
}
