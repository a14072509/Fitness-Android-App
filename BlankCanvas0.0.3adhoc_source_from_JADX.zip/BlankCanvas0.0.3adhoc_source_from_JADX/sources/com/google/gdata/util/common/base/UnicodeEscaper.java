package com.google.gdata.util.common.base;

import java.io.IOException;

public abstract class UnicodeEscaper implements Escaper {
    private static final int DEST_PAD = 32;
    private static final ThreadLocal<char[]> DEST_TL = new C05262();

    /* renamed from: com.google.gdata.util.common.base.UnicodeEscaper$2 */
    static class C05262 extends ThreadLocal<char[]> {
        C05262() {
        }

        protected char[] initialValue() {
            return new char[1024];
        }
    }

    protected abstract char[] escape(int i);

    protected int nextEscapeIndex(CharSequence csq, int start, int end) {
        int index = start;
        while (index < end) {
            int cp = codePointAt(csq, index, end);
            if (cp < 0) {
                break;
            } else if (escape(cp) != null) {
                break;
            } else {
                index += Character.isSupplementaryCodePoint(cp) ? 2 : 1;
            }
        }
        return index;
    }

    public String escape(String string) {
        int end = string.length();
        int index = nextEscapeIndex(string, 0, end);
        return index == end ? string : escapeSlow(string, index);
    }

    protected final String escapeSlow(String s, int index) {
        int cp;
        int end = s.length();
        char[] dest = (char[]) DEST_TL.get();
        int destIndex = 0;
        int unescapedChunkStart = 0;
        while (index < end) {
            cp = codePointAt(s, index, end);
            if (cp >= 0) {
                char[] escaped = escape(cp);
                if (escaped != null) {
                    int charsSkipped = index - unescapedChunkStart;
                    int sizeNeeded = (destIndex + charsSkipped) + escaped.length;
                    if (dest.length < sizeNeeded) {
                        dest = growBuffer(dest, destIndex, ((end - index) + sizeNeeded) + 32);
                    }
                    if (charsSkipped > 0) {
                        s.getChars(unescapedChunkStart, index, dest, destIndex);
                        destIndex += charsSkipped;
                    }
                    if (escaped.length > 0) {
                        System.arraycopy(escaped, 0, dest, destIndex, escaped.length);
                        destIndex += escaped.length;
                    }
                }
                unescapedChunkStart = index + (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
                index = nextEscapeIndex(s, unescapedChunkStart, end);
            } else {
                throw new IllegalArgumentException("Trailing high surrogate at end of input");
            }
        }
        cp = end - unescapedChunkStart;
        if (cp > 0) {
            int endIndex = destIndex + cp;
            if (dest.length < endIndex) {
                dest = growBuffer(dest, destIndex, endIndex);
            }
            s.getChars(unescapedChunkStart, end, dest, destIndex);
            destIndex = endIndex;
        }
        return new String(dest, 0, destIndex);
    }

    public Appendable escape(final Appendable out) {
        Preconditions.checkNotNull(out);
        return new Appendable() {
            char[] decodedChars = new char[2];
            int pendingHighSurrogate = -1;

            public Appendable append(CharSequence csq) throws IOException {
                return append(csq, 0, csq.length());
            }

            /* JADX WARNING: inconsistent code. */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public java.lang.Appendable append(java.lang.CharSequence r8, int r9, int r10) throws java.io.IOException {
                /*
                r7 = this;
                r0 = r9;
                if (r0 >= r10) goto L_0x0090;
            L_0x0003:
                r1 = r0;
                r2 = r7.pendingHighSurrogate;
                r3 = -1;
                if (r2 == r3) goto L_0x004e;
            L_0x0009:
                r2 = r0 + 1;
                r0 = r8.charAt(r0);
                r4 = java.lang.Character.isLowSurrogate(r0);
                if (r4 == 0) goto L_0x0037;
            L_0x0015:
                r4 = com.google.gdata.util.common.base.UnicodeEscaper.this;
                r5 = r7.pendingHighSurrogate;
                r5 = (char) r5;
                r5 = java.lang.Character.toCodePoint(r5, r0);
                r4 = r4.escape(r5);
                if (r4 == 0) goto L_0x002b;
            L_0x0024:
                r5 = r4.length;
                r7.outputChars(r4, r5);
                r1 = r1 + 1;
                goto L_0x0033;
            L_0x002b:
                r5 = r2;
                r6 = r7.pendingHighSurrogate;
                r6 = (char) r6;
                r5.append(r6);
            L_0x0033:
                r7.pendingHighSurrogate = r3;
                r0 = r2;
                goto L_0x004f;
            L_0x0037:
                r3 = new java.lang.IllegalArgumentException;
                r4 = new java.lang.StringBuilder;
                r4.<init>();
                r5 = "Expected low surrogate character but got ";
                r4.append(r5);
                r4.append(r0);
                r4 = r4.toString();
                r3.<init>(r4);
                throw r3;
            L_0x004f:
                r2 = com.google.gdata.util.common.base.UnicodeEscaper.this;
                r0 = r2.nextEscapeIndex(r8, r0, r10);
                if (r0 <= r1) goto L_0x005d;
            L_0x0057:
                r2 = r2;
                r2.append(r8, r1, r0);
                goto L_0x005e;
            L_0x005e:
                if (r0 != r10) goto L_0x0061;
            L_0x0060:
                goto L_0x0091;
            L_0x0061:
                r2 = com.google.gdata.util.common.base.UnicodeEscaper.codePointAt(r8, r0, r10);
                if (r2 >= 0) goto L_0x006b;
            L_0x0067:
                r3 = -r2;
                r7.pendingHighSurrogate = r3;
                goto L_0x0091;
            L_0x006b:
                r3 = com.google.gdata.util.common.base.UnicodeEscaper.this;
                r3 = r3.escape(r2);
                if (r3 == 0) goto L_0x0078;
            L_0x0073:
                r4 = r3.length;
                r7.outputChars(r3, r4);
                goto L_0x0084;
            L_0x0078:
                r4 = r7.decodedChars;
                r5 = 0;
                r4 = java.lang.Character.toChars(r2, r4, r5);
                r5 = r7.decodedChars;
                r7.outputChars(r5, r4);
            L_0x0084:
                r4 = java.lang.Character.isSupplementaryCodePoint(r2);
                if (r4 == 0) goto L_0x008c;
            L_0x008a:
                r4 = 2;
                goto L_0x008d;
            L_0x008c:
                r4 = 1;
            L_0x008d:
                r0 = r0 + r4;
                r1 = r0;
                goto L_0x004f;
            L_0x0091:
                return r7;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.google.gdata.util.common.base.UnicodeEscaper.1.append(java.lang.CharSequence, int, int):java.lang.Appendable");
            }

            public Appendable append(char c) throws IOException {
                char[] escaped;
                StringBuilder stringBuilder;
                if (this.pendingHighSurrogate != -1) {
                    if (Character.isLowSurrogate(c)) {
                        escaped = UnicodeEscaper.this.escape(Character.toCodePoint((char) this.pendingHighSurrogate, c));
                        if (escaped != null) {
                            outputChars(escaped, escaped.length);
                        } else {
                            out.append((char) this.pendingHighSurrogate);
                            out.append(c);
                        }
                        this.pendingHighSurrogate = -1;
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("Expected low surrogate character but got '");
                        stringBuilder.append(c);
                        stringBuilder.append("' with value ");
                        stringBuilder.append(c);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                } else if (Character.isHighSurrogate(c)) {
                    this.pendingHighSurrogate = c;
                } else if (Character.isLowSurrogate(c)) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Unexpected low surrogate character '");
                    stringBuilder.append(c);
                    stringBuilder.append("' with value ");
                    stringBuilder.append(c);
                    throw new IllegalArgumentException(stringBuilder.toString());
                } else {
                    escaped = UnicodeEscaper.this.escape((int) c);
                    if (escaped != null) {
                        outputChars(escaped, escaped.length);
                    } else {
                        out.append(c);
                    }
                }
                return this;
            }

            private void outputChars(char[] chars, int len) throws IOException {
                for (int n = 0; n < len; n++) {
                    out.append(chars[n]);
                }
            }
        };
    }

    protected static final int codePointAt(CharSequence seq, int index, int end) {
        if (index < end) {
            int index2 = index + 1;
            index = seq.charAt(index);
            if (index >= 55296) {
                if (index <= 57343) {
                    if (index > 56319) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Unexpected low surrogate character '");
                        stringBuilder.append(index);
                        stringBuilder.append("' with value ");
                        stringBuilder.append(index);
                        stringBuilder.append(" at index ");
                        stringBuilder.append(index2 - 1);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    } else if (index2 == end) {
                        return -index;
                    } else {
                        char c2 = seq.charAt(index2);
                        if (Character.isLowSurrogate(c2)) {
                            return Character.toCodePoint(index, c2);
                        }
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Expected low surrogate but got char '");
                        stringBuilder2.append(c2);
                        stringBuilder2.append("' with value ");
                        stringBuilder2.append(c2);
                        stringBuilder2.append(" at index ");
                        stringBuilder2.append(index2);
                        throw new IllegalArgumentException(stringBuilder2.toString());
                    }
                }
            }
            return index;
        }
        throw new IndexOutOfBoundsException("Index exceeds specified range");
    }

    private static final char[] growBuffer(char[] dest, int index, int size) {
        char[] copy = new char[size];
        if (index > 0) {
            System.arraycopy(dest, 0, copy, 0, index);
        }
        return copy;
    }
}
