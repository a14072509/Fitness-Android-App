package com.keyes.youtube;

public class PlaylistId extends YouTubeId {
    public PlaylistId(String pId) {
        super(pId);
    }
}
