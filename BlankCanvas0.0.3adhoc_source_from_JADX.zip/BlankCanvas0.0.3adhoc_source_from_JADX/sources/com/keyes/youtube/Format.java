package com.keyes.youtube;

public class Format {
    protected int mId;

    public Format(String pFormatString) {
        this.mId = Integer.parseInt(pFormatString.split("/")[0]);
    }

    public Format(int pId) {
        this.mId = pId;
    }

    public int getId() {
        return this.mId;
    }

    public boolean equals(Object pObject) {
        boolean z = false;
        if (!(pObject instanceof Format)) {
            return false;
        }
        if (((Format) pObject).mId == this.mId) {
            z = true;
        }
        return z;
    }
}
