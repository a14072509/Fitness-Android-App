package com.keyes.youtube;

public abstract class YouTubeId {
    protected String mId;

    public YouTubeId(String pId) {
        this.mId = pId;
    }

    public String getId() {
        return this.mId;
    }
}
