package com.keyes.youtube;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import com.eachscape.AppResource;
import com.eachscape.AppViewControllerActivity;
import com.eachscape.R$string;
import com.eachscape.managers.LogMgr;
import com.eachscape.models.other.App;
import com.eachscape.other.listener.OnActivityResultListener;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeStandalonePlayer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.FactoryConfigurationError;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class YouTubeUtility {
    private static final int REQ_RESOLVE_SERVICE_MISSING = 60036;
    public static final int REQ_START_STANDALONE_PLAYER = 60035;
    private static final String TAG = YouTubeUtility.class.getSimpleName();
    private static final String YOUTUBE_PLAYLIST_ATOM_FEED_URL = "http://gdata.youtube.com/feeds/api/playlists/";
    private static final String YOUTUBE_VIDEO_INFORMATION_URL = "http://www.youtube.com/get_video_info?&video_id=";

    public static String queryLatestPlaylistVideo(PlaylistId pPlaylistId) throws IOException, ClientProtocolException, FactoryConfigurationError {
        String lVideoId = null;
        HttpClient lClient = new DefaultHttpClient();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(YOUTUBE_PLAYLIST_ATOM_FEED_URL);
        stringBuilder.append(pPlaylistId.getId());
        stringBuilder.append("?v=2&max-results=50&alt=json");
        HttpResponse lResp = lClient.execute(new HttpGet(stringBuilder.toString()));
        ByteArrayOutputStream lBOS = new ByteArrayOutputStream();
        try {
            lResp.getEntity().writeTo(lBOS);
            JSONArray lEntryArr = new JSONObject(lBOS.toString("UTF-8")).getJSONObject("feed").getJSONArray("entry");
            JSONArray lLinkArr = lEntryArr.getJSONObject(lEntryArr.length() - 1).getJSONArray("link");
            for (int i = 0; i < lLinkArr.length(); i++) {
                JSONObject lLinkObj = lLinkArr.getJSONObject(i);
                String lRelVal = lLinkObj.optString("rel", null);
                if (lRelVal != null && lRelVal.equals("alternate")) {
                    lVideoId = Uri.parse(lLinkObj.optString("href", null)).getQueryParameter("v");
                    break;
                }
            }
        } catch (IllegalStateException e) {
            Log.i(YouTubeUtility.class.getSimpleName(), "Error retrieving content from YouTube", e);
        } catch (IOException e2) {
            Log.i(YouTubeUtility.class.getSimpleName(), "Error retrieving content from YouTube", e2);
        } catch (JSONException e3) {
            Log.i(YouTubeUtility.class.getSimpleName(), "Error retrieving content from YouTube", e3);
        }
        return lVideoId;
    }

    public static String calculateYouTubeUrl(String pYouTubeFmtQuality, boolean pFallback, String pYouTubeVideoId) throws IOException, ClientProtocolException, UnsupportedEncodingException {
        int length;
        String lFormatStr;
        String lUriStr;
        String lUriStr2 = null;
        HttpClient lClient = new DefaultHttpClient();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(YOUTUBE_VIDEO_INFORMATION_URL);
        stringBuilder.append(pYouTubeVideoId);
        HttpResponse lResp = lClient.execute(new HttpGet(stringBuilder.toString()));
        ByteArrayOutputStream lBOS = new ByteArrayOutputStream();
        lResp.getEntity().writeTo(lBOS);
        String[] lArgs = new String(lBOS.toString("UTF-8")).split("&");
        Map<String, String> lArgMap = new HashMap();
        for (String[] lArgValStrArr : lArgs) {
            String[] lArgValStrArr2 = lArgValStrArr2.split("=");
            if (lArgValStrArr2 != null) {
                if (lArgValStrArr2.length >= 2) {
                    lArgMap.put(lArgValStrArr2[0], URLDecoder.decode(lArgValStrArr2[1]));
                }
            }
        }
        String lFmtList = URLDecoder.decode((String) lArgMap.get("fmt_list"));
        ArrayList<Format> lFormats = new ArrayList();
        if (lFmtList != null) {
            for (String lFormatStr2 : lFmtList.split(",")) {
                lFormats.add(new Format(lFormatStr2));
            }
        }
        String lStreamList = (String) lArgMap.get("url_encoded_fmt_stream_map");
        HttpClient lClient2;
        if (lStreamList != null) {
            int lFormatId;
            String[] lStreamStrs = lStreamList.split(",");
            ArrayList<VideoStream> lStreams = new ArrayList();
            length = lStreamStrs.length;
            int i = 0;
            while (i < length) {
                lUriStr = lUriStr2;
                lClient2 = lClient;
                lStreams.add(new VideoStream(lStreamStrs[i]));
                i++;
                lUriStr2 = lUriStr;
                lClient = lClient2;
            }
            lUriStr = lUriStr2;
            lClient2 = lClient;
            lUriStr2 = Integer.parseInt(pYouTubeFmtQuality);
            lClient = new Format((int) lUriStr2);
            while (!lFormats.contains(lClient) && pFallback) {
                length = lClient.getId();
                i = getSupportedFallbackId(length);
                if (length == i) {
                    String str = lUriStr2;
                    break;
                }
                lFormatId = lUriStr2;
                Object lClient3 = new Format(i);
                lUriStr2 = lFormatId;
            }
            lFormatId = lUriStr2;
            lUriStr2 = lFormats.indexOf(lClient);
            if (lUriStr2 >= null) {
                lFormatStr2 = ((VideoStream) lStreams.get(lUriStr2)).getUrl();
                return URLDecoder.decode(lFormatStr2);
            }
        } else {
            lUriStr = null;
            lClient2 = lClient;
        }
        lFormatStr2 = lUriStr;
        return URLDecoder.decode(lFormatStr2);
    }

    public static boolean hasVideoBeenViewed(Context pCtxt, String pVideoId) {
        String lViewedVideoIds = PreferenceManager.getDefaultSharedPreferences(pCtxt).getString("com.eachscape.lastViewedVideoIds", null);
        if (lViewedVideoIds == null) {
            return false;
        }
        String[] lSplitIds = lViewedVideoIds.split(";");
        if (lSplitIds != null) {
            if (lSplitIds.length != 0) {
                int i = 0;
                while (i < lSplitIds.length) {
                    if (lSplitIds[i] != null && lSplitIds[i].equals(pVideoId)) {
                        return true;
                    }
                    i++;
                }
                return false;
            }
        }
        return false;
    }

    public static void markVideoAsViewed(Context pCtxt, String pVideoId) {
        SharedPreferences lPrefs = PreferenceManager.getDefaultSharedPreferences(pCtxt);
        if (pVideoId != null) {
            String lViewedVideoIds = lPrefs.getString("com.eachscape.lastViewedVideoIds", null);
            if (lViewedVideoIds == null) {
                lViewedVideoIds = "";
            }
            String[] lSplitIds = lViewedVideoIds.split(";");
            if (lSplitIds == null) {
                lSplitIds = new String[0];
            }
            Map<String, String> lMap = new HashMap();
            for (int i = 0; i < lSplitIds.length; i++) {
                lMap.put(lSplitIds[i], lSplitIds[i]);
            }
            String lNewIdList = "";
            for (String lId : lMap.keySet()) {
                if (!lId.trim().equals("")) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(lNewIdList);
                    stringBuilder.append(lId);
                    stringBuilder.append(";");
                    lNewIdList = stringBuilder.toString();
                }
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(lNewIdList);
            stringBuilder2.append(pVideoId);
            stringBuilder2.append(";");
            lNewIdList = stringBuilder2.toString();
            Editor lPrefEdit = lPrefs.edit();
            lPrefEdit.putString("com.eachscape.lastViewedVideoIds", lNewIdList);
            lPrefEdit.commit();
        }
    }

    public static int getSupportedFallbackId(int pOldId) {
        int[] lSupportedFormatIds = new int[]{13, 17, 18};
        int lFallbackId = pOldId;
        int i = lSupportedFormatIds.length - 1;
        while (i >= 0) {
            if (pOldId == lSupportedFormatIds[i] && i > 0) {
                lFallbackId = lSupportedFormatIds[i - 1];
            }
            i--;
        }
        return lFallbackId;
    }

    public static String getYoutubeVideoId(String youtubeUrl) {
        if (TextUtils.isEmpty(youtubeUrl)) {
            return null;
        }
        Matcher matcher = Pattern.compile("https?:\\/\\/(?:[0-9A-Z-]+\\.)?(?:youtu\\.be\\/|youtube\\.com\\S*[^\\w\\-\\s])([\\w\\-]{11})(?=[^\\w\\-\\.]|$)(?![?=&+%\\w-\\.]*(?:['\\\"][^<>]*>|<\\/a>))[?=&+%\\w-\\.]*", 2).matcher(youtubeUrl);
        if (!matcher.matches()) {
            return null;
        }
        String videoId = "";
        String groupIndex1 = matcher.group(1);
        if (groupIndex1.length() == 11) {
            videoId = groupIndex1;
        }
        return videoId;
    }

    private static boolean canResolveIntent(Intent intent) {
        List<ResolveInfo> resolveInfo = AppResource.getInstance().getPackageManager().queryIntentActivities(intent, 0);
        if (resolveInfo == null || resolveInfo.isEmpty()) {
            return false;
        }
        return true;
    }

    public static void startYouTubePlayer(AppViewControllerActivity context, String videoId, OnActivityResultListener onActivityResultListener) {
        Intent intent = YouTubeStandalonePlayer.createVideoIntent(context, App.getDeveloperKey(), videoId, 0, true, false);
        if (intent == null) {
            return;
        }
        if (canResolveIntent(intent)) {
            if (onActivityResultListener != null) {
                context.addActivityResultListenerForYouTube(onActivityResultListener);
            }
            context.startActivityForResult(intent, REQ_START_STANDALONE_PLAYER);
            return;
        }
        YouTubeInitializationResult.SERVICE_MISSING.getErrorDialog(context, REQ_RESOLVE_SERVICE_MISSING).show();
    }

    public static void displayYouTubeErrorDialog(AppViewControllerActivity context, Intent data, OnDismissListener listener) {
        if (data == null) {
            LogMgr.error(TAG, "Attempt to display a youtube error dialog without intent data.");
            return;
        }
        Dialog dialog;
        YouTubeInitializationResult errorReason = YouTubeStandalonePlayer.getReturnedInitializationResult(data);
        if (errorReason.isUserRecoverableError()) {
            dialog = errorReason.getErrorDialog(context, 0);
        } else {
            dialog = new Builder(context).setTitle(R$string.youtube_error_title).setMessage(errorReason.toString()).setNegativeButton(R$string.alert_dialog_ok, null).setCancelable(false).create();
        }
        dialog.setOnDismissListener(listener);
        context.showDialog(123456, dialog);
        LogMgr.error(TAG, String.format("YouTube error [%s]", new Object[]{errorReason.toString()}));
    }
}
