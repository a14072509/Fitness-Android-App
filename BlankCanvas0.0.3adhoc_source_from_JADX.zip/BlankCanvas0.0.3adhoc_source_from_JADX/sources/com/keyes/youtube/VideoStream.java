package com.keyes.youtube;

import com.google.android.gms.common.internal.ImagesContract;
import java.util.HashMap;
import java.util.Map;

public class VideoStream {
    protected String mUrl;

    public VideoStream(String pStreamStr) {
        String[] lArgs = pStreamStr.split("&");
        Map<String, String> lArgMap = new HashMap();
        for (String[] lArgValStrArr : lArgs) {
            String[] lArgValStrArr2 = lArgValStrArr2.split("=");
            if (lArgValStrArr2 != null) {
                if (lArgValStrArr2.length >= 2) {
                    lArgMap.put(lArgValStrArr2[0], lArgValStrArr2[1]);
                }
            }
        }
        this.mUrl = (String) lArgMap.get(ImagesContract.URL);
    }

    public String getUrl() {
        return this.mUrl;
    }
}
